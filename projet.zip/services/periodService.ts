import { supabase } from '@/lib/supabase';
import type { Period, AppSettings } from '@/types';
import { logOperation } from '@/services/operationLogService';

export async function countPaymentsForPeriod(periodId: string): Promise<number> {
  const { count, error } = await supabase
    .from('payments')
    .select('id', { count: 'exact', head: true })
    .eq('period_id', periodId);
  if (error) throw error;
  return count ?? 0;
}

export async function fetchPeriods(schoolYearId?: string | null): Promise<Period[]> {
  let query = supabase
    .from('periods')
    .select('*')
    .order('start_date', { ascending: false });
  if (schoolYearId) query = query.eq('school_year_id', schoolYearId);
  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function fetchOpenPeriods(schoolYearId?: string | null): Promise<Period[]> {
  let query = supabase
    .from('periods')
    .select('*')
    .eq('is_closed', false)
    .order('start_date', { ascending: false });
  if (schoolYearId) query = query.eq('school_year_id', schoolYearId);
  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function createPeriod(input: {
  start_date: string;
  end_date: string;
  school_year_id?: string | null;
  set_active?: boolean;
}): Promise<Period> {
  const { count, error: countErr } = await supabase
    .from('periods')
    .select('id', { count: 'exact', head: true });
  if (countErr) throw countErr;
  const periodNumber = (count ?? 0) + 1;
  const name = `Période ${periodNumber}`;
  const { data, error } = await supabase
    .from('periods')
    .insert({
      name,
      start_date: input.start_date,
      end_date: input.end_date,
      school_year_id: input.school_year_id ?? null,
      is_active: input.set_active ?? true,
    })
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'period_close',
    period_id: data.id,
    description: `Période créée: ${name} (${input.start_date} → ${input.end_date})`,
  });
  return data;
}

export async function updatePeriod(id: string, updates: Partial<Period>): Promise<Period> {
  const { data, error } = await supabase
    .from('periods')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'modification',
    period_id: id,
    description: `Période modifiée: ${data.name}`,
  });
  return data;
}

export async function deletePeriod(id: string): Promise<void> {
  const { error } = await supabase.from('periods').delete().eq('id', id);
  if (error) throw error;
  await logOperation({
    operation_type: 'deletion',
    period_id: id,
    description: 'Période supprimée',
  });
}

export interface PeriodCloseResult {
  periodId?: string;
  totalRevenue: number;
  professorShare: number;
  establishmentShare: number;
  totalDebt: number;
  paymentCount: number;
  unpaidList: { studentName: string; gender: 'male' | 'female' | null; amount: number; amountPaid: number; debt: number }[];
}

export async function closePeriod(periodId: string, settings: AppSettings): Promise<PeriodCloseResult> {
  const { data: period, error: periodErr } = await supabase
    .from('periods')
    .select('start_date,end_date')
    .eq('id', periodId)
    .maybeSingle();
  if (periodErr) throw periodErr;

  // Query payments linked by period_id, OR whose date range overlaps the period
  const { data: payments, error: fetchErr } = await supabase
    .from('payments')
    .select('*, student:students(full_name,gender)')
    .or(`period_id.eq.${periodId},and(period_start.lte.${period?.end_date},period_end.gte.${period?.start_date})`);
  if (fetchErr) throw fetchErr;

  // Ensure all matched payments are linked to this period for future queries
  const unlinked = (payments ?? []).filter((p) => !p.period_id);
  if (unlinked.length > 0) {
    await supabase
      .from('payments')
      .update({ period_id: periodId })
      .in('id', unlinked.map((p) => p.id));
  }

  const totalRevenue = (payments ?? []).reduce((sum, p) => sum + Number(p.amount_paid), 0);
  const totalDebt = (payments ?? []).reduce((sum, p) => sum + (Number(p.amount) - Number(p.amount_paid)), 0);

  let establishmentShare = 0;
  let professorShare = 0;
  if (settings.room_share_type === 'percentage') {
    establishmentShare = totalRevenue * (settings.room_share_rate / 100);
  } else {
    establishmentShare = Math.min(settings.room_share_rate * (payments ?? []).length, totalRevenue);
  }
  professorShare = totalRevenue - establishmentShare;

  const unpaidList = (payments ?? [])
    .filter((p) => Number(p.amount_paid) < Number(p.amount))
    .map((p) => ({
      studentName: (p as { student?: { full_name: string; gender: 'male' | 'female' | null } }).student?.full_name ?? 'Inconnu',
      gender: (p as { student?: { gender: 'male' | 'female' | null } }).student?.gender ?? null,
      amount: Number(p.amount),
      amountPaid: Number(p.amount_paid),
      debt: Number(p.amount) - Number(p.amount_paid),
    }));

  const { error: updateErr } = await supabase
    .from('periods')
    .update({
      is_closed: true,
      is_active: false,
      pin_protected: true,
      closed_at: new Date().toISOString(),
      total_revenue: totalRevenue,
      professor_share: professorShare,
      creche_share: establishmentShare,
      total_debt: totalDebt,
      payment_count: payments?.length ?? 0,
    })
    .eq('id', periodId);
  if (updateErr) throw updateErr;

  return {
    totalRevenue,
    professorShare,
    establishmentShare,
    totalDebt,
    paymentCount: payments?.length ?? 0,
    unpaidList,
  };
}

export async function closePeriodWithLog(periodId: string, settings: AppSettings): Promise<PeriodCloseResult> {
  const result = await closePeriod(periodId, settings);
  await logOperation({
    operation_type: 'period_close',
    period_id: periodId,
    description: `Période clôturée - Revenu: ${result.totalRevenue} DZD, Prof: ${result.professorShare} DZD, Établissement: ${result.establishmentShare} DZD`,
    amount: result.totalRevenue,
  });
  return result;
}

export async function fetchClosedPeriodReport(periodId: string): Promise<PeriodCloseResult> {
  const { data: period, error: periodErr } = await supabase
    .from('periods')
    .select('*')
    .eq('id', periodId)
    .maybeSingle();
  if (periodErr) throw periodErr;
  if (!period) throw new Error('Période introuvable');

  const { data: payments, error: payErr } = await supabase
    .from('payments')
    .select('*, student:students(full_name,gender)')
    .eq('period_id', periodId);
  if (payErr) throw payErr;

  const unpaidList = (payments ?? [])
    .filter((p) => Number(p.amount_paid) < Number(p.amount))
    .map((p) => ({
      studentName: (p as { student?: { full_name: string; gender: 'male' | 'female' | null } }).student?.full_name ?? 'Inconnu',
      gender: (p as { student?: { gender: 'male' | 'female' | null } }).student?.gender ?? null,
      amount: Number(p.amount),
      amountPaid: Number(p.amount_paid),
      debt: Number(p.amount) - Number(p.amount_paid),
    }));

  return {
    periodId,
    totalRevenue: Number(period.total_revenue),
    professorShare: Number(period.professor_share),
    establishmentShare: Number(period.creche_share),
    totalDebt: Number(period.total_debt),
    paymentCount: period.payment_count ?? (payments?.length ?? 0),
    unpaidList,
  };
}

export async function fetchActivePeriod(schoolYearId?: string | null): Promise<Period | null> {
  let query = supabase
    .from('periods')
    .select('*')
    .eq('is_active', true);
  if (schoolYearId) query = query.eq('school_year_id', schoolYearId);
  const { data, error } = await query.maybeSingle();
  if (error) throw error;
  return data;
}

export async function setActivePeriod(periodId: string): Promise<void> {
  const { error } = await supabase
    .from('periods')
    .update({ is_active: true })
    .eq('id', periodId);
  if (error) throw error;
}
