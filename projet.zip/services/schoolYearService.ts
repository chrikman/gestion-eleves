import { supabase } from '@/lib/supabase';
import type { SchoolYear } from '@/types';
import { logOperation } from '@/services/operationLogService';

export async function fetchSchoolYears(): Promise<SchoolYear[]> {
  const { data, error } = await supabase
    .from('school_years')
    .select('*')
    .order('start_date', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchCurrentSchoolYear(): Promise<SchoolYear | null> {
  const { data, error } = await supabase
    .from('school_years')
    .select('*')
    .eq('is_current', true)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function createSchoolYear(input: Omit<SchoolYear, 'id' | 'created_at'>): Promise<SchoolYear> {
  if (input.is_current) {
    await supabase.from('school_years').update({ is_current: false }).neq('id', '00000000-0000-0000-0000-000000000000');
  }
  const { data, error } = await supabase
    .from('school_years')
    .insert(input)
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'creation',
    description: `Année scolaire créée: ${input.name}`,
    school_year_id: data.id,
  });
  return data;
}

export async function updateSchoolYear(id: string, updates: Partial<SchoolYear>): Promise<SchoolYear> {
  if (updates.is_current) {
    await supabase.from('school_years').update({ is_current: false }).neq('id', id);
  }
  const { data, error } = await supabase
    .from('school_years')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteSchoolYear(id: string): Promise<void> {
  const { error } = await supabase.from('school_years').delete().eq('id', id);
  if (error) throw error;
}
