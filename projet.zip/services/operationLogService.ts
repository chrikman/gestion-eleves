import { supabase } from '@/lib/supabase';
import type { OperationLog, OperationType } from '@/types';

export async function fetchOperations(limit = 200): Promise<OperationLog[]> {
  const { data, error } = await supabase
    .from('operations_log')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}

export async function fetchOperationsByDay(date: string): Promise<OperationLog[]> {
  const { data, error } = await supabase
    .from('operations_log')
    .select('*')
    .gte('created_at', `${date}T00:00:00`)
    .lte('created_at', `${date}T23:59:59`)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function logOperation(input: {
  operation_type: OperationType;
  student_id?: string | null;
  payment_id?: string | null;
  period_id?: string | null;
  student_name?: string | null;
  description?: string | null;
  amount?: number;
  school_year_id?: string | null;
}): Promise<void> {
  try {
    await supabase.from('operations_log').insert({
      operation_type: input.operation_type,
      student_id: input.student_id ?? null,
      payment_id: input.payment_id ?? null,
      period_id: input.period_id ?? null,
      student_name: input.student_name ?? null,
      description: input.description ?? null,
      amount: input.amount ?? 0,
      school_year_id: input.school_year_id ?? null,
      operation_timestamp: new Date().toISOString(),
    });
  } catch {
    // best-effort logging
  }
}
