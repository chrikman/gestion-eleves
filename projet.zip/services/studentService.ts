import { supabase } from '@/lib/supabase';
import type { Student, StudentStatus, Gender } from '@/types';
import { logOperation } from '@/services/operationLogService';

export interface StudentWithRelations extends Omit<Student, 'level' | 'school_year'> {
  level?: { id: string; name: string; label: string | null } | null;
  school_year?: { id: string; name: string } | null;
}

export async function fetchStudents(filters?: {
  status?: StudentStatus;
  levelId?: string;
  schoolYearId?: string;
  search?: string;
}): Promise<StudentWithRelations[]> {
  let query = supabase
    .from('students')
    .select('*, level:levels(id,name,label), school_year:school_years(id,name)')
    .order('full_name', { ascending: true });

  if (filters?.status) {
    query = query.eq('status', filters.status);
  } else {
    query = query.neq('status', 'trashed');
  }
  if (filters?.levelId) query = query.eq('level_id', filters.levelId);
  if (filters?.schoolYearId) query = query.eq('school_year_id', filters.schoolYearId);
  if (filters?.search) {
    const s = filters.search.trim();
    if (s) {
      query = query.ilike('full_name', `%${s}%`);
    }
  }

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function fetchStudentById(id: string): Promise<StudentWithRelations | null> {
  const { data, error } = await supabase
    .from('students')
    .select('*, level:levels(id,name,label), school_year:school_years(id,name)')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function createStudent(input: {
  full_name: string;
  level_id?: string | null;
  phone?: string | null;
  parent_phone?: string | null;
  gender?: Gender;
  enrollment_date?: string | null;
  notes?: string | null;
  school_year_id?: string | null;
}): Promise<Student> {
  const { data, error } = await supabase
    .from('students')
    .insert({
      full_name: input.full_name,
      level_id: input.level_id ?? null,
      phone: input.phone ?? null,
      parent_phone: input.parent_phone ?? null,
      gender: input.gender ?? null,
      status: 'active',
      enrollment_date: input.enrollment_date ?? new Date().toISOString().slice(0, 10),
      notes: input.notes ?? null,
      school_year_id: input.school_year_id ?? null,
    })
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'creation',
    student_id: data.id,
    student_name: input.full_name,
    description: `Élève créé: ${input.full_name}`,
    school_year_id: input.school_year_id ?? null,
  });
  return data;
}

export async function updateStudent(id: string, updates: Partial<Student>): Promise<Student> {
  const { data, error } = await supabase
    .from('students')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'modification',
    student_id: id,
    student_name: data.full_name,
    description: `Modification de l'élève: ${data.full_name}`,
  });
  return data;
}

export async function setStudentStatus(id: string, status: StudentStatus): Promise<void> {
  const { error } = await supabase
    .from('students')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
  await logOperation({
    operation_type: status === 'trashed' ? 'deletion' : 'modification',
    student_id: id,
    description: `Statut changé vers: ${status}`,
  });
}

export async function carryOverActiveStudents(fromSchoolYearId: string | null, toSchoolYearId: string): Promise<number> {
  let query = supabase.from('students').select('*').eq('status', 'active');
  if (fromSchoolYearId) query = query.eq('school_year_id', fromSchoolYearId);
  const { data: activeStudents, error: fetchErr } = await query;
  if (fetchErr) throw fetchErr;
  if (!activeStudents || activeStudents.length === 0) return 0;

  const newRecords = activeStudents.map((s) => ({
    full_name: s.full_name,
    level_id: s.level_id,
    phone: s.phone,
    parent_phone: s.parent_phone,
    gender: s.gender,
    status: 'active' as const,
    enrollment_date: new Date().toISOString().slice(0, 10),
    notes: s.notes,
    school_year_id: toSchoolYearId,
  }));

  const { data: inserted, error: insertErr } = await supabase.from('students').insert(newRecords).select('id,full_name');
  if (insertErr) throw insertErr;

  for (const s of inserted ?? []) {
    await logOperation({
      operation_type: 'reenrollment',
      student_id: s.id,
      student_name: s.full_name,
      description: `Reporté vers la nouvelle année: ${s.full_name}`,
      school_year_id: toSchoolYearId,
    });
  }

  return inserted?.length ?? 0;
}

export async function permanentlyDeleteStudent(id: string): Promise<void> {
  const { data: existing } = await supabase.from('students').select('full_name').eq('id', id).maybeSingle();
  const { error } = await supabase.from('students').delete().eq('id', id);
  if (error) throw error;
  await logOperation({
    operation_type: 'deletion',
    student_id: id,
    student_name: existing?.full_name ?? null,
    description: `Suppression définitive: ${existing?.full_name ?? id}`,
  });
}

export async function reenrollStudent(id: string, schoolYearId: string, levelId?: string | null): Promise<void> {
  const { data: existing } = await supabase.from('students').select('full_name').eq('id', id).maybeSingle();
  const { error } = await supabase
    .from('students')
    .update({
      school_year_id: schoolYearId,
      level_id: levelId ?? null,
      status: 'active',
      enrollment_date: new Date().toISOString().slice(0, 10),
      updated_at: new Date().toISOString(),
    })
    .eq('id', id);
  if (error) throw error;
  await logOperation({
    operation_type: 'reenrollment',
    student_id: id,
    student_name: existing?.full_name ?? null,
    description: `Réinscription: ${existing?.full_name ?? id}`,
    school_year_id: schoolYearId,
  });
}
