import { supabase } from '@/lib/supabase';
import type { Level } from '@/types';

export async function fetchLevels(includeArchived = false): Promise<Level[]> {
  let query = supabase.from('levels').select('*').order('sort_order', { ascending: true });
  if (!includeArchived) {
    query = query.eq('archived', false);
  }
  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function createLevel(input: Pick<Level, 'name'> & Partial<Level>): Promise<Level> {
  const { data, error } = await supabase
    .from('levels')
    .insert({
      name: input.name,
      label: input.label ?? null,
      sort_order: input.sort_order ?? 0,
      archived: false,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateLevel(id: string, updates: Partial<Level>): Promise<Level> {
  const { data, error } = await supabase.from('levels').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteLevel(id: string): Promise<void> {
  const { error } = await supabase.from('levels').delete().eq('id', id);
  if (error) throw error;
}

export async function archiveLevel(id: string, archived = true): Promise<void> {
  const { error } = await supabase.from('levels').update({ archived }).eq('id', id);
  if (error) throw error;
}
