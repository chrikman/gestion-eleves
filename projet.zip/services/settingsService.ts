import { supabase } from '@/lib/supabase';
import { DEFAULT_SETTINGS, type AppSettings } from '@/types';

const SETTINGS_KEY = 'app_settings';

export async function loadSettings(): Promise<AppSettings> {
  const { data, error } = await supabase
    .from('settings')
    .select('value')
    .eq('key', SETTINGS_KEY)
    .maybeSingle();
  if (error) throw error;
  if (!data) return DEFAULT_SETTINGS;
  return { ...DEFAULT_SETTINGS, ...(data.value as Partial<AppSettings>) };
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  const { error } = await supabase
    .from('settings')
    .upsert(
      { key: SETTINGS_KEY, value: settings as unknown as Record<string, unknown>, updated_at: new Date().toISOString() },
      { onConflict: 'key' },
    );
  if (error) throw error;
}
