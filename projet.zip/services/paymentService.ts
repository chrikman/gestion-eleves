import { supabase } from '@/lib/supabase';
import type { Payment, PaymentStatus, PaymentType } from '@/types';
import { logOperation } from '@/services/operationLogService';

export interface PaymentWithStudent extends Omit<Payment, 'student'> {
  student?: { id: string; full_name: string; gender: 'male' | 'female' | null } | null;
}

export async function fetchPaymentsByStudent(studentId: string): Promise<Payment[]> {
  const { data, error } = await supabase
    .from('payments')
    .select('*, regularized_payment:regularizes_payment_id(id,amount,amount_paid,status,period_start,period_end,receipt_number)')
    .eq('student_id', studentId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function fetchAllPayments(filters?: {
  schoolYearId?: string;
  status?: PaymentStatus;
  periodId?: string;
  regularizationsOnly?: boolean;
}): Promise<PaymentWithStudent[]> {
  let query = supabase
    .from('payments')
    .select('*, student:students(id,full_name,gender), regularized_payment:regularizes_payment_id(id,student_id,amount,amount_paid,status,period_start,period_end)')
    .order('created_at', { ascending: false });
  if (filters?.schoolYearId) query = query.eq('school_year_id', filters.schoolYearId);
  if (filters?.status) query = query.eq('status', filters.status);
  if (filters?.periodId) query = query.eq('period_id', filters.periodId);
  if (filters?.regularizationsOnly) query = query.eq('is_regularization', true);
  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function createPayment(input: {
  student_id: string;
  amount: number;
  amount_paid: number;
  status: PaymentStatus;
  payment_type?: PaymentType;
  period_start: string;
  period_end: string;
  session_count: number;
  sessions_completed?: number;
  is_closed?: boolean;
  school_year_id?: string | null;
  period_id?: string | null;
  notes?: string | null;
  is_regularization?: boolean;
  regularizes_payment_id?: string | null;
}): Promise<Payment> {
  const receiptNumber = `REC-${Date.now()}`;
  const now = new Date().toISOString();
  const paymentDate = now.slice(0, 10);
  const { data, error } = await supabase
    .from('payments')
    .insert({
      ...input,
      payment_type: input.payment_type ?? 'monthly',
      sessions_completed: input.sessions_completed ?? 0,
      is_closed: input.is_closed ?? false,
      is_regularization: input.is_regularization ?? false,
      regularizes_payment_id: input.regularizes_payment_id ?? null,
      receipt_number: receiptNumber,
      payment_date: paymentDate,
      operation_timestamp: now,
    })
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: input.is_regularization ? 'regularization' : 'payment',
    student_id: input.student_id,
    payment_id: data.id,
    description: input.is_regularization
      ? `Régularisation de ${input.amount_paid} DZD (reçu ${receiptNumber})`
      : `Paiement de ${input.amount_paid} DZD (reçu ${receiptNumber})`,
    amount: input.amount_paid,
    school_year_id: input.school_year_id ?? null,
  });
  return data;
}

export async function updatePayment(id: string, updates: Partial<Payment>): Promise<Payment> {
  const updateData = { ...updates, operation_timestamp: new Date().toISOString() };
  const { data, error } = await supabase
    .from('payments')
    .update(updateData)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'modification',
    payment_id: id,
    student_id: data.student_id,
    description: `Modification du paiement (reçu ${data.receipt_number})`,
    amount: Number(updates.amount_paid ?? data.amount_paid),
  });
  return data;
}

export async function deletePayment(id: string): Promise<void> {
  const { data: existing } = await supabase.from('payments').select('student_id,receipt_number').eq('id', id).maybeSingle();
  const { error } = await supabase.from('payments').delete().eq('id', id);
  if (error) throw error;
  await logOperation({
    operation_type: 'deletion',
    payment_id: id,
    student_id: existing?.student_id ?? null,
    description: `Suppression du paiement (reçu ${existing?.receipt_number ?? id})`,
  });
}

export async function incrementSession(paymentId: string): Promise<Payment> {
  const { data: current, error: fetchErr } = await supabase
    .from('payments')
    .select('*')
    .eq('id', paymentId)
    .maybeSingle();
  if (fetchErr) throw fetchErr;
  if (!current) throw new Error('Paiement introuvable');

  const completed = (current.sessions_completed ?? 0) + 1;
  const isClosed = completed >= current.session_count;

  const { data, error } = await supabase
    .from('payments')
    .update({ sessions_completed: completed, is_closed: isClosed })
    .eq('id', paymentId)
    .select()
    .single();
  if (error) throw error;
  await logOperation({
    operation_type: 'session_increment',
    payment_id: paymentId,
    student_id: current.student_id,
    description: `Séance ${completed}/${current.session_count} validée`,
  });
  return data;
}

export function computePaymentStatus(amount: number, amountPaid: number, sessionCount: number): PaymentStatus {
  if (sessionCount === 1) return 'single';
  if (amountPaid <= 0) return 'unpaid';
  if (amountPaid >= amount) return 'paid';
  return 'partial';
}

export function getPaymentTypeLabel(type: PaymentType): string {
  switch (type) {
    case 'monthly': return 'Mensuel';
    case 'per_session': return 'Par séance';
    case 'social_case': return 'Cas social';
    default: return type;
  }
}

export interface OldDebt {
  id: string;
  student_id: string;
  student_name: string;
  amount: number;
  amount_paid: number;
  debt: number;
  status: PaymentStatus;
  period_start: string;
  period_end: string;
  period_name: string;
  receipt_number: string | null;
  is_closed: boolean;
}

export async function fetchOldDebts(studentId?: string): Promise<OldDebt[]> {
  let query = supabase
    .from('payments')
    .select(`
      id, student_id, amount, amount_paid, status, period_start, period_end,
      receipt_number, is_closed,
      student:students(full_name),
      period:periods(name)
    `)
    .eq('is_closed', true)
    .neq('status', 'paid')
    .order('period_end', { ascending: false });
  if (studentId) query = query.eq('student_id', studentId);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map((p) => {
    const row = p as typeof p & { student?: { full_name: string } | null; period?: { name: string } | null };
    return {
      id: row.id,
      student_id: row.student_id,
      student_name: row.student?.full_name ?? 'Inconnu',
      amount: Number(row.amount),
      amount_paid: Number(row.amount_paid),
      debt: Number(row.amount) - Number(row.amount_paid),
      status: row.status as PaymentStatus,
      period_start: row.period_start,
      period_end: row.period_end,
      period_name: row.period?.name ?? 'Période inconnue',
      receipt_number: row.receipt_number,
      is_closed: row.is_closed,
    };
  });
}

export async function fetchRegularizationsForPayment(paymentId: string): Promise<Payment[]> {
  const { data, error } = await supabase
    .from('payments')
    .select('*')
    .eq('regularizes_payment_id', paymentId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}
