import { supabase } from '@/lib/supabase';
import type { Absence } from '@/types';

export async function fetchAbsencesByStudent(studentId: string): Promise<Absence[]> {
  const { data, error } = await supabase
    .from('absences')
    .select('*')
    .eq('student_id', studentId)
    .order('date', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function createAbsence(input: {
  student_id: string;
  date: string;
  reason?: string | null;
  session_index?: number | null;
}): Promise<Absence> {
  const { data, error } = await supabase
    .from('absences')
    .insert(input)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteAbsence(id: string): Promise<void> {
  const { error } = await supabase.from('absences').delete().eq('id', id);
  if (error) throw error;
}
