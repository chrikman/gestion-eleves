export type StudentStatus = 'active' | 'suspended' | 'trashed';
export type PaymentStatus = 'paid' | 'unpaid' | 'partial' | 'single';
export type PaymentType = 'monthly' | 'per_session' | 'social_case';
export type Gender = 'male' | 'female' | null;
export type OperationType = 'payment' | 'reenrollment' | 'regularization' | 'modification' | 'deletion' | 'creation' | 'session_increment' | 'period_close';

export interface Level {
  id: string;
  name: string;
  label: string | null;
  sort_order: number;
  archived: boolean;
  created_at: string;
}

export interface SchoolYear {
  id: string;
  name: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
  created_at: string;
}

export interface Student {
  id: string;
  full_name: string;
  first_name: string | null;
  last_name: string | null;
  level_id: string | null;
  phone: string | null;
  parent_phone: string | null;
  gender: Gender;
  status: StudentStatus;
  enrollment_date: string | null;
  notes: string | null;
  school_year_id: string | null;
  created_at: string;
  updated_at: string;
  level?: Level | null;
  school_year?: SchoolYear | null;
}

export interface Payment {
  id: string;
  student_id: string;
  amount: number;
  amount_paid: number;
  status: PaymentStatus;
  payment_type: PaymentType;
  period_start: string;
  period_end: string;
  session_count: number;
  sessions_completed: number;
  is_closed: boolean;
  receipt_number: string | null;
  school_year_id: string | null;
  period_id: string | null;
  payment_date: string | null;
  notes: string | null;
  is_regularization: boolean;
  regularizes_payment_id: string | null;
  operation_timestamp: string | null;
  created_at: string;
  student?: Student | null;
  regularized_payment?: Payment | null;
}

export interface Absence {
  id: string;
  student_id: string;
  date: string;
  reason: string | null;
  session_index: number | null;
  created_at: string;
  student?: Student | null;
}

export interface Period {
  id: string;
  name: string;
  start_date: string;
  end_date: string;
  is_closed: boolean;
  is_active: boolean;
  pin_protected: boolean;
  school_year_id: string | null;
  total_revenue: number;
  professor_share: number;
  creche_share: number;
  total_debt: number;
  payment_count: number;
  closed_at: string | null;
  created_at: string;
}

export interface OperationLog {
  id: string;
  operation_type: OperationType;
  student_id: string | null;
  payment_id: string | null;
  period_id: string | null;
  student_name: string | null;
  description: string | null;
  amount: number;
  school_year_id: string | null;
  operation_timestamp: string | null;
  created_at: string;
}

export interface AppSettings {
  professor_name: string;
  professor_first_name: string;
  professor_phone: string;
  professor_email: string;
  professor_center: string;
  professor_address: string;
  professor_logo: string | null;
  professor_signature: string | null;
  current_school_year_id: string | null;
  sessions_per_period: number;
  period_duration_days: number;
  room_share_rate: number;
  room_share_type: 'percentage' | 'fixed';
  default_session_price: number;
  theme_mode: 'light' | 'dark' | 'system';
  app_lock_enabled: boolean;
  app_password: string | null;
  accent_color: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  professor_name: '',
  professor_first_name: '',
  professor_phone: '',
  professor_email: '',
  professor_center: '',
  professor_address: '',
  professor_logo: null,
  professor_signature: null,
  current_school_year_id: null,
  sessions_per_period: 4,
  period_duration_days: 21,
  room_share_rate: 15,
  room_share_type: 'percentage',
  default_session_price: 500,
  theme_mode: 'system',
  app_lock_enabled: false,
  app_password: null,
  accent_color: '#2563EB',
};
