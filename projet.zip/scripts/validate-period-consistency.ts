/*
 * Validation script: checks consistency between payments, period archives, and reports.
 *
 * Run with: npx tsx scripts/validate-period-consistency.ts
 *
 * Checks:
 * 1. Every closed period has non-zero totals matching its linked payments.
 * 2. Every payment with a period_id belongs to a period whose date range overlaps.
 * 3. Sum of all closed period revenues equals sum of payments linked to closed periods.
 * 4. No payment has a NULL period_id when an active period exists.
 */

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? process.env.SUPABASE_URL ?? '';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? process.env.SUPABASE_ANON_KEY ?? '';

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase env vars');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

interface PeriodRow {
  id: string;
  name: string;
  is_closed: boolean;
  is_active: boolean;
  start_date: string;
  end_date: string;
  total_revenue: string;
  professor_share: string;
  creche_share: string;
  total_debt: string;
  payment_count: number;
}

interface PaymentRow {
  id: string;
  amount: string;
  amount_paid: string;
  period_id: string | null;
  period_start: string;
  period_end: string;
}

async function validate(): Promise<void> {
  let errors = 0;
  let warnings = 0;

  const { data: periods, error: periodErr } = await supabase
    .from('periods')
    .select('*')
    .order('created_at', { ascending: true });
  if (periodErr) throw periodErr;

  const { data: payments, error: payErr } = await supabase
    .from('payments')
    .select('id,amount,amount_paid,period_id,period_start,period_end')
    .order('created_at', { ascending: true });
  if (payErr) throw payErr;

  // Check 1: Closed periods have consistent totals
  for (const period of (periods ?? []) as PeriodRow[]) {
    if (!period.is_closed) continue;

    const periodPayments = (payments ?? []).filter(
      (p: PaymentRow) => p.period_id === period.id,
    );

    const computedRevenue = periodPayments.reduce(
      (sum: number, p: PaymentRow) => sum + Number(p.amount_paid),
      0,
    );
    const computedDebt = periodPayments.reduce(
      (sum: number, p: PaymentRow) => sum + (Number(p.amount) - Number(p.amount_paid)),
      0,
    );
    const storedRevenue = Number(period.total_revenue);
    const storedDebt = Number(period.total_debt);

    if (computedRevenue !== storedRevenue) {
      console.error(
        `[FAIL] Period "${period.name}": revenue mismatch — stored=${storedRevenue}, computed=${computedRevenue}`,
      );
      errors++;
    }

    if (computedDebt !== storedDebt) {
      console.error(
        `[FAIL] Period "${period.name}": debt mismatch — stored=${storedDebt}, computed=${computedDebt}`,
      );
      errors++;
    }

    if (periodPayments.length !== (period.payment_count ?? 0)) {
      console.error(
        `[FAIL] Period "${period.name}": payment_count mismatch — stored=${period.payment_count ?? 0}, actual=${periodPayments.length}`,
      );
      errors++;
    }

    if (storedRevenue === 0 && periodPayments.length > 0) {
      console.error(
        `[FAIL] Period "${period.name}": stored revenue is 0 but has ${periodPayments.length} linked payments`,
      );
      errors++;
    }

    console.log(
      `[OK] Period "${period.name}": revenue=${storedRevenue}, debt=${storedDebt}, payments=${periodPayments.length}`,
    );
  }

  // Check 2: Payment period_id date overlap
  for (const payment of (payments ?? []) as PaymentRow[]) {
    if (!payment.period_id) continue;
    const period = (periods ?? []).find((p: PeriodRow) => p.id === payment.period_id);
    if (!period) {
      console.error(`[FAIL] Payment ${payment.id}: period_id references non-existent period`);
      errors++;
      continue;
    }
    const overlaps =
      payment.period_start <= period.end_date && payment.period_end >= period.start_date;
    if (!overlaps) {
      console.warn(
        `[WARN] Payment ${payment.id}: date range does not overlap period "${period.name}"`,
      );
      warnings++;
    }
  }

  // Check 3: Sum of closed period revenues
  const closedPeriods = (periods ?? []).filter((p: PeriodRow) => p.is_closed);
  const totalStoredRevenue = closedPeriods.reduce(
    (sum: number, p: PeriodRow) => sum + Number(p.total_revenue),
    0,
  );
  const closedPeriodIds = closedPeriods.map((p: PeriodRow) => p.id);
  const closedPayments = (payments ?? []).filter((p: PaymentRow) =>
    closedPeriodIds.includes(p.period_id ?? ''),
  );
  const totalComputedRevenue = closedPayments.reduce(
    (sum: number, p: PaymentRow) => sum + Number(p.amount_paid),
    0,
  );

  if (totalStoredRevenue !== totalComputedRevenue) {
    console.error(
      `[FAIL] Total revenue mismatch — stored total=${totalStoredRevenue}, computed from payments=${totalComputedRevenue}`,
    );
    errors++;
  } else {
    console.log(
      `[OK] Total closed period revenue: ${totalStoredRevenue} (matches ${closedPayments.length} payments)`,
    );
  }

  // Check 4: Unlinked payments when active period exists
  const activePeriod = (periods ?? []).find((p: PeriodRow) => p.is_active);
  if (activePeriod) {
    const unlinked = (payments ?? []).filter(
      (p: PaymentRow) => !p.period_id && p.period_start <= activePeriod.end_date && p.period_end >= activePeriod.start_date,
    );
    if (unlinked.length > 0) {
      console.warn(
        `[WARN] ${unlinked.length} payment(s) have NULL period_id but overlap active period "${activePeriod.name}"`,
      );
      warnings++;
    } else {
      console.log(`[OK] All payments overlapping the active period are linked`);
    }
  }

  console.log('\n--- Summary ---');
  console.log(`Errors:   ${errors}`);
  console.log(`Warnings: ${warnings}`);
  if (errors > 0) {
    console.log('RESULT: FAILED');
    process.exit(1);
  } else {
    console.log('RESULT: PASSED');
  }
}

validate().catch((err) => {
  console.error('Validation script error:', err);
  process.exit(1);
});
