import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Switch, TextInput, Modal, FlatList, RefreshControl } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { ScreenHeader, LoadingView, ErrorView } from '@/components/ScreenHeader';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { DatePickerField } from '@/components/DatePickerField';
import { StudentAvatar } from '@/components/StudentAvatar';
import { EmptyState } from '@/components/EmptyState';
import { loadSettings, saveSettings } from '@/services/settingsService';
import { fetchSchoolYears, createSchoolYear } from '@/services/schoolYearService';
import { fetchPeriods, createPeriod, updatePeriod, deletePeriod, countPaymentsForPeriod } from '@/services/periodService';
import { carryOverActiveStudents, fetchStudents, setStudentStatus, permanentlyDeleteStudent, type StudentWithRelations } from '@/services/studentService';
import { fetchOperations } from '@/services/operationLogService';
import { fetchAllPayments, type PaymentWithStudent } from '@/services/paymentService';
import { DEFAULT_SETTINGS, type AppSettings, type SchoolYear, type Period, type OperationLog, type OperationType } from '@/types';
import { todayISO, formatDate, formatCurrency, getGenderColor } from '@/utils/format';
import { User, GraduationCap, Palette, Shield, Sun, Moon, Monitor, Plus, Check, Building2, CalendarClock, X, Pencil, Trash2, MapPin, Phone, Mail, Image as ImageIcon, PenTool, History, Activity, Trash, ChevronRight, ChevronDown, Banknote, UserPlus, RefreshCw, Lock, TrendingUp } from 'lucide-react-native';

type SubPage = null | 'history' | 'journal' | 'trash';
type Category = null | 'profile' | 'years' | 'periods' | 'share' | 'data' | 'theme' | 'security';

export default function SettingsScreen() {
  const { colors, spacing, radius, mode, setMode } = useTheme();
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [schoolYears, setSchoolYears] = useState<SchoolYear[]>([]);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showPeriodModal, setShowPeriodModal] = useState(false);
  const [editingPeriod, setEditingPeriod] = useState<Period | null>(null);
  const [showYearModal, setShowYearModal] = useState(false);
  const [confirmDeletePeriod, setConfirmDeletePeriod] = useState<Period | null>(null);
  const [subPage, setSubPage] = useState<SubPage>(null);
  const [expandedCategory, setExpandedCategory] = useState<Category>(null);

  const loadData = useCallback(async () => {
    try {
      const [s, years, periodsData] = await Promise.all([loadSettings(), fetchSchoolYears(), fetchPeriods()]);
      setSettings(s);
      setSchoolYears(years);
      setPeriods(periodsData);
    } catch (e) {
      // use defaults
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e) {
      // ignore
    } finally { setSaving(false); }
  };

  const handlePeriodSaved = () => {
    setShowPeriodModal(false);
    setEditingPeriod(null);
    loadData();
  };

  const handleDeletePeriod = async (periodId: string) => {
    try {
      await deletePeriod(periodId);
      setConfirmDeletePeriod(null);
      loadData();
    } catch (e) { /* ignore */ }
  };

  if (loading) return <LoadingView />;

  const update = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => { setSettings({ ...settings, [key]: value }); };

  // Sub-pages
  if (subPage === 'history') return <HistorySubPage onBack={() => setSubPage(null)} />;
  if (subPage === 'journal') return <JournalSubPage onBack={() => setSubPage(null)} />;
  if (subPage === 'trash') return <TrashSubPage onBack={() => setSubPage(null)} />;

  const toggleCategory = (cat: Category) => setExpandedCategory(expandedCategory === cat ? null : cat);

  const categories: { key: Category; icon: React.ReactNode; title: string; subtitle: string; color: string; bg: string }[] = [
    { key: 'profile', icon: <User size={22} color={colors.primary} />, title: 'Profil du professeur', subtitle: 'Nom, contact, centre, logo', color: colors.onPrimaryContainer, bg: colors.primaryContainer },
    { key: 'years', icon: <GraduationCap size={22} color={colors.secondary} />, title: 'Années scolaires', subtitle: 'Gérer les années et l\'année actuelle', color: colors.onSecondaryContainer, bg: colors.secondaryContainer },
    { key: 'periods', icon: <CalendarClock size={22} color={colors.warning} />, title: 'Périodes', subtitle: 'Créer et gérer les périodes', color: colors.onWarningContainer, bg: colors.warningContainer },
    { key: 'share', icon: <Building2 size={22} color={colors.primary} />, title: 'Part de l\'établissement', subtitle: 'Pourcentage ou montant fixe', color: colors.onPrimaryContainer, bg: colors.primaryContainer },
    { key: 'data', icon: <History size={22} color={colors.secondary} />, title: 'Données et historique', subtitle: 'Historique, journal, corbeille', color: colors.onSecondaryContainer, bg: colors.secondaryContainer },
    { key: 'theme', icon: <Palette size={22} color={colors.primary} />, title: 'Apparence', subtitle: 'Thème clair, sombre ou système', color: colors.onPrimaryContainer, bg: colors.primaryContainer },
    { key: 'security', icon: <Shield size={22} color={colors.error} />, title: 'Sécurité', subtitle: 'Mot de passe et verrouillage', color: colors.onErrorContainer, bg: colors.errorContainer },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Paramètres" />
      <ScrollView contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}>
        {/* Category buttons */}
        <View style={{ gap: spacing.sm, marginTop: spacing.sm }}>
          {categories.map((cat) => (
            <View key={cat.key}>
              <Pressable
                onPress={() => toggleCategory(cat.key)}
                style={({ pressed }) => [styles.categoryBtn, { backgroundColor: cat.bg, opacity: pressed ? 0.85 : 1 }]}
              >
                <View style={styles.categoryIcon}>{cat.icon}</View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.categoryTitle, { color: cat.color }]}>{cat.title}</Text>
                  <Text style={[styles.categorySub, { color: cat.color, opacity: 0.7 }]}>{cat.subtitle}</Text>
                </View>
                {expandedCategory === cat.key
                  ? <ChevronDown size={20} color={cat.color} />
                  : <ChevronRight size={20} color={cat.color} />}
              </Pressable>

              {/* Expanded content */}
              {expandedCategory === cat.key ? (
                <Card elevation={1} style={{ marginTop: 4, marginBottom: 4 }}>
                  {cat.key === 'profile' && (
                    <View>
                      <View style={{ flexDirection: 'row', gap: spacing.sm }}>
                        <View style={{ flex: 1 }}>
                          <FieldInput label="Nom" value={settings.professor_name} onChangeText={(v) => update('professor_name', v)} placeholder="Nom" />
                        </View>
                        <View style={{ flex: 1 }}>
                          <FieldInput label="Prénom" value={settings.professor_first_name} onChangeText={(v) => update('professor_first_name', v)} placeholder="Prénom" />
                        </View>
                      </View>
                      <FieldInput label="Téléphone" value={settings.professor_phone} onChangeText={(v) => update('professor_phone', v)} placeholder="06 12 34 56 78" keyboardType="numeric" icon={<Phone size={16} color={colors.onSurfaceVariant} />} />
                      <FieldInput label="E-mail" value={settings.professor_email} onChangeText={(v) => update('professor_email', v)} placeholder="email@exemple.com" icon={<Mail size={16} color={colors.onSurfaceVariant} />} />
                      <FieldInput label="Centre" value={settings.professor_center} onChangeText={(v) => update('professor_center', v)} placeholder="Nom du centre" icon={<Building2 size={16} color={colors.onSurfaceVariant} />} />
                      <FieldInput label="Adresse" value={settings.professor_address} onChangeText={(v) => update('professor_address', v)} placeholder="Adresse complète" icon={<MapPin size={16} color={colors.onSurfaceVariant} />} multiline />
                      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Logo</Text>
                      <Pressable style={[styles.imagePicker, { backgroundColor: colors.surfaceVariant, borderColor: colors.outline, borderRadius: radius.md }]} onPress={() => update('professor_logo', settings.professor_logo ? null : 'placeholder_logo')}>
                        <ImageIcon size={20} color={colors.onSurfaceVariant} />
                        <Text style={[styles.imagePickerText, { color: colors.onSurfaceVariant }]}>{settings.professor_logo ? 'Logo configuré (toucher pour retirer)' : 'Ajouter un logo'}</Text>
                      </Pressable>
                      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Signature</Text>
                      <Pressable style={[styles.imagePicker, { backgroundColor: colors.surfaceVariant, borderColor: colors.outline, borderRadius: radius.md }]} onPress={() => update('professor_signature', settings.professor_signature ? null : 'placeholder_signature')}>
                        <PenTool size={20} color={colors.onSurfaceVariant} />
                        <Text style={[styles.imagePickerText, { color: colors.onSurfaceVariant }]}>{settings.professor_signature ? 'Signature configurée (toucher pour retirer)' : 'Ajouter une signature'}</Text>
                      </Pressable>
                    </View>
                  )}

                  {cat.key === 'years' && (
                    <View>
                      <Text style={[styles.periodHint, { color: colors.onSurfaceVariant, marginBottom: spacing.sm }]}>
                        Chaque année possède ses propres élèves, paiements, dettes et périodes. Sélectionnez l'année actuelle en la touchant.
                      </Text>
                      {schoolYears.map((year) => (
                        <Pressable key={year.id} onPress={() => update('current_school_year_id', year.id)} style={[styles.yearRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                          <View>
                            <Text style={[styles.yearName, { color: colors.onSurface }]}>{year.name}</Text>
                            <Text style={[styles.yearDates, { color: colors.onSurfaceVariant }]}>{formatDate(year.start_date)} → {formatDate(year.end_date)}</Text>
                          </View>
                          {settings.current_school_year_id === year.id ? (
                            <View style={[styles.currentBadge, { backgroundColor: colors.primaryContainer }]}><Text style={[styles.currentText, { color: colors.onPrimaryContainer }]}>Actuelle</Text></View>
                          ) : null}
                        </Pressable>
                      ))}
                      <Button label="Nouvelle année scolaire" variant="tonal" size="sm" onPress={() => setShowYearModal(true)} style={{ marginTop: spacing.sm }} icon={<Plus size={16} color={colors.onPrimaryContainer} />} />
                    </View>
                  )}

                  {cat.key === 'periods' && (
                    <View>
                      <Text style={[styles.periodHint, { color: colors.onSurfaceVariant }]}>
                        Gérez les périodes ici. La clôture se fait depuis l'onglet Comptabilité.
                      </Text>
                      <Button label="Nouvelle période" variant="tonal" size="sm" onPress={() => setShowPeriodModal(true)} style={{ marginTop: spacing.sm }} icon={<Plus size={16} color={colors.onPrimaryContainer} />} />
                      {periods.length === 0 ? (
                        <Text style={[styles.emptyText, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Aucune période créée</Text>
                      ) : (
                        <View style={{ marginTop: spacing.sm }}>
                          {periods.map((p) => (
                            <View key={p.id} style={[styles.periodRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                              <View style={{ flex: 1 }}>
                                <View style={styles.periodHeader}>
                                  <Text style={[styles.periodName, { color: colors.onSurface }]}>{p.name}</Text>
                                  <View style={[styles.statusPill, { backgroundColor: p.is_closed ? colors.successContainer : colors.warningContainer }]}>
                                    <Text style={[styles.statusPillText, { color: p.is_closed ? colors.onSuccessContainer : colors.onWarningContainer }]}>
                                      {p.is_closed ? 'Clôturée' : 'Ouverte'}
                                    </Text>
                                  </View>
                                </View>
                                <Text style={[styles.periodDates, { color: colors.onSurfaceVariant }]}>
                                  {formatDate(p.start_date)} → {formatDate(p.end_date)}
                                </Text>
                                {p.is_closed ? (
                                  <View style={styles.periodStats}>
                                    <StatChip label="Revenu" value={formatCurrency(p.total_revenue)} color={colors.onSurface} bg={colors.surfaceVariant} />
                                    <StatChip label="Professeur" value={formatCurrency(p.professor_share)} color={colors.onSuccessContainer} bg={colors.successContainer} />
                                    <StatChip label="Établissement" value={formatCurrency(p.creche_share)} color={colors.onPrimaryContainer} bg={colors.primaryContainer} />
                                    <StatChip label="Dettes" value={formatCurrency(p.total_debt)} color={colors.onErrorContainer} bg={colors.errorContainer} />
                                  </View>
                                ) : null}
                                <View style={styles.periodActions}>
                                  <Button label="Modifier" size="sm" variant="outlined" onPress={() => setEditingPeriod(p)} icon={<Pencil size={14} color={colors.primary} />} />
                                  <Button label="Supprimer" size="sm" variant="text" onPress={() => setConfirmDeletePeriod(p)} icon={<Trash2 size={14} color={colors.error} />} />
                                </View>
                              </View>
                            </View>
                          ))}
                        </View>
                      )}
                    </View>
                  )}

                  {cat.key === 'share' && (
                    <View>
                      <View style={styles.switchRow}>
                        <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Type</Text>
                        <View style={{ flexDirection: 'row', gap: 8 }}>
                          <Pressable onPress={() => update('room_share_type', 'percentage')} style={[styles.typePill, { backgroundColor: settings.room_share_type === 'percentage' ? colors.primary : colors.surfaceVariant }]}>
                            <Text style={{ color: settings.room_share_type === 'percentage' ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 13, fontWeight: '600' }}>%</Text>
                          </Pressable>
                          <Pressable onPress={() => update('room_share_type', 'fixed')} style={[styles.typePill, { backgroundColor: settings.room_share_type === 'fixed' ? colors.primary : colors.surfaceVariant }]}>
                            <Text style={{ color: settings.room_share_type === 'fixed' ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 13, fontWeight: '600' }}>Fixe</Text>
                          </Pressable>
                        </View>
                      </View>
                      <FieldInput
                        label={settings.room_share_type === 'percentage' ? 'Pourcentage (%)' : 'Montant fixe (DZD)'}
                        value={String(settings.room_share_rate)}
                        onChangeText={(v) => update('room_share_rate', parseFloat(v) || 0)}
                        placeholder="20"
                        keyboardType="numeric"
                      />
                    </View>
                  )}

                  {cat.key === 'data' && (
                    <View>
                      <SubPageRow icon={<History size={18} color={colors.primary} />} label="Historique quotidien" subtitle="Encaissements par journée" onPress={() => setSubPage('history')} colors={colors} />
                      <SubPageRow icon={<Activity size={18} color={colors.primary} />} label="Journal des opérations" subtitle="Historique chronologique" onPress={() => setSubPage('journal')} colors={colors} />
                      <SubPageRow icon={<Trash size={18} color={colors.error} />} label="Corbeille" subtitle="Élèves supprimés" onPress={() => setSubPage('trash')} colors={colors} />
                    </View>
                  )}

                  {cat.key === 'theme' && (
                    <View style={styles.themeRow}>
                      <ThemeOption icon={<Sun size={20} color={colors.onSurface} />} label="Clair" active={mode === 'light'} onPress={() => setMode('light')} colors={colors} />
                      <ThemeOption icon={<Moon size={20} color={colors.onSurface} />} label="Sombre" active={mode === 'dark'} onPress={() => setMode('dark')} colors={colors} />
                      <ThemeOption icon={<Monitor size={20} color={colors.onSurface} />} label="Système" active={mode === 'system'} onPress={() => setMode('system')} colors={colors} />
                    </View>
                  )}

                  {cat.key === 'security' && (
                    <View>
                      <View style={styles.switchRow}>
                        <Text style={[styles.fieldLabel, { color: colors.onSurface }]}>Protection par mot de passe</Text>
                        <Switch value={settings.app_lock_enabled} onValueChange={(v) => update('app_lock_enabled', v)} trackColor={{ false: colors.outline, true: colors.primary }} />
                      </View>
                      {settings.app_lock_enabled ? (
                        <FieldInput label="Mot de passe" value={settings.app_password ?? ''} onChangeText={(v) => update('app_password', v)} placeholder="Mot de passe" secureTextEntry />
                      ) : null}
                    </View>
                  )}
                </Card>
              ) : null}
            </View>
          ))}
        </View>

        {/* Save */}
        <View style={{ marginTop: spacing.lg }}>
          <Button label={saved ? 'Enregistré' : 'Enregistrer les paramètres'} variant="filled" size="lg" onPress={handleSave} disabled={saving} icon={saved ? <Check size={18} color={colors.onPrimary} /> : undefined} />
        </View>
      </ScrollView>

      <AddPeriodModal
        visible={showPeriodModal}
        onClose={() => setShowPeriodModal(false)}
        schoolYearId={settings.current_school_year_id}
        onSaved={handlePeriodSaved}
      />

      {editingPeriod ? (
        <EditPeriodModal
          period={editingPeriod}
          onClose={() => setEditingPeriod(null)}
          onSaved={handlePeriodSaved}
        />
      ) : null}

      <NewYearModal
        visible={showYearModal}
        onClose={() => setShowYearModal(false)}
        currentYearId={settings.current_school_year_id}
        onCreated={(newYearId) => { setShowYearModal(false); setSettings({ ...settings, current_school_year_id: newYearId }); loadData(); }}
      />

      <ConfirmDialog
        visible={!!confirmDeletePeriod}
        title="Supprimer la période"
        message={confirmDeletePeriod?.is_closed ? 'Cette période est clôturée. Êtes-vous sûr de vouloir la supprimer ? Les données figées seront perdues.' : 'Êtes-vous sûr de vouloir supprimer cette période ?'}
        confirmLabel="Supprimer"
        danger
        onConfirm={() => confirmDeletePeriod && handleDeletePeriod(confirmDeletePeriod.id)}
        onCancel={() => setConfirmDeletePeriod(null)}
      />
    </View>
  );
}

function SubPageRow({ icon, label, subtitle, onPress, colors }: {
  icon: React.ReactNode; label: string; subtitle: string; onPress: () => void; colors: ReturnType<typeof useTheme>['colors'];
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.subPageRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth, opacity: pressed ? 0.7 : 1 }]}>
      {icon}
      <View style={{ flex: 1 }}>
        <Text style={[styles.subPageLabel, { color: colors.onSurface }]}>{label}</Text>
        <Text style={[styles.subPageSub, { color: colors.onSurfaceVariant }]}>{subtitle}</Text>
      </View>
      <ChevronRight size={18} color={colors.onSurfaceVariant} />
    </Pressable>
  );
}

function HistorySubPage({ onBack }: { onBack: () => void }) {
  const { colors, spacing } = useTheme();
  const [days, setDays] = useState<{ date: string; collected: number; professorShare: number; establishmentShare: number; paymentCount: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const [payments, s] = await Promise.all([fetchAllPayments(), loadSettings()]);
      const byDay = new Map<string, PaymentWithStudent[]>();
      for (const p of payments) {
        const dayKey = (p.payment_date ?? p.created_at.slice(0, 10));
        if (!byDay.has(dayKey)) byDay.set(dayKey, []);
        byDay.get(dayKey)!.push(p);
      }
      const summaries: typeof days = [];
      byDay.forEach((dayPayments, date) => {
        const collected = dayPayments.reduce((sum, p) => sum + (Number(p.amount_paid) || 0), 0);
        const establishmentShare = s.room_share_type === 'percentage'
          ? collected * (s.room_share_rate / 100)
          : Math.min(s.room_share_rate * dayPayments.length, collected);
        summaries.push({ date, collected, professorShare: collected - establishmentShare, establishmentShare, paymentCount: dayPayments.length });
      });
      summaries.sort((a, b) => b.date.localeCompare(a.date));
      setDays(summaries);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  if (loading) return <LoadingView />;
  if (error) return <ErrorView message={error} />;

  const totalCollected = days.reduce((s, d) => s + d.collected, 0);
  const totalProfessor = days.reduce((s, d) => s + d.professorShare, 0);
  const totalEstablishment = days.reduce((s, d) => s + d.establishmentShare, 0);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: spacing.lg, paddingTop: spacing.sm, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable onPress={onBack}><X size={24} color={colors.onSurface} /></Pressable>
        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.onSurface }}>Historique quotidien</Text>
      </View>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
      >
        <Card elevation={2} style={{ marginTop: spacing.sm }}>
          <Text style={[styles.summaryTitle, { color: colors.onSurface }]}>Cumul total</Text>
          <View style={styles.summaryRow}><Banknote size={18} color={colors.success} /><Text style={[styles.summaryLabel, { color: colors.onSurfaceVariant }]}>Encaissements</Text><Text style={[styles.summaryValue, { color: colors.success }]}>{formatCurrency(totalCollected)}</Text></View>
          <View style={[styles.summaryRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}><User size={18} color={colors.primary} /><Text style={[styles.summaryLabel, { color: colors.onSurfaceVariant }]}>Professeur</Text><Text style={[styles.summaryValue, { color: colors.primary }]}>{formatCurrency(totalProfessor)}</Text></View>
          <View style={[styles.summaryRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}><Building2 size={18} color={colors.warning} /><Text style={[styles.summaryLabel, { color: colors.onSurfaceVariant }]}>Établissement</Text><Text style={[styles.summaryValue, { color: colors.warning }]}>{formatCurrency(totalEstablishment)}</Text></View>
        </Card>
        {days.length === 0 ? (
          <Text style={{ color: colors.onSurfaceVariant, marginTop: spacing.lg, textAlign: 'center', fontSize: 14 }}>Aucun encaissement enregistré</Text>
        ) : (
          days.map((d, i) => (
            <Card key={i} elevation={1} style={{ marginTop: spacing.sm }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <CalendarClock size={16} color={colors.primary} />
                <Text style={{ fontSize: 15, fontWeight: '700', color: colors.onSurface, flex: 1 }}>{formatDate(d.date)}</Text>
                <View style={{ backgroundColor: colors.primaryContainer, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999 }}><Text style={{ fontSize: 11, fontWeight: '600', color: colors.onPrimaryContainer }}>{d.paymentCount} p.</Text></View>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, gap: 10 }}><TrendingUp size={16} color={colors.success} /><Text style={{ flex: 1, fontSize: 13, fontWeight: '500', color: colors.onSurfaceVariant }}>Encaissé</Text><Text style={{ fontSize: 14, fontWeight: '700', color: colors.success }}>{formatCurrency(d.collected)}</Text></View>
              <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, gap: 10, borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }}><User size={16} color={colors.primary} /><Text style={{ flex: 1, fontSize: 13, fontWeight: '500', color: colors.onSurfaceVariant }}>Professeur</Text><Text style={{ fontSize: 14, fontWeight: '700', color: colors.primary }}>{formatCurrency(d.professorShare)}</Text></View>
              <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, gap: 10, borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }}><Building2 size={16} color={colors.warning} /><Text style={{ flex: 1, fontSize: 13, fontWeight: '500', color: colors.onSurfaceVariant }}>Établissement</Text><Text style={{ fontSize: 14, fontWeight: '700', color: colors.warning }}>{formatCurrency(d.establishmentShare)}</Text></View>
            </Card>
          ))
        )}
      </ScrollView>
    </View>
  );
}

function JournalSubPage({ onBack }: { onBack: () => void }) {
  const { colors, spacing } = useTheme();
  const [operations, setOperations] = useState<OperationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const ops = await fetchOperations(300);
      setOperations(ops);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  if (loading) return <LoadingView />;
  if (error) return <ErrorView message={error} />;

  let lastDate = '';
  const opConfig: Record<OperationType, { icon: React.ReactNode; label: string }> = {
    payment: { icon: <Banknote size={16} color="#16A34A" />, label: 'Paiement' },
    reenrollment: { icon: <RefreshCw size={16} color="#2563EB" />, label: 'Réinscription' },
    regularization: { icon: <TrendingUp size={16} color="#CA8A04" />, label: 'Régularisation' },
    modification: { icon: <Pencil size={16} color="#64748B" />, label: 'Modification' },
    deletion: { icon: <Trash2 size={16} color="#DC2626" />, label: 'Suppression' },
    creation: { icon: <UserPlus size={16} color="#2563EB" />, label: 'Création' },
    session_increment: { icon: <CalendarClock size={16} color="#0891B2" />, label: 'Séance' },
    period_close: { icon: <Lock size={16} color="#7C3AED" />, label: 'Clôture période' },
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: spacing.lg, paddingTop: spacing.sm, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable onPress={onBack}><X size={24} color={colors.onSurface} /></Pressable>
        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.onSurface }}>Journal des opérations</Text>
      </View>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
      >
        {operations.length === 0 ? (
          <View style={{ alignItems: 'center', marginTop: spacing.xxl }}>
            <Activity size={32} color={colors.onSurfaceVariant} />
            <Text style={{ color: colors.onSurfaceVariant, marginTop: 12, fontSize: 14 }}>Aucune opération enregistrée</Text>
          </View>
        ) : (
          operations.map((op) => {
            const opDate = op.created_at.slice(0, 10);
            const showDateHeader = opDate !== lastDate;
            lastDate = opDate;
            const cfg = opConfig[op.operation_type] ?? opConfig.modification;
            return (
              <View key={op.id}>
                {showDateHeader ? <Text style={{ fontSize: 13, fontWeight: '700', color: colors.onSurfaceVariant, marginTop: 16, marginBottom: 4 }}>{formatDate(opDate)}</Text> : null}
                <Card elevation={1} style={{ marginTop: 6 }}>
                  <View style={{ flexDirection: 'row', gap: 12 }}>
                    <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceVariant, alignItems: 'center', justifyContent: 'center' }}>{cfg.icon}</View>
                    <View style={{ flex: 1 }}>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Text style={{ fontSize: 14, fontWeight: '600', color: colors.onSurface }}>{cfg.label}</Text>
                        <Text style={{ fontSize: 12, fontWeight: '500', color: colors.onSurfaceVariant }}>{new Date(op.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</Text>
                      </View>
                      {op.student_name ? <Text style={{ fontSize: 13, marginTop: 2, color: colors.onSurfaceVariant }}>{op.student_name}</Text> : null}
                      {op.description ? <Text style={{ fontSize: 12, marginTop: 2, color: colors.onSurfaceVariant }}>{op.description}</Text> : null}
                      {op.amount > 0 ? <Text style={{ fontSize: 14, fontWeight: '700', marginTop: 4, color: colors.success }}>{formatCurrency(op.amount)}</Text> : null}
                    </View>
                  </View>
                </Card>
              </View>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}

function TrashSubPage({ onBack }: { onBack: () => void }) {
  const { colors, spacing } = useTheme();
  const [students, setStudents] = useState<StudentWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const data = await fetchStudents({ status: 'trashed' });
      setStudents(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur de chargement');
    } finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRestore = async (id: string) => {
    try { await setStudentStatus(id, 'active'); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };
  const handlePermanentDelete = async () => {
    if (!confirmDelete) return;
    try { await permanentlyDeleteStudent(confirmDelete); setConfirmDelete(null); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };

  if (loading) return <LoadingView />;
  if (error) return <ErrorView message={error} />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: spacing.lg, paddingTop: spacing.sm, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable onPress={onBack}><X size={24} color={colors.onSurface} /></Pressable>
        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.onSurface }}>Corbeille</Text>
        <Text style={{ fontSize: 14, color: colors.onSurfaceVariant }}>{students.length} élève(s)</Text>
      </View>
      <FlatList
        data={students}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
        ListEmptyComponent={<EmptyState title="Corbeille vide" message="Les élèves supprimés apparaîtront ici" icon={<Trash size={32} color={colors.onSurfaceVariant} />} />}
        renderItem={({ item }) => (
          <Card elevation={1} style={{ marginBottom: spacing.sm }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <StudentAvatar fullName={item.full_name} size={40} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontWeight: '600', color: getGenderColor(item.gender) }} numberOfLines={1}>{item.full_name}</Text>
                <Text style={{ fontSize: 12, marginTop: 2, color: colors.onSurfaceVariant }}>{item.level?.name ?? 'Sans niveau'}</Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 8, gap: 4 }}>
              <Button label="Restaurer" size="sm" variant="tonal" onPress={() => handleRestore(item.id)} />
              <Button label="Supprimer définitivement" size="sm" variant="text" onPress={() => setConfirmDelete(item.id)} />
            </View>
          </Card>
        )}
      />
      <ConfirmDialog
        visible={confirmDelete !== null}
        title="Suppression définitive"
        message="Cette action est irréversible. L'élève et tout son historique seront définitivement supprimés."
        confirmLabel="Supprimer"
        danger
        onConfirm={handlePermanentDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </View>
  );
}

function StatChip({ label, value, color, bg }: { label: string; value: string; color: string; bg: string }) {
  return (
    <View style={[styles.statChip, { backgroundColor: bg }]}>
      <Text style={[styles.statChipLabel, { color }]}>{label}</Text>
      <Text style={[styles.statChipValue, { color }]}>{value}</Text>
    </View>
  );
}

function FieldInput({ label, value, onChangeText, placeholder, multiline, keyboardType, secureTextEntry, icon }: {
  label: string; value: string; onChangeText: (v: string) => void; placeholder?: string; multiline?: boolean; keyboardType?: 'default' | 'numeric'; secureTextEntry?: boolean; icon?: React.ReactNode;
}) {
  const { colors, radius, spacing } = useTheme();
  return (
    <View style={{ marginTop: spacing.sm }}>
      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <View style={[styles.inputRow, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, paddingHorizontal: spacing.md }]}>
        {icon}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.onSurfaceVariant}
          multiline={multiline}
          keyboardType={keyboardType ?? 'default'}
          secureTextEntry={secureTextEntry}
          style={[styles.input, { color: colors.onSurface }, multiline && { minHeight: 60, textAlignVertical: 'top', paddingTop: spacing.sm }]}
        />
      </View>
    </View>
  );
}

function ThemeOption({ icon, label, active, onPress, colors }: {
  icon: React.ReactNode; label: string; active: boolean; onPress: () => void; colors: ReturnType<typeof useTheme>['colors'];
}) {
  return (
    <Pressable onPress={onPress} style={[styles.themeOption, { backgroundColor: active ? colors.primaryContainer : colors.surfaceVariant, borderColor: active ? colors.primary : 'transparent' }]}>
      {icon}
      <Text style={[styles.themeOptionText, { color: active ? colors.onPrimaryContainer : colors.onSurfaceVariant }]}>{label}</Text>
    </Pressable>
  );
}

interface AddPeriodModalProps {
  visible: boolean;
  onClose: () => void;
  schoolYearId: string | null;
  onSaved: () => void;
}

function AddPeriodModal({ visible, onClose, schoolYearId, onSaved }: AddPeriodModalProps) {
  const { colors, spacing, radius } = useTheme();
  const [startDate, setStartDate] = useState(todayISO());
  const [endDate, setEndDate] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const reset = () => { setStartDate(todayISO()); setEndDate(''); setErr(null); };

  const handleSave = async () => {
    if (!startDate || !endDate) { setErr('Sélectionnez les dates de début et de fin'); return; }
    setSaving(true); setErr(null);
    try {
      await createPeriod({ start_date: startDate, end_date: endDate, school_year_id: schoolYearId });
      reset(); onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Nouvelle période</Text>
            <Pressable onPress={() => { reset(); onClose(); }}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginBottom: spacing.sm }]}>Le nom est attribué automatiquement (Période 1, 2, 3...)</Text>
            <DatePickerField label="Date de début *" value={startDate} onChange={setStartDate} placeholder="Sélectionner" />
            <DatePickerField label="Date de fin *" value={endDate} onChange={setEndDate} placeholder="Sélectionner" />
          </ScrollView>
          {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={() => { reset(); onClose(); }} style={{ flex: 1 }} />
            <Button label={saving ? '...' : 'Créer'} variant="filled" onPress={handleSave} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function EditPeriodModal({ period, onClose, onSaved }: { period: Period; onClose: () => void; onSaved: () => void }) {
  const { colors, spacing, radius } = useTheme();
  const [startDate, setStartDate] = useState(period.start_date);
  const [endDate, setEndDate] = useState(period.end_date);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [confirmEdit, setConfirmEdit] = useState(false);
  const [paymentCount, setPaymentCount] = useState<number | null>(null);
  const [pinStep, setPinStep] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);

  useEffect(() => {
    countPaymentsForPeriod(period.id).then(setPaymentCount).catch(() => setPaymentCount(0));
  }, [period.id]);

  const handleSave = async () => {
    if (!startDate || !endDate) { setErr('Sélectionnez les dates'); return; }
    if ((paymentCount ?? 0) > 0 && !confirmEdit) { setConfirmEdit(true); return; }
    if (period.is_closed && !pinStep) { setPinStep(true); return; }
    if (period.is_closed && pinStep) {
      const settings = await loadSettings();
      if (!settings.app_password || settings.app_password.trim() === '') {
        setPinError('Aucun code PIN configuré. Créez-en un dans les Paramètres > Sécurité.');
        return;
      }
      if (pinInput !== settings.app_password) { setPinError('Code PIN incorrect'); return; }
    }
    setSaving(true); setErr(null);
    try {
      await updatePeriod(period.id, { start_date: startDate, end_date: endDate });
      onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Modifier la période</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginBottom: spacing.sm }]}>{period.name} — le nom est attribué automatiquement</Text>
            <DatePickerField label="Date de début *" value={startDate} onChange={setStartDate} placeholder="Sélectionner" />
            <DatePickerField label="Date de fin *" value={endDate} onChange={setEndDate} placeholder="Sélectionner" />
            {confirmEdit ? (
              <View style={{ backgroundColor: period.is_closed ? colors.errorContainer : colors.warningContainer, borderRadius: radius.md, marginTop: spacing.sm, padding: spacing.md }}>
                <Text style={{ fontSize: 13, color: period.is_closed ? colors.onErrorContainer : colors.onWarningContainer }}>
                  {period.is_closed
                    ? 'Cette période est clôturée. La modification peut affecter les rapports. Confirmez-vous ?'
                    : `Cette période contient ${paymentCount} paiement(s). La modification peut affecter les calculs. Confirmez-vous ?`}
                </Text>
              </View>
            ) : null}
            {pinStep ? (
              <View style={{ marginTop: spacing.sm }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: colors.onSurface, marginBottom: 8 }}>Entrez le code PIN pour modifier une période clôturée</Text>
                <TextInput
                  value={pinInput}
                  onChangeText={setPinInput}
                  placeholder="Code PIN"
                  placeholderTextColor={colors.onSurfaceVariant}
                  keyboardType="numeric"
                  secureTextEntry
                  style={{ backgroundColor: colors.surfaceVariant, borderRadius: 12, paddingHorizontal: 16, height: 48, fontSize: 16, color: colors.onSurface, textAlign: 'center', letterSpacing: 4 }}
                />
                {pinError ? <Text style={{ fontSize: 13, color: colors.error, marginTop: 8, textAlign: 'center' }}>{pinError}</Text> : null}
              </View>
            ) : null}
          </ScrollView>
          {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label={saving ? '...' : pinStep ? 'Confirmer' : confirmEdit ? 'Confirmer' : 'Enregistrer'} variant="filled" onPress={handleSave} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function NewYearModal({ visible, onClose, currentYearId, onCreated }: {
  visible: boolean; onClose: () => void; currentYearId: string | null; onCreated: (newYearId: string) => void;
}) {
  const { colors, spacing, radius } = useTheme();
  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState(todayISO());
  const [endDate, setEndDate] = useState('');
  const [carryOver, setCarryOver] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const reset = () => { setName(''); setStartDate(todayISO()); setEndDate(''); setCarryOver(false); setErr(null); };

  const handleCreate = async () => {
    if (!name.trim()) { setErr('Donnez un nom à l\'année'); return; }
    if (!startDate || !endDate) { setErr('Sélectionnez les dates'); return; }
    setSaving(true); setErr(null);
    try {
      const newYear = await createSchoolYear({ name: name.trim(), start_date: startDate, end_date: endDate, is_current: true });
      if (carryOver && currentYearId) {
        await carryOverActiveStudents(currentYearId, newYear.id);
      }
      reset();
      onCreated(newYear.id);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Nouvelle année scolaire</Text>
            <Pressable onPress={() => { reset(); onClose(); }}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <FieldInput label="Nom de l'année *" value={name} onChangeText={setName} placeholder="Ex: 2027-2028" />
            <DatePickerField label="Date de début *" value={startDate} onChange={setStartDate} placeholder="Sélectionner" />
            <DatePickerField label="Date de fin *" value={endDate} onChange={setEndDate} placeholder="Sélectionner" />
            <Pressable onPress={() => setCarryOver(!carryOver)} style={[styles.carryOverRow, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, marginTop: spacing.sm }]}>
              <Switch value={carryOver} onValueChange={setCarryOver} trackColor={{ false: colors.outline, true: colors.primary }} />
              <View style={{ flex: 1, marginLeft: spacing.sm }}>
                <Text style={[styles.fieldLabel, { color: colors.onSurface, marginBottom: 2 }]}>Reporter les élèves actifs</Text>
                <Text style={{ fontSize: 12, color: colors.onSurfaceVariant }}>Copie les élèves actifs de l'année actuelle vers la nouvelle</Text>
              </View>
            </Pressable>
          </ScrollView>
          {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={() => { reset(); onClose(); }} style={{ flex: 1 }} />
            <Button label={saving ? '...' : 'Créer'} variant="filled" onPress={handleCreate} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  categoryBtn: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 16, paddingVertical: 16, borderRadius: 16 },
  categoryIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.3)', alignItems: 'center', justifyContent: 'center' },
  categoryTitle: { fontSize: 16, fontWeight: '700' },
  categorySub: { fontSize: 12, marginTop: 2 },
  fieldLabel: { fontSize: 13, fontWeight: '500', marginBottom: 6 },
  inputRow: { flexDirection: 'row', alignItems: 'center', gap: 8, height: 48 },
  input: { flex: 1, fontSize: 15 },
  yearRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, marginTop: 4 },
  yearName: { fontSize: 15, fontWeight: '500' },
  yearDates: { fontSize: 12, marginTop: 2 },
  currentBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  currentText: { fontSize: 12, fontWeight: '600' },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 },
  typePill: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 999 },
  themeRow: { flexDirection: 'row', gap: 8 },
  themeOption: { flex: 1, alignItems: 'center', paddingVertical: 16, borderRadius: 12, borderWidth: 2, gap: 6 },
  themeOptionText: { fontSize: 13, fontWeight: '600' },
  periodHint: { fontSize: 13, lineHeight: 19 },
  emptyText: { fontSize: 14 },
  periodRow: { paddingVertical: 14, marginTop: 4 },
  periodHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  periodName: { fontSize: 15, fontWeight: '700' },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusPillText: { fontSize: 11, fontWeight: '600' },
  periodDates: { fontSize: 12, marginTop: 4 },
  periodStats: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  statChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  statChipLabel: { fontSize: 10, fontWeight: '500' },
  statChipValue: { fontSize: 13, fontWeight: '700', marginTop: 2 },
  periodActions: { flexDirection: 'row', gap: 8, marginTop: 8, flexWrap: 'wrap' },
  imagePicker: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 16, borderWidth: StyleSheet.hairlineWidth },
  imagePickerText: { fontSize: 14, fontWeight: '500' },
  carryOverRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  addModal: { width: '100%', maxWidth: 400 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '700' },
  errText: { fontSize: 13, marginTop: 8, textAlign: 'center' },
  modalActions: { flexDirection: 'row', marginTop: 16 },
  subPageRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, marginTop: 4 },
  subPageLabel: { fontSize: 15, fontWeight: '600' },
  subPageSub: { fontSize: 12, marginTop: 2 },
  summaryTitle: { fontSize: 16, fontWeight: '700', marginBottom: 10 },
  summaryRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 10 },
  summaryLabel: { flex: 1, fontSize: 14, fontWeight: '500' },
  summaryValue: { fontSize: 16, fontWeight: '700' },
});
