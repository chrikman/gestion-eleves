import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, RefreshControl, Pressable, Modal } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { ScreenHeader, LoadingView, ErrorView } from '@/components/ScreenHeader';
import { StatCard } from '@/components/StatCard';
import { Card } from '@/components/Card';
import { StudentAvatar } from '@/components/StudentAvatar';
import { fetchStudents, type StudentWithRelations } from '@/services/studentService';
import { fetchAllPayments } from '@/services/paymentService';
import { fetchLevels } from '@/services/levelService';
import { loadSettings } from '@/services/settingsService';
import { fetchPeriods } from '@/services/periodService';
import { formatCurrency, formatDate, todayISO, addDays, getGenderColor } from '@/utils/format';
import { Users, UserCheck, UserX, CheckCircle2, AlertCircle, Banknote, TrendingDown, Building2, CalendarClock, TrendingUp, Wallet, Clock, ChevronRight, X } from 'lucide-react-native';
import type { AppSettings, Period, Student, Payment, Level } from '@/types';
import { useRouter } from 'expo-router';

interface DashboardStats {
  totalStudents: number;
  activeStudents: number;
  suspendedStudents: number;
  paidStudents: number;
  lateStudents: number;
  partialStudents: number;
  debtStudents: number;
  totalCollected: number;
  totalDebt: number;
  profit: number;
  roomShare: number;
  byLevel: { levelName: string; count: number; collected: number }[];
  todayCollected: number;
  todayProfessorShare: number;
  todayEstablishmentShare: number;
  endOfWeekCount: number;
  nextWeekPaymentCount: number;
  nextWeekExpectedTotal: number;
}

export default function DashboardScreen() {
  const { colors, spacing } = useTheme();
  const router = useRouter();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [alertStudents, setAlertStudents] = useState<{ title: string; students: { id: string; full_name: string; level?: string; gender: 'male' | 'female' | null }[] } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const loadStats = useCallback(async () => {
    try {
      setError(null);
      const [students, payments, levels, settings, periods] = await Promise.all([
        fetchStudents(),
        fetchAllPayments(),
        fetchLevels(),
        loadSettings(),
        fetchPeriods(),
      ]);

      const today = todayISO();

      const active = students.filter((s) => s.status === 'active');
      const suspended = students.filter((s) => s.status === 'suspended');

      const paidStudentIds = new Set(
        payments.filter((p) => p.status === 'paid' || p.status === 'single').map((p) => p.student_id),
      );
      const partialStudentIds = new Set(
        payments.filter((p) => p.status === 'partial').map((p) => p.student_id),
      );
      const debtStudentIds = new Set(
        payments.filter((p) => p.status === 'unpaid').map((p) => p.student_id),
      );
      const allActiveIds = new Set(active.map((s) => s.id));
      const lateIds = [...allActiveIds].filter((id) => !paidStudentIds.has(id));

      // Students ending period this week
      const endOfWeekStudents = active.filter((s) => {
        const studentPayments = payments.filter((p) => p.student_id === s.id && !p.is_closed);
        if (studentPayments.length === 0) return false;
        const latest = studentPayments[0];
        const endDate = new Date(latest.period_end);
        const todayDate = new Date(today);
        const diff = (endDate.getTime() - todayDate.getTime()) / (1000 * 60 * 60 * 24);
        return diff >= 0 && diff <= 7;
      });

      const lateStudents = active.filter((s) => lateIds.includes(s.id));

      // Today's payment students
      const todayPaymentStudents = students.filter((s) => {
        const studentPayments = payments.filter((p) => p.student_id === s.id);
        return studentPayments.some((p) => (p.payment_date ?? p.created_at.slice(0, 10)) === today);
      });

      setAlertStudentsMap({ endOfWeek: endOfWeekStudents, late: lateStudents, todayPayment: todayPaymentStudents });

      const totalCollected = payments.reduce((sum, p) => sum + (Number(p.amount_paid) || 0), 0);
      const totalDebt = payments
        .filter((p) => p.status !== 'paid' && p.status !== 'single')
        .reduce((sum, p) => sum + (Number(p.amount) - Number(p.amount_paid)), 0);

      const roomShare = computeRoomShare(totalCollected, settings);
      const profit = totalCollected - roomShare;

      const byLevel = levels.map((lvl) => {
        const levelStudents = active.filter((s) => s.level_id === lvl.id);
        const levelPayments = payments.filter((p) => levelStudents.some((s) => s.id === p.student_id));
        const collected = levelPayments.reduce((sum, p) => sum + (Number(p.amount_paid) || 0), 0);
        return { levelName: lvl.name, count: levelStudents.length, collected };
      });

      // Today's financial summary
      const todayPayments = payments.filter((p) => (p.payment_date ?? p.created_at.slice(0, 10)) === today);
      const todayCollected = todayPayments.reduce((sum, p) => sum + (Number(p.amount_paid) || 0), 0);
      const todayEstablishmentShare = computeRoomShare(todayCollected, settings);
      const todayProfessorShare = todayCollected - todayEstablishmentShare;

      // End of period alert: students whose period_end is within the next 7 days
      const weekEnd = addDays(today, 7);
      const endOfWeekCount = active.filter((s) => {
        const studentPayments = payments.filter((p) => p.student_id === s.id && !p.is_closed);
        if (studentPayments.length === 0) return false;
        const latest = studentPayments[0];
        const endDate = new Date(latest.period_end);
        const todayDate = new Date(today);
        const diff = (endDate.getTime() - todayDate.getTime()) / (1000 * 60 * 60 * 24);
        return diff >= 0 && diff <= 7;
      }).length;

      // Next week payment forecast: students whose period_end is within 7-14 days
      const nextWeekEnd = addDays(today, 14);
      const nextWeekPayments = payments.filter((p) => {
        if (p.status === 'paid' || p.status === 'single') return false;
        const endDate = new Date(p.period_end);
        const todayDate = new Date(today);
        const weekEndDate = new Date(nextWeekEnd);
        const weekStartDate = new Date(weekEnd);
        return endDate > weekStartDate && endDate <= weekEndDate;
      });
      const nextWeekPaymentCount = new Set(nextWeekPayments.map((p) => p.student_id)).size;
      const nextWeekExpectedTotal = nextWeekPayments.reduce((sum, p) => sum + (Number(p.amount) - Number(p.amount_paid)), 0);

      setStats({
        totalStudents: students.length,
        activeStudents: active.length,
        suspendedStudents: suspended.length,
        paidStudents: paidStudentIds.size,
        lateStudents: lateIds.length,
        partialStudents: partialStudentIds.size,
        debtStudents: debtStudentIds.size,
        totalCollected,
        totalDebt,
        profit,
        roomShare,
        byLevel,
        todayCollected,
        todayProfessorShare,
        todayEstablishmentShare,
        endOfWeekCount,
        nextWeekPaymentCount,
        nextWeekExpectedTotal,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur de chargement');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const [alertStudentsMap, setAlertStudentsMap] = useState<{ endOfWeek: StudentWithRelations[]; late: StudentWithRelations[]; todayPayment: StudentWithRelations[] }>({ endOfWeek: [], late: [], todayPayment: [] });

  if (loading && !stats) return <LoadingView />;
  if (error && !stats) return <ErrorView message={error} />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Soutien 2027" subtitle="Tableau de bord" />
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadStats(); }} />}
      >
        {/* Date and time display */}
        <Card elevation={1} style={{ marginTop: spacing.sm }}>
          <View style={[styles.dateTimeRow, { borderBottomColor: colors.divider, borderBottomWidth: StyleSheet.hairlineWidth }]}>
            <CalendarClock size={18} color={colors.primary} />
            <Text style={[styles.dateTimeLabel, { color: colors.onSurfaceVariant }]}>Date</Text>
            <Text style={[styles.dateTimeValue, { color: colors.onSurface }]}>{currentTime.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
          </View>
          <View style={styles.dateTimeRow}>
            <Clock size={18} color={colors.primary} />
            <Text style={[styles.dateTimeLabel, { color: colors.onSurfaceVariant }]}>Heure</Text>
            <Text style={[styles.dateTimeValue, { color: colors.onSurface }]}>{currentTime.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</Text>
          </View>
        </Card>

        {/* Daily financial summary */}
        <Card elevation={2} style={{ marginTop: spacing.sm }}>
          <View style={[styles.dailyHeader, { borderBottomColor: colors.divider, borderBottomWidth: StyleSheet.hairlineWidth }]}>
            <CalendarClock size={18} color={colors.primary} />
            <Text style={[styles.dailyTitle, { color: colors.onSurface }]}>Bilan financier du {formatDate(todayISO())}</Text>
          </View>
          <View style={styles.dailyRow}>
            <Banknote size={18} color={colors.success} />
            <Text style={[styles.dailyLabel, { color: colors.onSurfaceVariant }]}>Encaissements du jour</Text>
            <Text style={[styles.dailyValue, { color: colors.success }]}>{formatCurrency(stats?.todayCollected ?? 0)}</Text>
          </View>
          <View style={[styles.dailyRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Wallet size={18} color={colors.primary} />
            <Text style={[styles.dailyLabel, { color: colors.onSurfaceVariant }]}>Part du professeur</Text>
            <Text style={[styles.dailyValue, { color: colors.primary }]}>{formatCurrency(stats?.todayProfessorShare ?? 0)}</Text>
          </View>
          <View style={[styles.dailyRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Building2 size={18} color={colors.warning} />
            <Text style={[styles.dailyLabel, { color: colors.onSurfaceVariant }]}>Part de l'établissement</Text>
            <Text style={[styles.dailyValue, { color: colors.warning }]}>{formatCurrency(stats?.todayEstablishmentShare ?? 0)}</Text>
          </View>
        </Card>

        {/* Alerts — clickable */}
        <Pressable onPress={() => setAlertStudents({ title: 'Élèves terminant leur mois cette semaine', students: alertStudentsMap.endOfWeek.map((s) => ({ id: s.id, full_name: s.full_name, level: s.level?.name, gender: s.gender })) })} disabled={(stats?.endOfWeekCount ?? 0) === 0}>
          {(stats?.endOfWeekCount ?? 0) > 0 ? (
            <Card elevation={1} style={{ marginTop: spacing.sm, backgroundColor: colors.warningContainer }}>
              <View style={styles.alertRow}>
                <Clock size={18} color={colors.onWarningContainer} />
                <Text style={[styles.alertText, { color: colors.onWarningContainer }]}>
                  {stats?.endOfWeekCount} élève(s) terminent leur mois cette semaine
                </Text>
                <ChevronRight size={18} color={colors.onWarningContainer} />
              </View>
            </Card>
          ) : null}
        </Pressable>

        <Pressable onPress={() => setAlertStudents({ title: 'Élèves en retard de paiement', students: alertStudentsMap.late.map((s) => ({ id: s.id, full_name: s.full_name, level: s.level?.name, gender: s.gender })) })} disabled={(stats?.lateStudents ?? 0) === 0}>
          {(stats?.lateStudents ?? 0) > 0 ? (
            <Card elevation={1} style={{ marginTop: spacing.sm, backgroundColor: colors.errorContainer }}>
              <View style={styles.alertRow}>
                <AlertCircle size={18} color={colors.onErrorContainer} />
                <Text style={[styles.alertText, { color: colors.onErrorContainer }]}>
                  {stats?.lateStudents} élève(s) en retard de paiement
                </Text>
                <ChevronRight size={18} color={colors.onErrorContainer} />
              </View>
            </Card>
          ) : null}
        </Pressable>

        <Pressable onPress={() => setAlertStudents({ title: 'Élèves devant payer aujourd\'hui', students: alertStudentsMap.todayPayment.map((s) => ({ id: s.id, full_name: s.full_name, level: s.level?.name, gender: s.gender })) })} disabled={(stats?.todayCollected ?? 0) === 0 && alertStudentsMap.todayPayment.length === 0}>
          {(alertStudentsMap.todayPayment.length ?? 0) > 0 ? (
            <Card elevation={1} style={{ marginTop: spacing.sm, backgroundColor: colors.infoContainer }}>
              <View style={styles.alertRow}>
                <Banknote size={18} color={colors.onInfoContainer} />
                <Text style={[styles.alertText, { color: colors.onInfoContainer }]}>
                  {alertStudentsMap.todayPayment.length} élève(s) doivent payer aujourd\'hui
                </Text>
                <ChevronRight size={18} color={colors.onInfoContainer} />
              </View>
            </Card>
          ) : null}
        </Pressable>

        {(stats?.nextWeekPaymentCount ?? 0) > 0 ? (
          <Card elevation={1} style={{ marginTop: spacing.sm, backgroundColor: colors.infoContainer }}>
            <View style={styles.alertRow}>
              <TrendingUp size={18} color={colors.onInfoContainer} />
              <Text style={[styles.alertText, { color: colors.onInfoContainer }]}>
                {stats?.nextWeekPaymentCount} élève(s) devront payer la semaine prochaine — {formatCurrency(stats?.nextWeekExpectedTotal ?? 0)} attendus
              </Text>
            </View>
          </Card>
        ) : null}

        {/* Alert students modal */}
        <AlertStudentsModal
          visible={alertStudents !== null}
          title={alertStudents?.title ?? ''}
          students={alertStudents?.students ?? []}
          colors={colors}
          spacing={spacing}
          onClose={() => setAlertStudents(null)}
          onStudentPress={(id) => { setAlertStudents(null); router.push({ pathname: '/student/[id]', params: { id } }); }}
        />

        {/* Student stats */}
        <View style={styles.grid}>
          <StatCard label="Total élèves" value={stats?.totalStudents ?? 0} colorKey="primary" icon={<Users size={20} color={colors.primary} />} />
          <StatCard label="Actifs" value={stats?.activeStudents ?? 0} colorKey="success" icon={<UserCheck size={20} color={colors.success} />} />
        </View>
        <View style={styles.grid}>
          <StatCard label="Suspendus" value={stats?.suspendedStudents ?? 0} colorKey="error" icon={<UserX size={20} color={colors.error} />} />
          <StatCard label="En retard" value={stats?.lateStudents ?? 0} colorKey="warning" icon={<AlertCircle size={20} color={colors.warning} />} />
        </View>

        {/* Payment rate */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Taux de paiement</Text>
        <Card elevation={1}>
          <View style={styles.rateRow}>
            <CheckCircle2 size={18} color={colors.success} />
            <Text style={[styles.rateLabel, { color: colors.onSurfaceVariant }]}>Élèves à jour</Text>
            <Text style={[styles.rateValue, { color: colors.success }]}>{stats?.paidStudents ?? 0}</Text>
          </View>
          <View style={[styles.rateRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <AlertCircle size={18} color={colors.warning} />
            <Text style={[styles.rateLabel, { color: colors.onSurfaceVariant }]}>Paiements partiels</Text>
            <Text style={[styles.rateValue, { color: colors.warning }]}>{stats?.partialStudents ?? 0}</Text>
          </View>
          <View style={[styles.rateRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <TrendingDown size={18} color={colors.error} />
            <Text style={[styles.rateLabel, { color: colors.onSurfaceVariant }]}>Élèves en dette</Text>
            <Text style={[styles.rateValue, { color: colors.error }]}>{stats?.debtStudents ?? 0}</Text>
          </View>
        </Card>

        {/* Finance summary */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Bilan financier global</Text>
        <Card elevation={2}>
          <View style={styles.financeRow}>
            <Banknote size={20} color={colors.success} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Total encaissé</Text>
            </View>
            <Text style={[styles.financeValue, { color: colors.onSurface }]}>{formatCurrency(stats?.totalCollected ?? 0)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <TrendingDown size={20} color={colors.error} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Total dettes</Text>
            </View>
            <Text style={[styles.financeValue, { color: colors.error }]}>{formatCurrency(stats?.totalDebt ?? 0)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Building2 size={20} color={colors.warning} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Part de la salle</Text>
            </View>
            <Text style={[styles.financeValue, { color: colors.warning }]}>{formatCurrency(stats?.roomShare ?? 0)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <CheckCircle2 size={20} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Bénéfice professeur</Text>
            </View>
            <Text style={[styles.financeValue, { color: colors.primary, fontWeight: '800' }]}>{formatCurrency(stats?.profit ?? 0)}</Text>
          </View>
        </Card>

        {/* Stats by level */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Statistiques par niveau</Text>
        {(stats?.byLevel ?? []).map((lvl, i) => (
          <Card key={i} elevation={1} style={{ marginTop: spacing.sm }}>
            <View style={styles.levelRow}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.levelName, { color: colors.onSurface }]}>{lvl.levelName}</Text>
                <Text style={[styles.levelSub, { color: colors.onSurfaceVariant }]}>{lvl.count} élève(s)</Text>
              </View>
              <Text style={[styles.levelAmount, { color: colors.success }]}>{formatCurrency(lvl.collected)}</Text>
            </View>
          </Card>
        ))}
        <Card elevation={1} style={{ marginTop: spacing.sm, backgroundColor: colors.primaryContainer }}>
          <View style={styles.levelRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.levelName, { color: colors.onPrimaryContainer }]}>Total général</Text>
              <Text style={[styles.levelSub, { color: colors.onPrimaryContainer }]}>{stats?.activeStudents ?? 0} élève(s) actif(s)</Text>
            </View>
            <Text style={[styles.levelAmount, { color: colors.onPrimaryContainer }]}>{formatCurrency(stats?.totalCollected ?? 0)}</Text>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

function computeRoomShare(totalCollected: number, settings: AppSettings): number {
  if (settings.room_share_type === 'percentage') {
    return totalCollected * (settings.room_share_rate / 100);
  }
  return settings.room_share_rate;
}

function AlertStudentsModal({ visible, title, students, colors, spacing, onClose, onStudentPress }: {
  visible: boolean;
  title: string;
  students: { id: string; full_name: string; level?: string; gender: 'male' | 'female' | null }[];
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  onClose: () => void;
  onStudentPress: (id: string) => void;
}) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
        <View style={{ backgroundColor: colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '80%' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Text style={{ fontSize: 18, fontWeight: '700', color: colors.onSurface, flex: 1 }}>{title}</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            {students.length === 0 ? (
              <Text style={{ fontSize: 14, color: colors.onSurfaceVariant, textAlign: 'center', paddingVertical: 20 }}>Aucun élève concerné</Text>
            ) : (
              students.map((s) => (
                <Pressable key={s.id} onPress={() => onStudentPress(s.id)} style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth, opacity: pressed ? 0.7 : 1 }]}>
                  <StudentAvatar fullName={s.full_name} size={40} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 15, fontWeight: '600', color: getGenderColor(s.gender) }} numberOfLines={1}>{s.full_name}</Text>
                    {s.level ? <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 2 }}>{s.level}</Text> : null}
                  </View>
                  <ChevronRight size={18} color={colors.onSurfaceVariant} />
                </Pressable>
              ))
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: 12, marginTop: 12 },
  financeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, gap: 12 },
  financeLabel: { fontSize: 14, fontWeight: '500' },
  financeValue: { fontSize: 16, fontWeight: '700' },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  levelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  levelName: { fontSize: 15, fontWeight: '600' },
  levelSub: { fontSize: 12, marginTop: 2 },
  levelAmount: { fontSize: 15, fontWeight: '700' },
  dailyHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingBottom: 10 },
  dailyTitle: { fontSize: 15, fontWeight: '700' },
  dailyRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 10 },
  dailyLabel: { flex: 1, fontSize: 14, fontWeight: '500' },
  dailyValue: { fontSize: 15, fontWeight: '700' },
  alertRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  alertText: { fontSize: 13, fontWeight: '600', flex: 1 },
  dateTimeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 10 },
  dateTimeLabel: { fontSize: 14, fontWeight: '500' },
  dateTimeValue: { fontSize: 14, fontWeight: '700', marginLeft: 'auto' },
  rateRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, gap: 12 },
  rateLabel: { flex: 1, fontSize: 14, fontWeight: '500' },
  rateValue: { fontSize: 16, fontWeight: '700' },
});
