import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, RefreshControl, Pressable, Modal, TextInput } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { ScreenHeader, LoadingView, ErrorView } from '@/components/ScreenHeader';
import { StatCard } from '@/components/StatCard';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { fetchAllPayments, type PaymentWithStudent } from '@/services/paymentService';
import { fetchStudents, type StudentWithRelations } from '@/services/studentService';
import { loadSettings } from '@/services/settingsService';
import { fetchPeriods, closePeriodWithLog, fetchClosedPeriodReport, type PeriodCloseResult } from '@/services/periodService';
import { formatCurrency, formatDate, todayISO, getGenderColor } from '@/utils/format';
import { Banknote, Wallet, Building2, TrendingDown, CheckCircle2, AlertCircle, Lock, X, FileText, Users, Clock, FileSpreadsheet, TrendingUp, UserCheck, ArrowRight } from 'lucide-react-native';
import type { AppSettings, Period } from '@/types';

export default function ComptabiliteScreen() {
  const { colors, spacing, radius } = useTheme();
  const [payments, setPayments] = useState<PaymentWithStudent[]>([]);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [students, setStudents] = useState<StudentWithRelations[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [closeResult, setCloseResult] = useState<PeriodCloseResult | null>(null);
  const [loadingReport, setLoadingReport] = useState(false);
  const [confirmClose, setConfirmClose] = useState<Period | null>(null);
  const [pinStep, setPinStep] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [showReport, setShowReport] = useState(false);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const [pays, pers, studs, s] = await Promise.all([fetchAllPayments(), fetchPeriods(), fetchStudents(), loadSettings()]);
      setPayments(pays);
      setPeriods(pers);
      setStudents(studs);
      setSettings(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur de chargement');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading && payments.length === 0) return <LoadingView />;
  if (error && payments.length === 0) return <ErrorView message={error} />;

  const totalCollected = payments.reduce((sum, p) => sum + (Number(p.amount_paid) || 0), 0);
  const totalDebt = payments
    .filter((p) => p.status !== 'paid' && p.status !== 'single')
    .reduce((sum, p) => sum + (Number(p.amount) - Number(p.amount_paid)), 0);

  const establishmentShare = settings
    ? settings.room_share_type === 'percentage'
      ? totalCollected * (settings.room_share_rate / 100)
      : Math.min(settings.room_share_rate * payments.length, totalCollected)
    : 0;
  const professorShare = totalCollected - establishmentShare;

  const unpaidList = payments
    .filter((p) => Number(p.amount_paid) < Number(p.amount))
    .map((p) => ({
      studentName: p.student?.full_name ?? 'Inconnu',
      gender: p.student?.gender ?? null,
      amount: Number(p.amount),
      amountPaid: Number(p.amount_paid),
      debt: Number(p.amount) - Number(p.amount_paid),
      status: p.status,
    }));

  const openPeriods = periods.filter((p) => !p.is_closed);
  const closedPeriods = periods.filter((p) => p.is_closed);

  const handleClose = async (periodId: string) => {
    if (!settings) return;
    try {
      const result = await closePeriodWithLog(periodId, settings);
      setCloseResult(result);
      setConfirmClose(null);
      setPinStep(false);
      setPinInput('');
      setPinError(null);
      setShowReport(true);
      loadData();
    } catch (e) { /* ignore */ }
  };

  const handlePinSubmit = () => {
    if (!settings) return;
    if (!settings.app_password || settings.app_password.trim() === '') {
      setPinError('Aucun code PIN configuré. Créez-en un dans les Paramètres > Sécurité.');
      return;
    }
    if (pinInput === settings.app_password) {
      setPinError(null);
      handleClose(confirmClose!.id);
    } else {
      setPinError('Code PIN incorrect');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Comptabilité" subtitle="Bilan financier et clôture de période" />
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
      >
        {/* Global financial summary */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.sm }]}>Bilan global</Text>
        <Card elevation={2}>
          <View style={styles.financeRow}>
            <Banknote size={20} color={colors.success} />
            <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Total encaissé</Text>
            <Text style={[styles.financeValue, { color: colors.success }]}>{formatCurrency(totalCollected)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <TrendingDown size={20} color={colors.error} />
            <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Total des dettes</Text>
            <Text style={[styles.financeValue, { color: colors.error }]}>{formatCurrency(totalDebt)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Wallet size={20} color={colors.primary} />
            <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Part du professeur</Text>
            <Text style={[styles.financeValue, { color: colors.primary, fontWeight: '800' }]}>{formatCurrency(professorShare)}</Text>
          </View>
          <View style={[styles.financeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Building2 size={20} color={colors.warning} />
            <Text style={[styles.financeLabel, { color: colors.onSurfaceVariant }]}>Part de l'établissement</Text>
            <Text style={[styles.financeValue, { color: colors.warning }]}>{formatCurrency(establishmentShare)}</Text>
          </View>
        </Card>

        {/* Quick stats */}
        <View style={styles.grid}>
          <StatCard label="Paiements" value={payments.length} colorKey="primary" icon={<FileText size={20} color={colors.primary} />} />
          <StatCard label="Impayés" value={unpaidList.length} colorKey="error" icon={<AlertCircle size={20} color={colors.error} />} />
        </View>

        {/* Unpaid list */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Liste des impayés ({unpaidList.length})</Text>
        {unpaidList.length === 0 ? (
          <Card elevation={1} style={{ marginTop: spacing.sm }}>
            <View style={styles.emptyRow}>
              <CheckCircle2 size={20} color={colors.success} />
              <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Tous les paiements sont réglés</Text>
            </View>
          </Card>
        ) : (
          <View style={{ marginTop: spacing.sm }}>
            {unpaidList.map((u, i) => (
              <Card key={i} elevation={1} style={{ marginBottom: spacing.sm }}>
                <View style={styles.unpaidRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.unpaidName, { color: getGenderColor(u.gender) }]} numberOfLines={1}>{u.studentName}</Text>
                    <Text style={[styles.unpaidSub, { color: colors.onSurfaceVariant }]}>
                      Payé: {formatCurrency(u.amountPaid)} / {formatCurrency(u.amount)}
                    </Text>
                  </View>
                  <Text style={[styles.unpaidDebt, { color: colors.error }]}>{formatCurrency(u.debt)}</Text>
                </View>
              </Card>
            ))}
          </View>
        )}

        {/* Close period */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Clôturer la période</Text>
        <Card elevation={2}>
          <Text style={[styles.hintText, { color: colors.onSurfaceVariant }]}>
            Clôturer la période en cours calcule les parts du professeur et de l'établissement, enregistre un rapport détaillé dans l'historique et archive définitivement les montants. Un code PIN est demandé pour confirmer.
          </Text>
          {openPeriods.length === 0 ? (
            <View style={[styles.emptyRow, { marginTop: spacing.sm }]}>
              <Clock size={18} color={colors.onSurfaceVariant} />
              <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Aucune période ouverte. Créez-en une dans les paramètres.</Text>
            </View>
          ) : (
            <View style={{ marginTop: spacing.sm }}>
              {openPeriods.map((p) => (
                <View key={p.id} style={[styles.periodRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.periodName, { color: colors.onSurface }]}>{p.name}</Text>
                    <Text style={[styles.periodDates, { color: colors.onSurfaceVariant }]}>
                      {formatDate(p.start_date)} → {formatDate(p.end_date)}
                    </Text>
                    {p.is_active ? (
                      <View style={[styles.activeBadge, { backgroundColor: colors.successContainer, marginTop: 4 }]}>
                        <Text style={[styles.activeBadgeText, { color: colors.onSuccessContainer }]}>Active</Text>
                      </View>
                    ) : null}
                  </View>
                  <Button label="Clôturer" size="sm" variant="filled" onPress={() => { setConfirmClose(p); setPinStep(false); setPinInput(''); setPinError(null); }} icon={<Lock size={14} color={colors.onPrimary} />} />
                </View>
              ))}
            </View>
          )}
        </Card>

        {/* Closed periods history */}
        {closedPeriods.length > 0 ? (
          <>
            <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>Périodes clôturées</Text>
            <View style={{ marginTop: spacing.sm }}>
              {closedPeriods.map((p) => (
                <Card key={p.id} elevation={1} style={{ marginBottom: spacing.sm }}>
                  <Pressable onPress={async () => { setLoadingReport(true); try { const report = await fetchClosedPeriodReport(p.id); setCloseResult(report); setShowReport(true); } catch { /* ignore */ } finally { setLoadingReport(false); } }}>
                    <View style={styles.closedPeriodHeader}>
                      <Text style={[styles.periodName, { color: colors.onSurface }]}>{p.name}</Text>
                      <View style={[styles.statusPill, { backgroundColor: colors.successContainer }]}>
                        <Text style={[styles.statusPillText, { color: colors.onSuccessContainer }]}>Clôturée</Text>
                      </View>
                    </View>
                    <Text style={[styles.periodDates, { color: colors.onSurfaceVariant }]}>
                      {formatDate(p.start_date)} → {formatDate(p.end_date)}
                    </Text>
                    <View style={styles.closedStats}>
                      <StatChip label="Revenu" value={formatCurrency(p.total_revenue)} color={colors.onSurface} bg={colors.surfaceVariant} />
                      <StatChip label="Professeur" value={formatCurrency(p.professor_share)} color={colors.onSuccessContainer} bg={colors.successContainer} />
                      <StatChip label="Établissement" value={formatCurrency(p.creche_share)} color={colors.onPrimaryContainer} bg={colors.primaryContainer} />
                      <StatChip label="Dettes" value={formatCurrency(p.total_debt)} color={colors.onErrorContainer} bg={colors.errorContainer} />
                    </View>
                  </Pressable>
                </Card>
              ))}
            </View>
          </>
        ) : null}
      </ScrollView>

      {/* Confirm close dialog with PIN */}
      <ConfirmCloseDialog
        visible={confirmClose !== null}
        period={confirmClose}
        colors={colors}
        spacing={spacing}
        radius={radius}
        pinStep={pinStep}
        pinInput={pinInput}
        pinError={pinError}
        onPinChange={setPinInput}
        onPinSubmit={handlePinSubmit}
        onConfirm={() => setPinStep(true)}
        onCancel={() => { setConfirmClose(null); setPinStep(false); setPinInput(''); setPinError(null); }}
      />

      {/* Synthesis report page */}
      {showReport && closeResult ? (
        <SynthesisReport
          result={closeResult}
          colors={colors}
          spacing={spacing}
          radius={radius}
          onClose={() => { setShowReport(false); setCloseResult(null); }}
        />
      ) : null}
    </View>
  );
}

function SynthesisReport({ result, colors, spacing, radius, onClose }: {
  result: PeriodCloseResult;
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  radius: ReturnType<typeof useTheme>['radius'];
  onClose: () => void;
}) {
  const reports = [
    { icon: <Banknote size={20} color={colors.success} />, label: 'Rapport des encaissements', color: colors.success },
    { icon: <TrendingDown size={20} color={colors.error} />, label: 'Rapport des impayés', color: colors.error },
    { icon: <Wallet size={20} color={colors.warning} />, label: 'Rapport des dettes', color: colors.warning },
    { icon: <TrendingUp size={20} color={colors.primary} />, label: 'Rapport des régularisations', color: colors.primary },
    { icon: <Building2 size={20} color={colors.onPrimaryContainer} />, label: 'Répartition des revenus', color: colors.onPrimaryContainer },
    { icon: <Wallet size={20} color={colors.primary} />, label: 'Bénéfice net', color: colors.primary },
    { icon: <UserCheck size={20} color={colors.success} />, label: 'Élèves ayant terminé', color: colors.success },
    { icon: <FileText size={20} color={colors.error} />, label: 'Export PDF', color: colors.error },
    { icon: <FileSpreadsheet size={20} color={colors.success} />, label: 'Export Excel', color: colors.success },
  ];

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.reportModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <FileText size={22} color={colors.primary} />
              <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Synthèse de la clôture</Text>
            </View>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>

          <ScrollView style={{ maxHeight: 500 }} contentContainerStyle={{ paddingBottom: spacing.sm }}>
            {/* Summary numbers */}
            <Card elevation={1} style={{ marginBottom: spacing.md }}>
              <ResultRow icon={<Banknote size={18} color={colors.success} />} label="Total encaissé" value={formatCurrency(result.totalRevenue)} colors={colors} />
              <ResultRow icon={<Wallet size={18} color={colors.primary} />} label="Part du professeur" value={formatCurrency(result.professorShare)} colors={colors} />
              <ResultRow icon={<Building2 size={18} color={colors.warning} />} label="Part de l'établissement" value={formatCurrency(result.establishmentShare)} colors={colors} />
              <ResultRow icon={<TrendingDown size={18} color={colors.error} />} label="Total des dettes" value={formatCurrency(result.totalDebt)} colors={colors} />
              <Text style={[styles.resultCount, { color: colors.onSurfaceVariant }]}>{result.paymentCount} paiement(s) — {result.unpaidList?.length ?? 0} impayé(s)</Text>
            </Card>

            {/* Unpaid list */}
            {result.unpaidList && result.unpaidList.length > 0 ? (
              <View style={{ marginBottom: spacing.md }}>
                <Text style={[styles.unpaidTitle, { color: colors.onSurface }]}>Liste des impayés</Text>
                {result.unpaidList.map((u, i) => (
                  <View key={i} style={[styles.unpaidResultRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                    <Text style={[styles.unpaidResultName, { color: getGenderColor(u.gender) }]} numberOfLines={1}>{u.studentName}</Text>
                    <Text style={[styles.unpaidResultDebt, { color: colors.error }]}>{formatCurrency(u.debt)}</Text>
                  </View>
                ))}
              </View>
            ) : null}

            {/* Report buttons */}
            <Text style={[styles.reportSectionTitle, { color: colors.onSurface }]}>Rapports disponibles</Text>
            <View style={{ gap: spacing.sm }}>
              {reports.map((r, i) => (
                <Pressable key={i} style={({ pressed }) => [styles.reportBtn, { backgroundColor: colors.surfaceVariant, opacity: pressed ? 0.8 : 1 }]}>
                  {r.icon}
                  <Text style={[styles.reportBtnLabel, { color: colors.onSurface, flex: 1 }]}>{r.label}</Text>
                  <ArrowRight size={16} color={colors.onSurfaceVariant} />
                </Pressable>
              ))}
            </View>
          </ScrollView>

          <Button label="Fermer" variant="filled" onPress={onClose} style={{ marginTop: spacing.md }} />
        </View>
      </View>
    </Modal>
  );
}

function ResultRow({ icon, label, value, colors }: { icon: React.ReactNode; label: string; value: string; colors: ReturnType<typeof useTheme>['colors'] }) {
  return (
    <View style={styles.resultRow}>
      {icon}
      <Text style={[styles.resultLabel, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <Text style={[styles.resultValue, { color: colors.onSurface }]}>{value}</Text>
    </View>
  );
}

function StatChip({ label, value, color, bg }: { label: string; value: string; color: string; bg: string }) {
  return (
    <View style={[styles.statChip, { backgroundColor: bg }]}>
      <Text style={[styles.statChipLabel, { color }]}>{label}</Text>
      <Text style={[styles.statChipValue, { color }]}>{value}</Text>
    </View>
  );
}

function ConfirmCloseDialog({ visible, period, colors, spacing, radius, pinStep, pinInput, pinError, onPinChange, onPinSubmit, onConfirm, onCancel }: {
  visible: boolean;
  period: Period | null;
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  radius: ReturnType<typeof useTheme>['radius'];
  pinStep: boolean;
  pinInput: string;
  pinError: string | null;
  onPinChange: (v: string) => void;
  onPinSubmit: () => void;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!visible || !period) return null;
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.modalOverlay}>
        <View style={[styles.confirmModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <Lock size={22} color={colors.warning} />
            <Text style={{ fontSize: 18, fontWeight: '700', color: colors.onSurface }}>Clôturer la période</Text>
          </View>
          <Text style={{ fontSize: 14, color: colors.onSurfaceVariant, lineHeight: 20, marginBottom: 16 }}>
            Voulez-vous clôturer la période « {period.name} » ? Les parts du professeur et de l'établissement seront calculées et un rapport sera enregistré dans l'historique. Vous pourrez créer une nouvelle période depuis les Paramètres {'>'} Périodes.
          </Text>
          {pinStep ? (
            <View>
              <Text style={{ fontSize: 14, fontWeight: '600', color: colors.onSurface, marginBottom: 8 }}>Entrez le code PIN pour confirmer</Text>
              <TextInput
                value={pinInput}
                onChangeText={onPinChange}
                placeholder="Code PIN"
                placeholderTextColor={colors.onSurfaceVariant}
                keyboardType="numeric"
                secureTextEntry
                style={{ backgroundColor: colors.surfaceVariant, borderRadius: 12, paddingHorizontal: 16, height: 48, fontSize: 16, color: colors.onSurface, textAlign: 'center', letterSpacing: 4 }}
              />
              {pinError ? <Text style={{ fontSize: 13, color: colors.error, marginTop: 8, textAlign: 'center' }}>{pinError}</Text> : null}
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 16 }}>
                <Button label="Annuler" variant="text" onPress={onCancel} style={{ flex: 1 }} />
                <Button label="Confirmer" variant="filled" onPress={onPinSubmit} style={{ flex: 1, marginLeft: 8 }} />
              </View>
            </View>
          ) : (
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Button label="Annuler" variant="text" onPress={onCancel} style={{ flex: 1 }} />
              <Button label="Continuer" variant="filled" onPress={onConfirm} style={{ flex: 1, marginLeft: 8 }} />
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  grid: { flexDirection: 'row', gap: 12, marginTop: 12 },
  financeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, gap: 12 },
  financeLabel: { flex: 1, fontSize: 14, fontWeight: '500' },
  financeValue: { fontSize: 16, fontWeight: '700' },
  emptyRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8 },
  emptyText: { fontSize: 14 },
  unpaidRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  unpaidName: { fontSize: 15, fontWeight: '600' },
  unpaidSub: { fontSize: 12, marginTop: 2 },
  unpaidDebt: { fontSize: 15, fontWeight: '700' },
  hintText: { fontSize: 13, lineHeight: 19 },
  periodRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, marginTop: 4 },
  periodName: { fontSize: 15, fontWeight: '700' },
  periodDates: { fontSize: 12, marginTop: 4 },
  activeBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, alignSelf: 'flex-start' },
  activeBadgeText: { fontSize: 11, fontWeight: '600' },
  closedPeriodHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusPillText: { fontSize: 11, fontWeight: '600' },
  closedStats: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  statChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  statChipLabel: { fontSize: 10, fontWeight: '500' },
  statChipValue: { fontSize: 13, fontWeight: '700', marginTop: 2 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  reportModal: { width: '100%', maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '700' },
  resultRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10 },
  resultLabel: { flex: 1, fontSize: 14 },
  resultValue: { fontSize: 16, fontWeight: '700' },
  resultCount: { fontSize: 12, marginTop: 4, textAlign: 'center' },
  unpaidTitle: { fontSize: 14, fontWeight: '700', marginBottom: 6 },
  unpaidResultRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8 },
  unpaidResultName: { fontSize: 13, fontWeight: '500', flex: 1 },
  unpaidResultDebt: { fontSize: 13, fontWeight: '700' },
  confirmModal: { width: '100%', maxWidth: 380 },
  reportSectionTitle: { fontSize: 15, fontWeight: '700', marginBottom: 10 },
  reportBtn: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 14, borderRadius: 12 },
  reportBtnLabel: { fontSize: 14, fontWeight: '500' },
});
