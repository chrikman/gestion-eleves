import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, TextInput, Modal } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTheme } from '@/theme/ThemeContext';
import { ScreenHeader, LoadingView, ErrorView } from '@/components/ScreenHeader';
import { Card } from '@/components/Card';
import { StudentAvatar } from '@/components/StudentAvatar';
import { Button } from '@/components/Button';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { fetchStudentById, updateStudent, setStudentStatus, type StudentWithRelations } from '@/services/studentService';
import { fetchPaymentsByStudent, updatePayment, fetchOldDebts, createPayment, incrementSession, type OldDebt } from '@/services/paymentService';
import { fetchAbsencesByStudent, createAbsence, deleteAbsence } from '@/services/absenceService';
import { fetchLevels } from '@/services/levelService';
import { fetchCurrentSchoolYear } from '@/services/schoolYearService';
import { loadSettings } from '@/services/settingsService';
import { formatCurrency, formatDate, todayISO, addDays, getStudentStatusLabel, getPaymentStatusLabel, getGenderColor } from '@/utils/format';
import { getPaymentColorKey } from '@/utils/paymentColors';
import { getEffectiveSessionsCompleted } from '@/utils/sessionProgress';
import type { Payment, Absence, Level, SchoolYear, AppSettings } from '@/types';
import { ArrowLeft, Pencil, Ban, CheckCircle2, Trash2, CalendarPlus, X, TrendingUp, Wallet, Clock, CalendarClock } from 'lucide-react-native';
import { DatePickerField } from '@/components/DatePickerField';

const MONTH_LABELS = ['Premier mois', 'Deuxième mois', 'Troisième mois', 'Quatrième mois', 'Cinquième mois', 'Sixième mois', 'Septième mois', 'Huitième mois', 'Neuvième mois', 'Dixième mois', 'Onzième mois', 'Douzième mois'];

export default function StudentDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const [student, setStudent] = useState<StudentWithRelations | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [absences, setAbsences] = useState<Absence[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [currentYear, setCurrentYear] = useState<SchoolYear | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [showAbsenceModal, setShowAbsenceModal] = useState(false);
  const [confirmTrash, setConfirmTrash] = useState(false);
  const [showNewMonthModal, setShowNewMonthModal] = useState(false);
  const [showRegularizeModal, setShowRegularizeModal] = useState(false);
  const [editPaymentId, setEditPaymentId] = useState<string | null>(null);
  const [oldDebts, setOldDebts] = useState<OldDebt[]>([]);
  const [confirmDeletePayment, setConfirmDeletePayment] = useState<Payment | null>(null);
  const [confirmSuspend, setConfirmSuspend] = useState(false);
  const [confirmActivate, setConfirmActivate] = useState(false);
  const [confirmDeleteAbsence, setConfirmDeleteAbsence] = useState<string | null>(null);
  const [prolongPayment, setProlongPayment] = useState<Payment | null>(null);

  const loadData = useCallback(async () => {
    if (!id) return;
    try {
      setError(null);
      const [s, p, a, l, y, sett] = await Promise.all([
        fetchStudentById(id), fetchPaymentsByStudent(id), fetchAbsencesByStudent(id),
        fetchLevels(), fetchCurrentSchoolYear(), loadSettings(),
      ]);
      setStudent(s); setPayments(p); setAbsences(a); setLevels(l); setCurrentYear(y); setSettings(sett);
      const debts = await fetchOldDebts(id);
      setOldDebts(debts);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally { setLoading(false); }
  }, [id]);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading) return <LoadingView />;
  if (error) return <ErrorView message={error} />;
  if (!student) return <ErrorView message="Élève introuvable" />;

  const regularPayments = payments.filter((p) => !p.is_regularization);
  const totalPaid = regularPayments.reduce((sum, p) => sum + Number(p.amount_paid), 0);
  const totalDue = regularPayments.reduce((sum, p) => sum + Number(p.amount), 0);
  const remaining = totalDue - totalPaid;
  const monthCount = regularPayments.length;

  const genderLabel = student.gender === 'male' ? 'Garçon' : student.gender === 'female' ? 'Fille' : '—';

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={[styles.topBar, { paddingHorizontal: spacing.md, paddingTop: spacing.lg, paddingBottom: spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}><ArrowLeft size={24} color={colors.onSurface} /></Pressable>
        <Text style={[styles.topTitle, { color: colors.onSurface }]} numberOfLines={1}>Fiche élève</Text>
        <Pressable onPress={() => setEditing(true)} style={styles.backBtn}><Pencil size={22} color={colors.primary} /></Pressable>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl }}>
        {/* Profile header */}
        <Card elevation={2} style={{ alignItems: 'center', paddingVertical: spacing.lg }}>
          <StudentAvatar fullName={student.full_name} size={72} />
          <Text style={[styles.profileNameUpper, { color: getGenderColor(student.gender) }]}>{(student.full_name ?? '').toUpperCase()}</Text>
          <Text style={[styles.profileLevel, { color: colors.onSurfaceVariant }]}>
            {student.level?.name ?? 'Sans niveau'} · {genderLabel}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: spacing.sm }}>
            <View style={[styles.statusBadge, { backgroundColor: student.status === 'active' ? colors.successContainer : student.status === 'suspended' ? colors.warningContainer : colors.surfaceVariant }]}>
              <Text style={[styles.statusBadgeText, { color: student.status === 'active' ? colors.onSuccessContainer : student.status === 'suspended' ? colors.onWarningContainer : colors.onSurfaceVariant }]}>
                {getStudentStatusLabel(student.status)}
              </Text>
            </View>
            {student.status === 'active' ? (
              <Pressable onPress={() => setConfirmSuspend(true)} style={[styles.pauseBtn, { backgroundColor: colors.warningContainer }]}>
                <Ban size={14} color={colors.onWarningContainer} />
                <Text style={[styles.pauseBtnText, { color: colors.onWarningContainer }]}>Pause</Text>
              </Pressable>
            ) : student.status === 'suspended' ? (
              <Pressable onPress={() => setConfirmActivate(true)} style={[styles.pauseBtn, { backgroundColor: colors.successContainer }]}>
                <CheckCircle2 size={14} color={colors.onSuccessContainer} />
                <Text style={[styles.pauseBtnText, { color: colors.onSuccessContainer }]}>Activer</Text>
              </Pressable>
            ) : null}
          </View>
        </Card>

        {/* Financial summary */}
        <Card elevation={1} style={{ marginTop: spacing.md }}>
          <View style={[styles.finHeader, { borderBottomColor: colors.divider, borderBottomWidth: StyleSheet.hairlineWidth, paddingBottom: spacing.sm }]}>
            <Wallet size={18} color={colors.primary} />
            <Text style={[styles.finTitle, { color: colors.onSurface }]}>Récapitulatif financier</Text>
          </View>
          <View style={{ flexDirection: 'row', paddingTop: spacing.sm, gap: 8 }}>
            <View style={styles.finCol}>
              <Text style={[styles.finLabel, { color: colors.onSurfaceVariant }]}>Total payé</Text>
              <Text style={[styles.finValue, { color: colors.success }]}>{formatCurrency(totalPaid)}</Text>
            </View>
            <View style={styles.finCol}>
              <Text style={[styles.finLabel, { color: colors.onSurfaceVariant }]}>Total dû</Text>
              <Text style={[styles.finValue, { color: colors.onSurface }]}>{formatCurrency(totalDue)}</Text>
            </View>
            <View style={styles.finCol}>
              <Text style={[styles.finLabel, { color: colors.onSurfaceVariant }]}>Reste</Text>
              <Text style={[styles.finValue, { color: remaining > 0 ? colors.error : colors.success }]}>{formatCurrency(remaining)}</Text>
            </View>
          </View>
        </Card>

        {/* Smart action buttons */}
        {(() => {
          const currentMonth = regularPayments[regularPayments.length - 1];
          const currentMonthDebt = currentMonth ? Number(currentMonth.amount) - Number(currentMonth.amount_paid) : 0;
          const hasOldDebts = oldDebts.length > 0;
          const hasCurrentDebt = currentMonthDebt > 0;

          const showPayer = hasCurrentDebt;
          const showRegularize = hasOldDebts;

          if (!showPayer && !showRegularize) return null;

          return (
            <View style={{ marginTop: spacing.md, gap: 8 }}>
              {showPayer ? (
                <Button
                  label="Payer le mois en cours"
                  variant="filled"
                  size="lg"
                  onPress={() => setEditPaymentId(currentMonth!.id)}
                  icon={<Wallet size={18} color={colors.onPrimary} />}
                />
              ) : null}
              {showRegularize ? (
                <Button
                  label="Régulariser une ancienne dette"
                  variant="outlined"
                  size="lg"
                  onPress={() => setShowRegularizeModal(true)}
                  icon={<TrendingUp size={18} color={colors.warning} />}
                />
              ) : null}
            </View>
          );
        })()}

        {/* Months history — per-month cards */}
        <Text style={[styles.sectionTitle, { color: colors.onSurface, marginTop: spacing.lg }]}>
          Historique ({monthCount} mois)
        </Text>
        {regularPayments.length === 0 ? (
          <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Aucun mois enregistré</Text>
        ) : (
          regularPayments.map((p, idx) => {
            const sessionsDone = getEffectiveSessionsCompleted(p);
            const sessionsTotal = p.session_count ?? 4;
            const debt = Number(p.amount) - Number(p.amount_paid);
            const monthLabel = idx < MONTH_LABELS.length ? MONTH_LABELS[idx] : `Mois ${idx + 1}`;

            return (
              <Card key={p.id} elevation={1} style={{ marginTop: spacing.sm }}>
                {/* Month header */}
                <View style={[styles.periodCardHeader, { borderBottomColor: colors.divider, borderBottomWidth: StyleSheet.hairlineWidth, paddingBottom: spacing.sm }]}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                    <View style={[styles.numberBadge, { backgroundColor: colors.primaryContainer }]}>
                      <Text style={[styles.numberText, { color: colors.onPrimaryContainer }]}>{idx + 1}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.monthLabel, { color: colors.onSurface }]}>{monthLabel}</Text>
                      <Text style={[styles.periodDates, { color: colors.onSurfaceVariant }]}>{formatDate(p.period_start)} → {formatDate(p.period_end)}</Text>
                    </View>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: p.status === 'paid' ? colors.successContainer : p.status === 'partial' ? colors.warningContainer : colors.errorContainer }]}>
                    <Text style={[styles.statusBadgeText, { color: p.status === 'paid' ? colors.onSuccessContainer : p.status === 'partial' ? colors.onWarningContainer : colors.onErrorContainer }]}>
                      {getPaymentStatusLabel(p.status)}
                    </Text>
                  </View>
                </View>

                {/* Session progress bars */}
                <View style={{ paddingTop: spacing.sm }}>
                  <SessionBars
                    sessionsDone={sessionsDone}
                    sessionsTotal={sessionsTotal}
                    paymentStatus={p.status}
                    colors={colors}
                  />
                </View>

                {/* Month details table */}
                <View style={{ paddingTop: spacing.sm, gap: 6 }}>
                  <DetailRow label="Tarif convenu" value={formatCurrency(Number(p.amount))} colors={colors} />
                  <DetailRow label="Montant payé" value={formatCurrency(Number(p.amount_paid))} colors={colors} />
                  <DetailRow label="Reste à payer" value={formatCurrency(debt)} colors={colors} valueColor={debt > 0 ? colors.error : colors.success} />
                  <DetailRow label="Reçu" value={p.receipt_number ?? '—'} colors={colors} />
                  <DetailRow label="Statut" value={getPaymentStatusLabel(p.status)} colors={colors} />
                  {p.payment_date ? <DetailRow label="Date du paiement" value={formatDate(p.payment_date)} colors={colors} /> : null}
                  {p.notes ? <DetailRow label="Observations" value={p.notes} colors={colors} /> : null}
                </View>

                {/* Actions: Modify payment + Prolong month + Delete */}
                <View style={[styles.periodActions, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth, marginTop: spacing.sm, paddingTop: spacing.sm }]}>
                  <Button label="Modifier" size="sm" variant="tonal" onPress={() => setEditPaymentId(p.id)} icon={<Pencil size={14} color={colors.primary} />} />
                  {!p.is_closed && !p.is_regularization ? (
                    <Button label="Prolonger le mois" size="sm" variant="outlined" onPress={() => { setProlongPayment(p); }} icon={<CalendarClock size={14} color={colors.primary} />} />
                  ) : null}
                  {!p.is_closed && !p.is_regularization && (p.sessions_completed ?? 0) < sessionsTotal ? (
                    <Button label="Valider séance" size="sm" variant="filled" onPress={async () => { await incrementSession(p.id); loadData(); }} icon={<CheckCircle2 size={14} color={colors.onPrimary} />} />
                  ) : null}
                  <Pressable onPress={() => setConfirmDeletePayment(p)} style={[styles.deleteIconBtn, { backgroundColor: colors.errorContainer }]}>
                    <Trash2 size={16} color={colors.onErrorContainer} />
                  </Pressable>
                </View>

                {p.is_closed ? (
                  <View style={[styles.closedBadgeRow, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth, marginTop: spacing.sm, paddingTop: spacing.sm }]}>
                    <View style={[styles.closedBadge, { backgroundColor: colors.surfaceVariant }]}>
                      <CheckCircle2 size={12} color={colors.onSurfaceVariant} />
                      <Text style={[styles.closedBadgeText, { color: colors.onSurfaceVariant }]}>Mois clôturé</Text>
                    </View>
                  </View>
                ) : null}
              </Card>
            );
          })
        )}

        {/* New month button */}
        {currentYear ? (
          <Button
            label={`Enregistrer le ${monthCount + 1}${monthCount + 1 === 1 ? 'er' : 'ème'} mois`}
            variant="filled"
            size="lg"
            style={{ marginTop: spacing.lg }}
            onPress={() => setShowNewMonthModal(true)}
            icon={<CalendarPlus size={18} color={colors.onPrimary} />}
          />
        ) : null}

        {/* Absences history */}
        <View style={[styles.sectionHeader, { marginTop: spacing.lg }]}>
          <Text style={[styles.sectionTitle, { color: colors.onSurface }]}>Historique des absences</Text>
          <Pressable onPress={() => setShowAbsenceModal(true)} style={[styles.addAbsenceBtn, { backgroundColor: colors.primaryContainer }]}>
            <CalendarPlus size={16} color={colors.onPrimaryContainer} />
            <Text style={[styles.addAbsenceText, { color: colors.onPrimaryContainer }]}>Ajouter</Text>
          </Pressable>
        </View>
        {absences.length === 0 ? (
          <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Aucune absence enregistrée</Text>
        ) : (
          absences.map((a) => (
            <Card key={a.id} elevation={1} style={{ marginTop: spacing.sm }}>
              <View style={styles.absenceRow}>
                <View>
                  <Text style={[styles.absenceDate, { color: colors.onSurface }]}>{formatDate(a.date)}</Text>
                  {a.reason ? <Text style={[styles.absenceReason, { color: colors.onSurfaceVariant }]}>{a.reason}</Text> : null}
                </View>
                <Pressable onPress={() => setConfirmDeleteAbsence(a.id)}><X size={18} color={colors.error} /></Pressable>
              </View>
            </Card>
          ))
        )}
      </ScrollView>

      {showNewMonthModal ? (
        <NewMonthModal
          monthNumber={monthCount + 1}
          periodDurationDays={settings?.period_duration_days ?? 21}
          sessionsPerPeriod={settings?.sessions_per_period ?? 4}
          defaultSessionPrice={settings?.default_session_price ?? 500}
          colors={colors}
          spacing={spacing}
          onClose={() => setShowNewMonthModal(false)}
          onConfirm={async (startDate, amountPaid) => {
            try {
              const periodDays = settings?.period_duration_days ?? 21;
              const sessionsPerPeriod = settings?.sessions_per_period ?? 4;
              const defaultPrice = settings?.default_session_price ?? 500;
              const totalAmount = defaultPrice * sessionsPerPeriod;
              const endDate = new Date(startDate);
              endDate.setDate(endDate.getDate() + periodDays);
              const status = amountPaid >= totalAmount ? 'paid' : amountPaid > 0 ? 'partial' : 'unpaid';
              await createPayment({
                student_id: student.id,
                amount: totalAmount,
                amount_paid: amountPaid,
                status,
                period_start: startDate,
                period_end: endDate.toISOString().slice(0, 10),
                session_count: sessionsPerPeriod,
                school_year_id: currentYear?.id ?? null,
              });
              setShowNewMonthModal(false);
              loadData();
            } catch (e) { /* ignore */ }
          }}
        />
      ) : null}

      {prolongPayment ? (
        <ProlongMonthModal
          payment={prolongPayment}
          colors={colors}
          spacing={spacing}
          onClose={() => setProlongPayment(null)}
          onConfirm={async (newEndDate: string) => {
            try {
              await updatePayment(prolongPayment.id, {
                period_end: newEndDate,
                notes: prolongPayment.notes
                  ? `${prolongPayment.notes}\n[Mois prolongé le ${formatDate(todayISO())} — nouvelle fin: ${formatDate(newEndDate)}]`
                  : `[Mois prolongé le ${formatDate(todayISO())} — nouvelle fin: ${formatDate(newEndDate)}]`,
              });
              setProlongPayment(null);
              loadData();
            } catch (e) { /* ignore */ }
          }}
        />
      ) : null}

      {editPaymentId ? (
        <EditPaymentModal
          payment={payments.find((p) => p.id === editPaymentId)!}
          colors={colors}
          spacing={spacing}
          onClose={() => setEditPaymentId(null)}
          onSaved={() => { setEditPaymentId(null); loadData(); }}
        />
      ) : null}

      {editing ? (
        <EditStudentModal student={student} levels={levels} onClose={() => setEditing(false)} onSaved={() => { setEditing(false); loadData(); }} />
      ) : null}

      <AddAbsenceModal visible={showAbsenceModal} onClose={() => setShowAbsenceModal(false)} onAdd={async (date, reason) => { await createAbsence({ student_id: student.id, date, reason: reason || null }); setShowAbsenceModal(false); loadData(); }} />

      {showRegularizeModal ? (
        <RegularizeModal
          debts={oldDebts}
          colors={colors}
          spacing={spacing}
          onClose={() => setShowRegularizeModal(false)}
          onRegularize={async (debtId, amount) => {
            await createPayment({
              student_id: student.id,
              amount,
              amount_paid: amount,
              status: 'paid',
              period_start: todayISO(),
              period_end: todayISO(),
              session_count: 0,
              school_year_id: currentYear?.id ?? null,
              is_regularization: true,
              regularizes_payment_id: debtId,
            });
            const debt = oldDebts.find((d) => d.id === debtId);
            if (debt) {
              const newAmountPaid = Math.min(debt.amount_paid + amount, debt.amount);
              const newStatus = newAmountPaid >= debt.amount ? 'paid' : 'partial';
              await updatePayment(debtId, { amount_paid: newAmountPaid, status: newStatus });
            }
            setShowRegularizeModal(false);
            loadData();
          }}
        />
      ) : null}

      <ConfirmDialog
        visible={confirmDeletePayment !== null}
        title="Supprimer le paiement"
        message="Êtes-vous certain de vouloir supprimer ce paiement ? Cette action est irréversible."
        confirmLabel="Supprimer"
        danger
        onConfirm={async () => { if (confirmDeletePayment) { await deletePaymentSafe(confirmDeletePayment.id); setConfirmDeletePayment(null); loadData(); } }}
        onCancel={() => setConfirmDeletePayment(null)}
      />

      <ConfirmDialog
        visible={confirmSuspend}
        title="Suspendre l'élève"
        message="Voulez-vous vraiment suspendre cet élève ? Il apparaîtra comme inactif."
        confirmLabel="Suspendre"
        danger
        onConfirm={async () => { await setStudentStatus(student.id, 'suspended'); setConfirmSuspend(false); loadData(); }}
        onCancel={() => setConfirmSuspend(false)}
      />

      <ConfirmDialog
        visible={confirmActivate}
        title="Réactiver l'élève"
        message="Voulez-vous réactiver cet élève ?"
        confirmLabel="Réactiver"
        onConfirm={async () => { await setStudentStatus(student.id, 'active'); setConfirmActivate(false); loadData(); }}
        onCancel={() => setConfirmActivate(false)}
      />

      <ConfirmDialog
        visible={confirmDeleteAbsence !== null}
        title="Supprimer l'absence"
        message="Êtes-vous certain de vouloir supprimer cette absence ?"
        confirmLabel="Supprimer"
        danger
        onConfirm={async () => { if (confirmDeleteAbsence) { await deleteAbsence(confirmDeleteAbsence); setConfirmDeleteAbsence(null); loadData(); } }}
        onCancel={() => setConfirmDeleteAbsence(null)}
      />

      <ConfirmDialog
        visible={confirmTrash}
        title="Mettre à la corbeille"
        message="L'élève sera déplacé vers la corbeille. Vous pourrez le restaurer ou le supprimer définitivement plus tard."
        confirmLabel="Corbeille"
        danger
        onConfirm={async () => { await setStudentStatus(student.id, 'trashed'); setConfirmTrash(false); router.back(); }}
        onCancel={() => setConfirmTrash(false)}
      />
    </View>
  );
}

async function deletePaymentSafe(id: string) {
  const { supabase } = await import('@/lib/supabase');
  const { error } = await supabase.from('payments').delete().eq('id', id);
  if (error) throw error;
}

function DetailRow({ label, value, colors, valueColor }: { label: string; value: string; colors: ReturnType<typeof useTheme>['colors']; valueColor?: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={[styles.detailLabel, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: valueColor ?? colors.onSurface }]}>{value}</Text>
    </View>
  );
}

function SessionBars({ sessionsDone, sessionsTotal, paymentStatus, colors }: {
  sessionsDone: number; sessionsTotal: number; paymentStatus: string; colors: ReturnType<typeof useTheme>['colors'];
}) {
  const barColor = paymentStatus === 'paid' ? colors.success : paymentStatus === 'partial' ? colors.warning : colors.error;
  const bars = [];
  for (let i = 0; i < sessionsTotal; i++) {
    bars.push(
      <View key={i} style={[styles.sessionBarItem, { backgroundColor: i < sessionsDone ? barColor : colors.surfaceVariant, borderColor: colors.outline }]} />
    );
  }
  return (
    <View style={styles.sessionBarsContainer}>
      <View style={styles.sessionBarsRow}>{bars}</View>
      <Text style={[styles.sessionBarsLabel, { color: colors.onSurfaceVariant }]}>
        {sessionsDone} / {sessionsTotal} séances
      </Text>
    </View>
  );
}

function EditStudentModal({ student, levels, onClose, onSaved }: {
  student: StudentWithRelations; levels: Level[]; onClose: () => void; onSaved: () => void;
}) {
  const { colors, spacing, radius } = useTheme();
  const [fullName, setFullName] = useState(student.full_name);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(student.level_id);
  const [notes, setNotes] = useState(student.notes ?? '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateStudent(student.id, {
        full_name: fullName.trim(),
        level_id: selectedLevel,
        notes: notes.trim() || null,
      });
      onSaved();
    } catch (e) { /* ignore */ } finally { setSaving(false); }
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Modifier l'élève</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <FieldInput label="Nom complet *" value={fullName} onChangeText={setFullName} />
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Niveau</Text>
            <View style={styles.pillRow}>
              {levels.map((lvl) => (
                <Pressable key={lvl.id} onPress={() => setSelectedLevel(selectedLevel === lvl.id ? null : lvl.id)} style={[styles.pill, { backgroundColor: selectedLevel === lvl.id ? colors.primary : colors.surfaceVariant, borderColor: colors.outline }]}>
                  <Text style={{ color: selectedLevel === lvl.id ? colors.onPrimary : colors.onSurfaceVariant, fontSize: 13, fontWeight: '600' }}>{lvl.name}</Text>
                </Pressable>
              ))}
            </View>
            <FieldInput label="Notes" value={notes} onChangeText={setNotes} multiline />
          </ScrollView>
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label={saving ? '...' : 'Enregistrer'} variant="filled" onPress={handleSave} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function AddAbsenceModal({ visible, onClose, onAdd }: {
  visible: boolean; onClose: () => void; onAdd: (date: string, reason: string) => void;
}) {
  const { colors, spacing, radius } = useTheme();
  const [date, setDate] = useState(todayISO());
  const [reason, setReason] = useState('');

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Ajouter une absence</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <DatePickerField label="Date de l'absence" value={date} onChange={setDate} placeholder="Sélectionner" />
            <FieldInput label="Raison" value={reason} onChangeText={setReason} placeholder="Maladie, voyage..." multiline />
          </ScrollView>
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label="Ajouter" variant="filled" onPress={() => onAdd(date, reason)} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function RegularizeModal({ debts, colors, spacing, onClose, onRegularize }: {
  debts: OldDebt[];
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  onClose: () => void;
  onRegularize: (debtId: string, amount: number) => void;
}) {
  const [selectedDebt, setSelectedDebt] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [err, setErr] = useState<string | null>(null);

  const handleRegularize = () => {
    if (!selectedDebt) { setErr('Sélectionnez une dette à régulariser'); return; }
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) { setErr('Montant invalide'); return; }
    onRegularize(selectedDebt, amt);
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: 20, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <TrendingUp size={22} color={colors.warning} />
              <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Régulariser une dette</Text>
            </View>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            {debts.length === 0 ? (
              <Text style={{ fontSize: 14, color: colors.onSurfaceVariant, textAlign: 'center', paddingVertical: spacing.lg }}>
                Aucune dette de période clôturée à régulariser.
              </Text>
            ) : (
              <>
                <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Dette à régulariser *</Text>
                <View style={{ gap: 8, marginTop: 4 }}>
                  {debts.map((d) => (
                    <Pressable key={d.id} onPress={() => { setSelectedDebt(d.id); setAmount(String(d.debt)); }} style={[styles.debtOption, { backgroundColor: selectedDebt === d.id ? colors.warningContainer : colors.surfaceVariant, borderColor: selectedDebt === d.id ? colors.warning : 'transparent' }]}>
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontSize: 14, fontWeight: '600', color: selectedDebt === d.id ? colors.onWarningContainer : colors.onSurface }}>{d.period_name}</Text>
                        <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 2 }}>
                          {formatDate(d.period_start)} → {formatDate(d.period_end)} — Reste: {formatCurrency(d.debt)}
                        </Text>
                      </View>
                      <Text style={{ fontSize: 15, fontWeight: '700', color: colors.error }}>{formatCurrency(d.debt)}</Text>
                    </Pressable>
                  ))}
                </View>
                {selectedDebt ? (
                  <View style={{ marginTop: spacing.sm }}>
                    <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant à régulariser (DZD)</Text>
                    <TextInput
                      value={amount}
                      onChangeText={setAmount}
                      placeholder="0"
                      placeholderTextColor={colors.onSurfaceVariant}
                      keyboardType="numeric"
                      style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: 12, color: colors.onSurface, paddingHorizontal: 16, height: 48, marginTop: 4 }]}
                    />
                  </View>
                ) : null}
              </>
            )}
            {err ? <Text style={{ fontSize: 13, color: colors.error, marginTop: 8, textAlign: 'center' }}>{err}</Text> : null}
          </ScrollView>
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label="Régulariser" variant="filled" onPress={handleRegularize} disabled={debts.length === 0} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function NewMonthModal({ monthNumber, periodDurationDays, sessionsPerPeriod, defaultSessionPrice, colors, spacing, onClose, onConfirm }: {
  monthNumber: number;
  periodDurationDays: number;
  sessionsPerPeriod: number;
  defaultSessionPrice: number;
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  onClose: () => void;
  onConfirm: (startDate: string, amountPaid: number) => void;
}) {
  const { radius } = useTheme();
  const [startDate, setStartDate] = useState(todayISO());
  const [amountPaidStr, setAmountPaidStr] = useState('0');
  const [err, setErr] = useState<string | null>(null);

  const totalAmount = defaultSessionPrice * sessionsPerPeriod;
  const computedEndDate = startDate ? addDays(startDate, periodDurationDays) : '—';
  const monthLabel = monthNumber <= MONTH_LABELS.length ? MONTH_LABELS[monthNumber - 1] : `Mois ${monthNumber}`;

  const handleConfirm = () => {
    if (!startDate) { setErr('Sélectionnez une date de début'); return; }
    const paid = parseFloat(amountPaidStr);
    if (isNaN(paid) || paid < 0) { setErr('Montant payé invalide'); return; }
    onConfirm(startDate, paid);
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <CalendarPlus size={22} color={colors.primary} />
              <Text style={[styles.modalTitle, { color: colors.onSurface }]}>{monthLabel}</Text>
            </View>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>

          <ScrollView style={{ maxHeight: 500 }}>
            <DatePickerField label="Date de début du mois *" value={startDate} onChange={setStartDate} placeholder="Sélectionner une date" />

            <View style={{ backgroundColor: colors.surfaceVariant, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm }}>
              <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Date de fin calculée automatiquement</Text>
              <Text style={{ fontSize: 16, fontWeight: '700', color: colors.primary, marginTop: 4 }}>
                {formatDate(computedEndDate)}
              </Text>
              <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 4 }}>
                Durée: {periodDurationDays} jours · {sessionsPerPeriod} séances
              </Text>
            </View>

            <View style={{ marginTop: spacing.sm }}>
              <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant total (DZD)</Text>
              <Text style={{ fontSize: 16, fontWeight: '700', color: colors.onSurface, marginTop: 4 }}>
                {formatCurrency(totalAmount)}
              </Text>
            </View>

            <View style={{ marginTop: spacing.sm }}>
              <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant payé (DZD)</Text>
              <TextInput
                value={amountPaidStr}
                onChangeText={setAmountPaidStr}
                placeholder="0"
                placeholderTextColor={colors.onSurfaceVariant}
                keyboardType="numeric"
                style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
              />
              <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 6 }}>
                Saisissez 0 pour un mois non payé, le montant total pour un paiement complet, ou un montant intermédiaire pour un paiement partiel.
              </Text>
            </View>

            {err ? <Text style={{ fontSize: 13, color: colors.error, marginTop: 8, textAlign: 'center' }}>{err}</Text> : null}
          </ScrollView>

          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label="Créer le mois" variant="filled" onPress={handleConfirm} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function ProlongMonthModal({ payment, colors, spacing, onClose, onConfirm }: {
  payment: Payment;
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  onClose: () => void;
  onConfirm: (newEndDate: string) => void;
}) {
  const [duration, setDuration] = useState<number | null>(null);
  const [customDays, setCustomDays] = useState('');
  const { radius } = useTheme();

  const options = [
    { days: 7, label: '+7 jours' },
    { days: 14, label: '+14 jours' },
    { days: 21, label: '+21 jours' },
  ];

  const selectedDays = duration ?? (parseInt(customDays, 10) || 0);
  const newEndDate = addDays(payment.period_end, selectedDays);

  const handleConfirm = () => {
    if (selectedDays <= 0) return;
    onConfirm(newEndDate);
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Prolonger le mois</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>

          <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Mois actuel</Text>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.onSurface, marginBottom: spacing.sm }}>
            {formatDate(payment.period_start)} → {formatDate(payment.period_end)}
          </Text>

          <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Choisir la prolongation</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: spacing.sm }}>
            {options.map((opt) => (
              <Pressable
                key={opt.days}
                onPress={() => { setDuration(opt.days); setCustomDays(''); }}
                style={[styles.pill, { backgroundColor: duration === opt.days ? colors.primary : colors.surfaceVariant, borderColor: duration === opt.days ? colors.primary : colors.outline }]}
              >
                <Text style={{ fontSize: 13, fontWeight: '600', color: duration === opt.days ? colors.onPrimary : colors.onSurfaceVariant }}>{opt.label}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Durée personnalisée (jours)</Text>
          <TextInput
            value={customDays}
            onChangeText={(v) => { setCustomDays(v); setDuration(null); }}
            placeholder="Ex: 10"
            placeholderTextColor={colors.onSurfaceVariant}
            keyboardType="numeric"
            style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
          />

          {selectedDays > 0 ? (
            <View style={{ backgroundColor: colors.surfaceVariant, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm }}>
              <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Nouvelle date de fin</Text>
              <Text style={{ fontSize: 16, fontWeight: '700', color: colors.primary }}>{formatDate(newEndDate)}</Text>
              <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 4 }}>
                Date de début conservée: {formatDate(payment.period_start)}
              </Text>
            </View>
          ) : null}

          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label="Confirmer" variant="filled" onPress={handleConfirm} disabled={selectedDays <= 0} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function EditPaymentModal({ payment, colors, spacing, onClose, onSaved }: {
  payment: Payment;
  colors: ReturnType<typeof useTheme>['colors'];
  spacing: ReturnType<typeof useTheme>['spacing'];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { radius } = useTheme();
  const [amount, setAmount] = useState(String(payment.amount));
  const [amountPaid, setAmountPaid] = useState(String(payment.amount_paid));
  const [notes, setNotes] = useState(payment.notes ?? '');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const handleSave = async () => {
    const amt = parseFloat(amount);
    const paid = parseFloat(amountPaid);
    if (isNaN(amt) || amt < 0) { setErr('Montant total invalide'); return; }
    if (isNaN(paid) || paid < 0) { setErr('Montant payé invalide'); return; }
    setSaving(true); setErr(null);
    try {
      const status = paid >= amt ? 'paid' : paid <= 0 ? 'unpaid' : 'partial';
      await updatePayment(payment.id, { amount: amt, amount_paid: paid, status, notes: notes.trim() || null });
      onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.editModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Modifier le paiement</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>

          <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Mois</Text>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.onSurface, marginBottom: spacing.sm }}>
            {formatDate(payment.period_start)} → {formatDate(payment.period_end)}
          </Text>

          <View style={{ marginTop: spacing.sm }}>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant total (DZD)</Text>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              keyboardType="numeric"
              style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
            />
          </View>

          <View style={{ marginTop: spacing.sm }}>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant payé (DZD)</Text>
            <TextInput
              value={amountPaid}
              onChangeText={setAmountPaid}
              keyboardType="numeric"
              style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
            />
          </View>

          <View style={{ marginTop: spacing.sm }}>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Observations</Text>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              multiline
              style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, minHeight: 60, textAlignVertical: 'top', paddingTop: spacing.sm, marginTop: 4 }]}
            />
          </View>

          {err ? <Text style={{ fontSize: 13, color: colors.error, marginTop: 8, textAlign: 'center' }}>{err}</Text> : null}

          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label={saving ? '...' : 'Enregistrer'} variant="filled" onPress={handleSave} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function FieldInput({ label, value, onChangeText, placeholder, multiline, keyboardType }: {
  label: string; value: string; onChangeText: (v: string) => void; placeholder?: string; multiline?: boolean; keyboardType?: 'default' | 'numeric';
}) {
  const { colors, radius, spacing } = useTheme();
  return (
    <View style={{ marginTop: spacing.sm }}>
      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.onSurfaceVariant}
        multiline={multiline}
        keyboardType={keyboardType ?? 'default'}
        style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md }, multiline && { minHeight: 60, textAlignVertical: 'top', paddingTop: spacing.sm }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  backBtn: { padding: 8 },
  topTitle: { fontSize: 18, fontWeight: '700', flex: 1, textAlign: 'center' },
  profileNameUpper: { fontSize: 22, fontWeight: '800', marginTop: 12, letterSpacing: 0.5, textAlign: 'center' },
  profileLevel: { fontSize: 14, marginTop: 4, textAlign: 'center' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  statusBadgeText: { fontSize: 12, fontWeight: '700' },
  pauseBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  pauseBtnText: { fontSize: 12, fontWeight: '600' },
  finHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  finTitle: { fontSize: 16, fontWeight: '700' },
  finCol: { flex: 1, alignItems: 'center' },
  finLabel: { fontSize: 12, fontWeight: '500' },
  finValue: { fontSize: 16, fontWeight: '700', marginTop: 4 },
  sectionTitle: { fontSize: 18, fontWeight: '700' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  addAbsenceBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999 },
  addAbsenceText: { fontSize: 13, fontWeight: '600' },
  emptyText: { fontSize: 14, marginTop: 8 },
  periodCardHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  numberBadge: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  numberText: { fontSize: 15, fontWeight: '700' },
  monthLabel: { fontSize: 15, fontWeight: '700' },
  periodDates: { fontSize: 12, marginTop: 2 },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  detailLabel: { fontSize: 13, fontWeight: '500' },
  detailValue: { fontSize: 13, fontWeight: '600' },
  periodActions: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  deleteIconBtn: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  closedBadgeRow: { flexDirection: 'row', justifyContent: 'flex-start' },
  closedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  closedBadgeText: { fontSize: 11, fontWeight: '600' },
  absenceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  absenceDate: { fontSize: 14, fontWeight: '600' },
  absenceReason: { fontSize: 12, marginTop: 2 },
  sessionBarsContainer: { marginTop: 4 },
  sessionBarsRow: { flexDirection: 'row', gap: 6 },
  sessionBarItem: { flex: 1, height: 8, borderRadius: 4, borderWidth: StyleSheet.hairlineWidth },
  sessionBarsLabel: { fontSize: 11, fontWeight: '500', marginTop: 4 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  editModal: { width: '100%', maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '700' },
  fieldLabel: { fontSize: 13, fontWeight: '500', marginBottom: 6 },
  input: { height: 48, fontSize: 15 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: StyleSheet.hairlineWidth },
  modalActions: { flexDirection: 'row', marginTop: 16 },

  debtOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14, borderRadius: 12, borderWidth: 2 },
});
