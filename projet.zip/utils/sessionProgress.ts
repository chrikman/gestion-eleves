import type { Payment } from '@/types';

/**
 * Nombre de séances qui auraient dû avoir lieu à l'instant T,
 * réparties uniformément sur la durée de la période.
 */
export function computeExpectedSessions(payment: Pick<Payment, 'period_start' | 'period_end' | 'session_count'>): number {
  const total = payment.session_count ?? 0;
  if (total <= 0) return 0;

  const start = new Date(payment.period_start).getTime();
  const end = new Date(payment.period_end).getTime();
  const now = Date.now();

  if (now <= start) return 0;
  if (now >= end) return total;

  const fraction = (now - start) / (end - start);
  return Math.min(Math.floor(fraction * total), total);
}

/**
 * Nombre de séances affichées: le maximum entre ce qui a été validé
 * manuellement et ce que le temps écoulé implique. La progression
 * se base par défaut sur la date/heure actuelles, tout en conservant
 * la possibilité de corriger manuellement (à la hausse).
 */
export function getEffectiveSessionsCompleted(payment: Pick<Payment, 'sessions_completed' | 'period_start' | 'period_end' | 'session_count'>): number {
  const manual = payment.sessions_completed ?? 0;
  const expected = computeExpectedSessions(payment);
  return Math.max(manual, expected);
}
