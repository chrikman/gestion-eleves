export function getPaymentColorKey(status: string): 'success' | 'error' | 'warning' | 'info' {
  switch (status) {
    case 'paid': return 'success';
    case 'unpaid': return 'error';
    case 'partial': return 'warning';
    case 'single': return 'info';
    default: return 'info';
  }
}
