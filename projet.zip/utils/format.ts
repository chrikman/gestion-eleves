export function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function formatDateLong(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function computePeriodEnd(startStr: string, durationDays: number): string {
  return addDays(startStr, durationDays);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('fr-DZ', {
    style: 'currency',
    currency: 'DZD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function getInitials(fullName: string): string {
  if (!fullName) return '?';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0][0]?.toUpperCase() ?? '?';
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function getPaymentStatusLabel(status: string): string {
  switch (status) {
    case 'paid': return 'Réglé';
    case 'unpaid': return 'En dette';
    case 'partial': return 'Paiement partiel';
    case 'single': return 'Séance unique';
    default: return status;
  }
}

export function getGenderColor(gender: 'male' | 'female' | null): string {
  if (gender === 'female') return '#EC4899';
  if (gender === 'male') return '#3B82F6';
  return '#1F2937';
}

export function getStudentStatusLabel(status: string): string {
  switch (status) {
    case 'active': return 'Actif';
    case 'suspended': return 'Suspendu';
    case 'trashed': return 'Corbeille';
    default: return status;
  }
}
