import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { Card } from './Card';

interface StatCardProps {
  label: string;
  value: string | number;
  colorKey?: 'primary' | 'success' | 'error' | 'warning' | 'info' | 'neutral';
  icon?: React.ReactNode;
}

export function StatCard({ label, value, colorKey = 'primary', icon }: StatCardProps) {
  const { colors, spacing, typography } = useTheme();

  const accentMap: Record<string, string> = {
    primary: colors.primary,
    success: colors.success,
    error: colors.error,
    warning: colors.warning,
    info: colors.info,
    neutral: colors.onSurfaceVariant,
  };
  const accent = accentMap[colorKey] ?? colors.primary;

  return (
    <Card elevation={1} style={{ padding: spacing.md, flex: 1 }}>
      <View style={styles.row}>
        {icon ? <View style={[styles.iconWrap, { backgroundColor: accent + '1A' }]}>{icon}</View> : null}
        <View style={{ flex: 1 }}>
          <Text style={[styles.label, { color: colors.onSurfaceVariant }]} numberOfLines={1}>
            {label}
          </Text>
          <Text style={[styles.value, { color: colors.onSurface }]} numberOfLines={1}>
            {value}
          </Text>
        </View>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: 12,
    fontWeight: '500',
    marginBottom: 2,
  },
  value: {
    fontSize: 20,
    fontWeight: '700',
  },
});
