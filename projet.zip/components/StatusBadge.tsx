import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';

interface StatusBadgeProps {
  label: string;
  colorKey: 'success' | 'error' | 'warning' | 'info' | 'neutral';
}

export function StatusBadge({ label, colorKey }: StatusBadgeProps) {
  const { colors } = useTheme();

  const colorMap: Record<string, { bg: string; fg: string }> = {
    success: { bg: colors.successContainer, fg: colors.onSuccessContainer },
    error: { bg: colors.errorContainer, fg: colors.onErrorContainer },
    warning: { bg: colors.warningContainer, fg: colors.onWarningContainer },
    info: { bg: colors.infoContainer, fg: colors.onInfoContainer },
    neutral: { bg: colors.surfaceVariant, fg: colors.onSurfaceVariant },
  };

  const c = colorMap[colorKey] ?? colorMap.neutral;

  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.text, { color: c.fg }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: 12,
    fontWeight: '600',
  },
});
