import React from 'react';
import { TextInput, StyleSheet, View } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { Search } from 'lucide-react-native';

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
}

export function SearchBar({ value, onChangeText, placeholder = 'Rechercher...' }: SearchBarProps) {
  const { colors, radius, spacing } = useTheme();
  return (
    <View
      style={[
        styles.container,
        { backgroundColor: colors.surfaceVariant, borderRadius: radius.xl, paddingHorizontal: spacing.md },
      ]}
    >
      <Search size={20} color={colors.onSurfaceVariant} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.onSurfaceVariant}
        style={[styles.input, { color: colors.onSurface }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 48,
  },
  input: {
    flex: 1,
    fontSize: 15,
    marginLeft: 10,
    padding: 0,
  },
});
