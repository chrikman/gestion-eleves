import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { getInitials } from '@/utils/format';

interface StudentAvatarProps {
  fullName: string;
  size?: number;
}

export function StudentAvatar({ fullName, size = 44 }: StudentAvatarProps) {
  const { colors, radius } = useTheme();
  return (
    <View
      style={[
        styles.avatar,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.primaryContainer,
        },
      ]}
    >
      <Text style={[styles.text, { color: colors.onPrimaryContainer, fontSize: size * 0.36 }]}>
        {getInitials(fullName)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  avatar: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontWeight: '700',
  },
});
