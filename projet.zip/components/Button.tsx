import React from 'react';
import { Pressable, Text, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'filled' | 'tonal' | 'outlined' | 'text' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  icon?: React.ReactNode;
}

export function Button({
  label,
  onPress,
  variant = 'filled',
  size = 'md',
  disabled,
  style,
  icon,
}: ButtonProps) {
  const { colors, radius, spacing } = useTheme();

  const height = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  const fontSize = size === 'sm' ? 13 : size === 'lg' ? 16 : 14;

  let bg = colors.primary;
  let fg = colors.onPrimary;
  let borderC = 'transparent';

  if (variant === 'tonal') {
    bg = colors.primaryContainer;
    fg = colors.onPrimaryContainer;
  } else if (variant === 'outlined') {
    bg = 'transparent';
    fg = colors.primary;
    borderC = colors.outline;
  } else if (variant === 'text') {
    bg = 'transparent';
    fg = colors.primary;
  } else if (variant === 'danger') {
    bg = colors.error;
    fg = colors.onError;
  }

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.base,
        {
          height,
          borderRadius: radius.xl,
          backgroundColor: bg,
          borderColor: borderC,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      {icon}
      <Text style={[styles.label, { color: fg, fontSize, paddingHorizontal: spacing.sm }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'transparent',
  },
  label: {
    fontWeight: '600',
  },
});
