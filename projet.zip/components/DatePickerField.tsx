import React, { useState } from 'react';
import { Platform, Pressable, View, Text, StyleSheet, Modal } from 'react-native';
import { useTheme } from '@/theme/ThemeContext';
import { formatDate } from '@/utils/format';
import { Calendar, X, ChevronLeft, ChevronRight } from 'lucide-react-native';

interface DatePickerFieldProps {
  label: string;
  value: string;
  onChange: (dateStr: string) => void;
  placeholder?: string;
}

export function DatePickerField({ label, value, onChange, placeholder }: DatePickerFieldProps) {
  const { colors, radius, spacing } = useTheme();
  const [show, setShow] = useState(false);

  const parsed = value ? new Date(value + 'T00:00:00') : new Date();
  const isValid = value && !isNaN(parsed.getTime());

  const handleChange = (dateStr: string) => {
    onChange(dateStr);
    setShow(false);
  };

  return (
    <View style={{ marginTop: spacing.sm }}>
      <Text style={[styles.label, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <Pressable
        onPress={() => setShow(true)}
        style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, paddingHorizontal: spacing.md, borderColor: colors.outline, borderWidth: StyleSheet.hairlineWidth }]}
      >
        <Calendar size={18} color={colors.onSurfaceVariant} />
        <Text style={[styles.valueText, { color: isValid ? colors.onSurface : colors.onSurfaceVariant }]}>
          {isValid ? formatDate(value) : (placeholder ?? 'Sélectionner une date')}
        </Text>
      </Pressable>

      {show ? (
        <WebDatePickerModal
          initialDate={isValid ? parsed : new Date()}
          onConfirm={handleChange}
          onCancel={() => setShow(false)}
        />
      ) : null}
    </View>
  );
}

function WebDatePickerModal({
  initialDate,
  onConfirm,
  onCancel,
}: {
  initialDate: Date;
  onConfirm: (dateStr: string) => void;
  onCancel: () => void;
}) {
  const { colors, radius, spacing } = useTheme();
  const [viewDate, setViewDate] = useState(new Date(initialDate.getFullYear(), initialDate.getMonth(), 1));
  const [selected, setSelected] = useState(initialDate);

  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
  ];
  const dayNames = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  // Monday = 0
  const startOffset = (firstDay.getDay() + 6) % 7;

  const cells: (Date | null)[] = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);

  const isSameDay = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  const prevMonth = () => setViewDate(new Date(year, month - 1, 1));
  const nextMonth = () => setViewDate(new Date(year, month + 1, 1));

  const toISO = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onCancel}>
      <Pressable style={styles.overlay} onPress={onCancel}>
        <Pressable
          onPress={(e) => e.stopPropagation()}
          style={[styles.calendarSheet, { backgroundColor: colors.surface, borderRadius: radius.lg }]}
        >
          <View style={[styles.calHeader, { borderBottomColor: colors.divider, borderBottomWidth: StyleSheet.hairlineWidth }]}>
            <Pressable onPress={prevMonth} style={styles.navBtn}><ChevronLeft size={22} color={colors.onSurface} /></Pressable>
            <Text style={[styles.calTitle, { color: colors.onSurface }]}>{monthNames[month]} {year}</Text>
            <Pressable onPress={nextMonth} style={styles.navBtn}><ChevronRight size={22} color={colors.onSurface} /></Pressable>
          </View>

          <View style={styles.weekRow}>
            {dayNames.map((dn, i) => (
              <Text key={i} style={[styles.weekDay, { color: colors.onSurfaceVariant }]}>{dn}</Text>
            ))}
          </View>

          <View style={styles.daysGrid}>
            {cells.map((cell, i) => {
              if (!cell) return <View key={i} style={styles.dayCell} />;
              const isSelected = isSameDay(cell, selected);
              return (
                <Pressable
                  key={i}
                  onPress={() => setSelected(cell)}
                  style={[
                    styles.dayCell,
                    styles.dayCellPress,
                    isSelected && { backgroundColor: colors.primary, borderRadius: radius.sm },
                  ]}
                >
                  <Text style={[styles.dayText, { color: isSelected ? colors.onPrimary : colors.onSurface }]}>
                    {cell.getDate()}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <View style={[styles.calActions, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
            <Pressable onPress={onCancel} style={styles.calBtn}><Text style={[styles.calBtnText, { color: colors.onSurfaceVariant }]}>Annuler</Text></Pressable>
            <Pressable onPress={() => onConfirm(toISO(selected))} style={[styles.calBtn, { backgroundColor: colors.primary, borderRadius: radius.sm }]}>
              <Text style={[styles.calBtnText, { color: colors.onPrimary }]}>Confirmer</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 13, fontWeight: '500', marginBottom: 6 },
  input: { flexDirection: 'row', alignItems: 'center', gap: 10, height: 48 },
  valueText: { fontSize: 15, fontWeight: '500' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  calendarSheet: { width: '100%', maxWidth: 360, padding: 16 },
  calHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 12 },
  navBtn: { padding: 8 },
  calTitle: { fontSize: 17, fontWeight: '700' },
  weekRow: { flexDirection: 'row', marginTop: 8 },
  weekDay: { flex: 1, textAlign: 'center', fontSize: 12, fontWeight: '600', paddingVertical: 6 },
  daysGrid: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 },
  dayCell: { width: '14.28%', aspectRatio: 1, alignItems: 'center', justifyContent: 'center' },
  dayCellPress: { alignItems: 'center', justifyContent: 'center' },
  dayText: { fontSize: 15, fontWeight: '500' },
  calActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8, marginTop: 12, paddingTop: 12 },
  calBtn: { paddingHorizontal: 20, paddingVertical: 10 },
  calBtnText: { fontSize: 14, fontWeight: '600' },
});
