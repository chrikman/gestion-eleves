/*
# Soutien 2027 — Schéma initial

Application de gestion de soutien scolaire pour un professeur de français.
Application mono-utilisateur (un seul professeur, pas de comptes multiples).
La protection par mot de passe est gérée côté application, pas via Supabase Auth.

1. Nouvelles tables

- `levels` (niveaux scolaires)
  - id (uuid, PK)
  - name (text, ex: 1AM, 2AM, 3AM, 4AM)
  - label (text, libellé complet optionnel)
  - sort_order (int, ordre d'affichage)
  - archived (boolean, default false)
  - created_at (timestamptz)

- `students` (élèves)
  - id (uuid, PK)
  - first_name (text, prénom)
  - last_name (text, nom)
  - level_id (uuid, FK vers levels, nullable pour élèves non réinscrits)
  - phone (text, téléphone élève, optionnel)
  - parent_phone (text, téléphone parent, optionnel)
  - status (text: 'active' | 'suspended' | 'trashed', default 'active')
  - enrollment_date (date, date d'inscription)
  - notes (text, optionnel)
  - school_year_id (uuid, FK vers school_years)
  - created_at, updated_at (timestamptz)

- `payments` (paiements)
  - id (uuid, PK)
  - student_id (uuid, FK vers students)
  - amount (numeric, montant total dû pour la période)
  - amount_paid (numeric, montant effectivement payé)
  - status (text: 'paid' | 'unpaid' | 'partial' | 'single', default 'unpaid')
  - period_start (date, début de la période de 4 séances)
  - period_end (date, fin calculée automatiquement, modifiable)
  - session_count (int, nombre de séances, default 4)
  - receipt_number (text, numéro de reçu unique)
  - school_year_id (uuid, FK vers school_years)
  - notes (text, optionnel, ex: raison de prolongation vacances)
  - created_at (timestamptz)

- `absences` (historique des absences)
  - id (uuid, PK)
  - student_id (uuid, FK vers students)
  - date (date)
  - reason (text, optionnel)
  - session_index (int, numéro de séance dans la période, optionnel)
  - created_at (timestamptz)

- `school_years` (années scolaires)
  - id (uuid, PK)
  - name (text, ex: 2026-2027)
  - start_date (date)
  - end_date (date)
  - is_current (boolean, default false)
  - created_at (timestamptz)

- `settings` (paramètres de l'application, stockage clé-valeur)
  - key (text, PK)
  - value (jsonb, valeur du paramètre)
  - updated_at (timestamptz)

2. Sécurité
- RLS activée sur toutes les tables.
- Application mono-utilisateur sans écran de connexion Supabase :
  politiques ouvertes à `anon, authenticated` car les données sont
  intentionnellement partagées (un seul professeur utilise l'app).
  La protection par mot de passe est une serrure côté application.

3. Notes importantes
- Les élèves "supprimés" ne sont jamais effacés : leur statut passe à 'trashed'
  (corbeille) puis restauration ou suppression définitive.
- `receipt_number` est unique pour permettre l'impression de reçus.
- Un seul `school_year` peut avoir is_current = true (géré côté application).
*/

CREATE TABLE IF NOT EXISTS levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  label text,
  sort_order int NOT NULL DEFAULT 0,
  archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE levels ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_levels" ON levels;
CREATE POLICY "anon_select_levels" ON levels FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_levels" ON levels;
CREATE POLICY "anon_insert_levels" ON levels FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_levels" ON levels;
CREATE POLICY "anon_update_levels" ON levels FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_levels" ON levels;
CREATE POLICY "anon_delete_levels" ON levels FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS school_years (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  is_current boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE school_years ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_school_years" ON school_years;
CREATE POLICY "anon_select_school_years" ON school_years FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_school_years" ON school_years;
CREATE POLICY "anon_insert_school_years" ON school_years FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_school_years" ON school_years;
CREATE POLICY "anon_update_school_years" ON school_years FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_school_years" ON school_years;
CREATE POLICY "anon_delete_school_years" ON school_years FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  level_id uuid REFERENCES levels(id) ON DELETE SET NULL,
  phone text,
  parent_phone text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','trashed')),
  enrollment_date date,
  notes text,
  school_year_id uuid REFERENCES school_years(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_students" ON students;
CREATE POLICY "anon_select_students" ON students FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_students" ON students;
CREATE POLICY "anon_insert_students" ON students FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_students" ON students;
CREATE POLICY "anon_update_students" ON students FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_students" ON students;
CREATE POLICY "anon_delete_students" ON students FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL DEFAULT 0,
  amount_paid numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('paid','unpaid','partial','single')),
  period_start date NOT NULL,
  period_end date NOT NULL,
  session_count int NOT NULL DEFAULT 4,
  receipt_number text UNIQUE,
  school_year_id uuid REFERENCES school_years(id) ON DELETE SET NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_payments" ON payments;
CREATE POLICY "anon_select_payments" ON payments FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_payments" ON payments;
CREATE POLICY "anon_insert_payments" ON payments FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_payments" ON payments;
CREATE POLICY "anon_update_payments" ON payments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_payments" ON payments;
CREATE POLICY "anon_delete_payments" ON payments FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS absences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  date date NOT NULL,
  reason text,
  session_index int,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE absences ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_absences" ON absences;
CREATE POLICY "anon_select_absences" ON absences FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_absences" ON absences;
CREATE POLICY "anon_insert_absences" ON absences FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_absences" ON absences;
CREATE POLICY "anon_update_absences" ON absences FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_absences" ON absences;
CREATE POLICY "anon_delete_absences" ON absences FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_settings" ON settings;
CREATE POLICY "anon_delete_settings" ON settings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_students_level_id ON students(level_id);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
CREATE INDEX IF NOT EXISTS idx_students_school_year_id ON students(school_year_id);
CREATE INDEX IF NOT EXISTS idx_payments_student_id ON payments(student_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_school_year_id ON payments(school_year_id);
CREATE INDEX IF NOT EXISTS idx_absences_student_id ON absences(student_id);
CREATE INDEX IF NOT EXISTS idx_absences_date ON absences(date);
