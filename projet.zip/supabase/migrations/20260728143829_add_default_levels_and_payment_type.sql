/*
# Niveaux par defaut et type de paiement

1. Donnees initiales
- Insertion des niveaux du college algerien (1AM, 2AM, 3AM, 4AM)
  et un niveau "Autre" pour les cas speciaux.

2. Modifications
- Ajout de la colonne `payment_type` (text) a la table `payments`.
  Valeurs: 'monthly' (mensuel), 'per_session' (par seance),
  'social_case' (cas social).
  Valeur par defaut: 'monthly'.

3. Notes
- Le niveau est desormais obligatoire lors de l'inscription d'un eleve.
- Le type de paiement permet de distinguer un eleve qui paie par mois,
  un eleve qui paie seance par seance, et un cas social.
*/

INSERT INTO levels (name, label, sort_order, archived)
VALUES
  ('1AM', '1ère Année Moyenne', 1, false),
  ('2AM', '2ème Année Moyenne', 2, false),
  ('3AM', '3ème Année Moyenne', 3, false),
  ('4AM', '4ème Année Moyenne', 4, false),
  ('Autre', 'Autre niveau', 5, false)
ON CONFLICT DO NOTHING;

ALTER TABLE payments ADD COLUMN IF NOT EXISTS payment_type text NOT NULL DEFAULT 'monthly'
  CHECK (payment_type IN ('monthly', 'per_session', 'social_case'));
