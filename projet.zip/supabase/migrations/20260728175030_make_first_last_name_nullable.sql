/*
# Rendre first_name et last_name optionnels

Les colonnes first_name et last_name sont encore NOT NULL dans la table
students, ce qui bloque l'insertion d'un eleve via full_name uniquement.
On les rend nullables pour que l'application puisse inserer un eleve
avec seulement full_name.
*/

ALTER TABLE students ALTER COLUMN first_name DROP NOT NULL;
ALTER TABLE students ALTER COLUMN last_name DROP NOT NULL;
