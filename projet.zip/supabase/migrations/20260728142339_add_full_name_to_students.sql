/*
# Ajout du champ full_name et ajustements

1. Modifications
- Ajout de la colonne `full_name` (text) à la table `students`.
  Le professeur saisit un seul nom complet au lieu de prénom + nom séparés.
  Les anciennes colonnes first_name / last_name sont conservées pour
  compatibilité mais ne sont plus utilisées par l'application.

2. Notes
- Aucune donnée n'est perdue : first_name et last_name restent intacts.
- L'application utilise désormais full_name partout.
*/

ALTER TABLE students ADD COLUMN IF NOT EXISTS full_name text;

UPDATE students SET full_name = COALESCE(first_name, '') || ' ' || COALESCE(last_name, '') WHERE full_name IS NULL OR full_name = ' ';

ALTER TABLE students ALTER COLUMN full_name SET NOT NULL;
