/*
# Régularisation des anciennes dettes + champs de clôture de période

1. Nouveaux champs sur `payments`
- `is_regularization` (boolean, default false) : identifie un encaissement de régularisation
  d'une dette d'une période précédente clôturée.
- `regularizes_payment_id` (uuid, FK vers payments, nullable) : référence vers le paiement
  de la période clôturée dont la dette est régularisée.
- `operation_timestamp` (timestamptz) : date+heure précise de l'opération (en plus de created_at).

2. Nouveaux champs sur `periods`
- `is_active` (boolean, default false) : une seule période active à la fois.
- `pin_protected` (boolean, default false) : la période clôturée est protégée par code PIN.

3. Nouveaux champs sur `operations_log`
- `operation_timestamp` (timestamptz) : date+heure précise de l'opération.

4. Index
- Index sur `payments.regularizes_payment_id` pour retrouver rapidement les régularisations.
- Index sur `payments.is_regularization` pour filtrer les régularisations.
- Index sur `periods.is_active`.

5. Sécurité
- Aucun changement de politique : les nouvelles colonnes héritent des politiques existantes.
*/

-- Nouveaux champs sur payments
ALTER TABLE payments ADD COLUMN IF NOT EXISTS is_regularization boolean NOT NULL DEFAULT false;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS regularizes_payment_id uuid REFERENCES payments(id) ON DELETE SET NULL;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS operation_timestamp timestamptz;

-- Nouveaux champs sur periods
ALTER TABLE periods ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT false;
ALTER TABLE periods ADD COLUMN IF NOT EXISTS pin_protected boolean NOT NULL DEFAULT false;

-- Nouveaux champs sur operations_log
ALTER TABLE operations_log ADD COLUMN IF NOT EXISTS operation_timestamp timestamptz;

-- Index
CREATE INDEX IF NOT EXISTS idx_payments_regularizes_payment_id ON payments(regularizes_payment_id);
CREATE INDEX IF NOT EXISTS idx_payments_is_regularization ON payments(is_regularization);
CREATE INDEX IF NOT EXISTS idx_periods_is_active ON periods(is_active);

-- Une seule période active à la fois : trigger pour désactiver les autres
CREATE OR REPLACE FUNCTION ensure_single_active_period()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_active = true THEN
    UPDATE periods SET is_active = false WHERE school_year_id IS NOT DISTINCT FROM NEW.school_year_id AND id <> NEW.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ensure_single_active_period ON periods;
CREATE TRIGGER trg_ensure_single_active_period
  BEFORE INSERT OR UPDATE OF is_active ON periods
  FOR EACH ROW EXECUTE FUNCTION ensure_single_active_period();