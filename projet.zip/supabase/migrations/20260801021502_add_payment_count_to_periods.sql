/*
# Add payment_count column to periods

## Purpose
Store the number of payments processed during each period directly on the period
record. This ensures closed period cards and reports can display consistent
data without re-querying payments each time.

## Changes
- Add `payment_count` (integer, default 0) to `periods` table.
- Backfill `payment_count` for existing closed periods from linked payments.

## Security
- No policy changes. The new column inherits existing RLS policies.
*/

ALTER TABLE periods ADD COLUMN IF NOT EXISTS payment_count integer NOT NULL DEFAULT 0;

-- Backfill for closed periods
UPDATE periods per
SET payment_count = COALESCE(sub.count, 0)
FROM (
  SELECT period_id, COUNT(*) AS count
  FROM payments
  WHERE period_id IS NOT NULL
  GROUP BY period_id
) sub
WHERE per.id = sub.period_id
  AND per.is_closed = true;
