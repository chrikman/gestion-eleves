-- V2.0: Add columns and tables for new features

-- 1. Real payment date on payments
ALTER TABLE payments ADD COLUMN IF NOT EXISTS payment_date date;

-- 2. Gender on students (for boy/girl selection)
ALTER TABLE students ADD COLUMN IF NOT EXISTS gender text;
ALTER TABLE students ADD CONSTRAINT students_gender_check CHECK (gender IS NULL OR gender IN ('male', 'female'));

-- 3. Operations log table (journal des opérations)
CREATE TABLE IF NOT EXISTS operations_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_type text NOT NULL CHECK (operation_type IN ('payment', 'reenrollment', 'regularization', 'modification', 'deletion', 'creation', 'session_increment', 'period_close')),
  student_id uuid REFERENCES students(id) ON DELETE SET NULL,
  payment_id uuid REFERENCES payments(id) ON DELETE SET NULL,
  period_id uuid REFERENCES periods(id) ON DELETE SET NULL,
  student_name text,
  description text,
  amount numeric(12,2) DEFAULT 0,
  school_year_id uuid REFERENCES school_years(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE operations_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_operations_log" ON operations_log;
CREATE POLICY "anon_select_operations_log" ON operations_log FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_operations_log" ON operations_log;
CREATE POLICY "anon_insert_operations_log" ON operations_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_operations_log" ON operations_log;
CREATE POLICY "anon_delete_operations_log" ON operations_log FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_operations_log_created_at ON operations_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_operations_log_student_id ON operations_log(student_id);
CREATE INDEX IF NOT EXISTS idx_operations_log_operation_type ON operations_log(operation_type);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);

-- 4. Backfill payment_date from created_at for existing payments
UPDATE payments SET payment_date = created_at::date WHERE payment_date IS NULL;
