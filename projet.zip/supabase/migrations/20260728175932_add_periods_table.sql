/*
# Table des periodes (périodes de paiement)

Chaque période est définie par le professeur: date de début, date de fin,
statut (ouverte/clôturée). Lors de la clôture, les parts (professeur / crèche)
sont calculées et figées, et les dettes sont générées.
*/

CREATE TABLE IF NOT EXISTS periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  is_closed boolean NOT NULL DEFAULT false,
  school_year_id uuid REFERENCES school_years(id) ON DELETE SET NULL,
  -- Champs figés lors de la clôture
  total_revenue numeric(12,2) NOT NULL DEFAULT 0,
  professor_share numeric(12,2) NOT NULL DEFAULT 0,
  creche_share numeric(12,2) NOT NULL DEFAULT 0,
  total_debt numeric(12,2) NOT NULL DEFAULT 0,
  closed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE periods ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_periods" ON periods;
CREATE POLICY "anon_select_periods" ON periods FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_periods" ON periods;
CREATE POLICY "anon_insert_periods" ON periods FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_periods" ON periods;
CREATE POLICY "anon_update_periods" ON periods FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_periods" ON periods;
CREATE POLICY "anon_delete_periods" ON periods FOR DELETE
  TO anon, authenticated USING (true);

-- Lier les paiements à une période (optionnel)
ALTER TABLE payments ADD COLUMN IF NOT EXISTS period_id uuid REFERENCES periods(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_periods_school_year_id ON periods(school_year_id);
CREATE INDEX IF NOT EXISTS idx_payments_period_id ON payments(period_id);
