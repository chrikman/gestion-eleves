/*
# Ajout des champs de gestion de periode sur les paiements

1. Modifications
- `sessions_completed` (int, default 0): nombre de seances deja effectuees.
- `is_closed` (boolean, default false): indique si le mois est cloture
  apres que le nombre de seances prevu soit atteint.

2. Notes
- Ces champs permettent au professeur de suivre les seances et de
  cloturer le mois (periode) une fois les 4 seances completees.
*/

ALTER TABLE payments ADD COLUMN IF NOT EXISTS sessions_completed int NOT NULL DEFAULT 0;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS is_closed boolean NOT NULL DEFAULT false;
