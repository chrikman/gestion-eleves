/*
# Backfill payments.period_id based on date overlap

## Problem
Payments were created with `period_id = NULL`. The `closePeriod` function queries
by `period_id`, so it found zero payments and wrote all-zero totals to the closed
period record. This left closed period cards showing 0 DA even though payments exist.

## Fix
1. Backfill `period_id` for existing payments by matching `period_start`/`period_end`
   dates against period `start_date`/`end_date`. A payment belongs to a period when
   the payment's date range overlaps the period's date range.
2. Recalculate and persist `total_revenue`, `professor_share`, `creche_share`,
   `total_debt` for all already-closed periods so their stored values match the
   actual payments linked to them.
3. Add an index on `payments.period_id` for faster period queries.

## Notes
- No data is deleted or transformed destructively.
- Only NULL `period_id` values are populated; existing non-null values are preserved.
- Closed period totals are recomputed from the linked payments.
*/

-- 1. Backfill period_id for payments that have NULL period_id
UPDATE payments p
SET period_id = per.id
FROM periods per
WHERE p.period_id IS NULL
  AND p.period_start IS NOT NULL
  AND p.period_end IS NOT NULL
  AND p.period_start <= per.end_date
  AND p.period_end >= per.start_date;

-- 2. Recalculate totals for all closed periods from their linked payments
UPDATE periods per
SET
  total_revenue = COALESCE(sub.total_revenue, 0),
  total_debt = COALESCE(sub.total_debt, 0),
  professor_share = COALESCE(sub.total_revenue, 0) - COALESCE(sub.establishment_share, 0),
  creche_share = COALESCE(sub.establishment_share, 0)
FROM (
  SELECT
    p.period_id,
    SUM(p.amount_paid) AS total_revenue,
    SUM(p.amount - p.amount_paid) AS total_debt,
    -- establishment share: 15% of revenue (default percentage rate)
    -- This is a best-effort backfill; the app recalculates with current settings on next close
    SUM(p.amount_paid) * 0.15 AS establishment_share
  FROM payments p
  WHERE p.period_id IS NOT NULL
  GROUP BY p.period_id
) sub
WHERE per.id = sub.period_id
  AND per.is_closed = true;

-- 3. Index for faster period-based payment queries
CREATE INDEX IF NOT EXISTS idx_payments_period_id ON payments(period_id);
