import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, RefreshControl, Pressable, Modal, ScrollView, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/theme/ThemeContext';
import { ScreenHeader, LoadingView, ErrorView } from '@/components/ScreenHeader';
import { SearchBar } from '@/components/SearchBar';
import { Card } from '@/components/Card';
import { FAB } from '@/components/FAB';
import { Button } from '@/components/Button';
import { EmptyState } from '@/components/EmptyState';
import { fetchStudents, createStudent, updateStudent, setStudentStatus, type StudentWithRelations } from '@/services/studentService';
import { fetchAllPayments, createPayment, updatePayment, computePaymentStatus, fetchOldDebts, type PaymentWithStudent, type OldDebt } from '@/services/paymentService';
import { fetchLevels } from '@/services/levelService';
import { fetchCurrentSchoolYear } from '@/services/schoolYearService';
import { loadSettings } from '@/services/settingsService';
import { fetchActivePeriod } from '@/services/periodService';
import { getStudentStatusLabel, todayISO, computePeriodEnd, formatDate, formatCurrency, getPaymentStatusLabel, getGenderColor } from '@/utils/format';
import { getEffectiveSessionsCompleted } from '@/utils/sessionProgress';
import { DatePickerField } from '@/components/DatePickerField';
import type { Level, SchoolYear, AppSettings, PaymentType, Gender, Payment } from '@/types';
import { UserPlus, Users, ChevronDown, X, CalendarDays, Wallet, CheckCircle2, ArrowDownUp, Ban, Trash2, Pencil, TrendingUp, FileText } from 'lucide-react-native';
import { ConfirmDialog } from '@/components/ConfirmDialog';

const PERIOD_LABELS = ['1er mois', '2ème mois', '3ème mois', '4ème mois', '5ème mois', '6ème mois', '7ème mois', '8ème mois', '9ème mois', '10ème mois', '11ème mois', '12ème mois'];

export default function StudentsScreen() {
  const { colors, spacing } = useTheme();
  const router = useRouter();
  const [students, setStudents] = useState<StudentWithRelations[]>([]);
  const [payments, setPayments] = useState<PaymentWithStudent[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [currentYear, setCurrentYear] = useState<SchoolYear | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filterLevel, setFilterLevel] = useState<string | null>(null);
  const [showLevelFilter, setShowLevelFilter] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [sortBy, setSortBy] = useState<'status' | 'level' | 'name'>('status');
  const [showSortModal, setShowSortModal] = useState(false);
  const [payModalStudent, setPayModalStudent] = useState<StudentWithRelations | null>(null);
  const [editStudent, setEditStudent] = useState<StudentWithRelations | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<StudentWithRelations | null>(null);
  const [activePeriodId, setActivePeriodId] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const [studentData, levelData, yearData, paymentData, s] = await Promise.all([
        fetchStudents({ search: search.trim() || undefined, levelId: filterLevel ?? undefined }),
        fetchLevels(),
        fetchCurrentSchoolYear(),
        fetchAllPayments(),
        loadSettings(),
      ]);
      const activePeriod = await fetchActivePeriod(yearData?.id ?? null);
      setStudents(studentData);
      setLevels(levelData);
      setCurrentYear(yearData);
      setPayments(paymentData);
      setSettings(s);
      setActivePeriodId(activePeriod?.id ?? null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur de chargement');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [search, filterLevel]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSuspend = async (id: string) => {
    try { await setStudentStatus(id, 'suspended'); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };
  const handleActivate = async (id: string) => {
    try { await setStudentStatus(id, 'active'); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };
  const handleTrash = async (id: string) => {
    try { await setStudentStatus(id, 'trashed'); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };
  const handleEditSave = async (id: string, updates: { full_name: string; level_id: string | null; gender: Gender; notes: string | null }) => {
    try { await updateStudent(id, updates); setEditStudent(null); loadData(); } catch (e) { setError(e instanceof Error ? e.message : 'Erreur'); }
  };

  if (loading && students.length === 0) return <LoadingView />;
  if (error && students.length === 0) return <ErrorView message={error} />;

  const paymentsByStudent = new Map<string, PaymentWithStudent[]>();
  for (const p of payments) {
    const arr = paymentsByStudent.get(p.student_id) ?? [];
    arr.push(p);
    paymentsByStudent.set(p.student_id, arr);
  }

  const filterLevelLabel = levels.find((l) => l.id === filterLevel)?.name;

  const sortedStudents = [...students].sort((a, b) => {
    if (sortBy === 'status') {
      const rank = (s: StudentWithRelations) => (s.status === 'active' ? 0 : s.status === 'suspended' ? 1 : 2);
      const r = rank(a) - rank(b);
      if (r !== 0) return r;
      return (a.full_name ?? '').localeCompare(b.full_name ?? '');
    }
    if (sortBy === 'level') {
      const lvlA = levels.find((l) => l.id === a.level_id)?.sort_order ?? 9999;
      const lvlB = levels.find((l) => l.id === b.level_id)?.sort_order ?? 9999;
      if (lvlA !== lvlB) return lvlA - lvlB;
      const rank = (s: StudentWithRelations) => (s.status === 'active' ? 0 : s.status === 'suspended' ? 1 : 2);
      const r = rank(a) - rank(b);
      if (r !== 0) return r;
      return (a.full_name ?? '').localeCompare(b.full_name ?? '');
    }
    return (a.full_name ?? '').localeCompare(b.full_name ?? '');
  });

  const sortLabels: Record<typeof sortBy, string> = {
    status: 'Actifs en premier',
    level: 'Par niveau',
    name: 'Par nom (A-Z)',
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Élèves" subtitle={`${students.length} élève(s)`} />

      <View style={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.sm }}>
        <SearchBar value={search} onChangeText={setSearch} placeholder="Rechercher un élève..." />
        <View style={{ flexDirection: 'row', gap: 8, marginTop: spacing.sm }}>
          <Pressable
            onPress={() => setShowLevelFilter(true)}
            style={[styles.filterBtn, { backgroundColor: colors.surfaceVariant, flex: 1 }]}
          >
            <Text style={[styles.filterText, { color: filterLevel ? colors.primary : colors.onSurfaceVariant }]} numberOfLines={1}>
              {filterLevelLabel ? `Niveau: ${filterLevelLabel}` : 'Tous les niveaux'}
            </Text>
            <ChevronDown size={18} color={colors.onSurfaceVariant} />
          </Pressable>
          <Pressable
            onPress={() => setShowSortModal(true)}
            style={[styles.filterBtn, { backgroundColor: colors.surfaceVariant, flex: 1 }]}
          >
            <ArrowDownUp size={16} color={colors.onSurfaceVariant} />
            <Text style={[styles.filterText, { color: colors.onSurfaceVariant }]} numberOfLines={1}>{sortLabels[sortBy]}</Text>
            <ChevronDown size={18} color={colors.onSurfaceVariant} />
          </Pressable>
        </View>
      </View>

      <FlatList
        data={sortedStudents}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 100 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}
        ListHeaderComponent={
          filterLevel ? (
            <View style={{ marginBottom: spacing.sm }}>
              <Card elevation={2} style={[styles.copiesCard, { backgroundColor: colors.primaryContainer }]}>
                <View style={styles.copiesCardRow}>
                  <View style={[styles.copiesCardIcon, { backgroundColor: colors.primary }]}>
                    <FileText size={22} color={colors.onPrimary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.copiesCardLabel, { color: colors.onPrimaryContainer }]}>Copies à imprimer</Text>
                    <Text style={[styles.copiesCardHint, { color: colors.onPrimaryContainer }]}>
                      {students.filter((s) => s.status === 'active' && s.level_id === filterLevel).length} élève(s) actif(s) + 1 professeur
                    </Text>
                  </View>
                  <Text style={[styles.copiesCardValue, { color: colors.onPrimaryContainer }]}>
                    {students.filter((s) => s.status === 'active' && s.level_id === filterLevel).length + 1}
                  </Text>
                </View>
              </Card>
            </View>
          ) : null
        }
        ListEmptyComponent={<EmptyState title="Aucun élève" message="Ajoutez votre premier élève avec le bouton +" icon={<Users size={32} color={colors.onSurfaceVariant} />} />}
        renderItem={({ item, index }) => {
          const studentPayments = (paymentsByStudent.get(item.id) ?? []).filter((p) => !p.is_regularization);
          const activePayment = studentPayments.find((p) => !p.is_closed) ?? studentPayments[0] ?? null;
          const periodNumber = studentPayments.length;
          const debt = activePayment ? Number(activePayment.amount) - Number(activePayment.amount_paid) : 0;
          const amountPaid = activePayment ? Number(activePayment.amount_paid) : 0;
          const sessionsDone = activePayment ? getEffectiveSessionsCompleted(activePayment) : 0;
          const sessionsTotal = activePayment ? (activePayment.session_count ?? 4) : 4;
          const lastPaymentDate = activePayment?.payment_date ?? null;

          return (
            <Card elevation={1} style={{ marginBottom: spacing.sm }}>
              {/* Row 1: number + name + status badge — clickable to open history */}
              <Pressable onPress={() => router.push({ pathname: '/student/[id]', params: { id: item.id } })} style={styles.cardTopRow}>
                <View style={[styles.numberBadge, { backgroundColor: colors.primaryContainer }]}>
                  <Text style={[styles.numberText, { color: colors.onPrimaryContainer }]}>{index + 1}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.studentName, { color: getGenderColor(item.gender) }]} numberOfLines={1}>{item.full_name}</Text>
                  <Text style={[styles.subInfo, { color: colors.onSurfaceVariant }]} numberOfLines={1}>
                    {item.level?.name ?? 'Sans niveau'}
                  </Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: item.status === 'active' ? colors.successContainer : item.status === 'suspended' ? colors.warningContainer : colors.surfaceVariant }]}>
                  <Text style={[styles.statusBadgeText, { color: item.status === 'active' ? colors.onSuccessContainer : item.status === 'suspended' ? colors.onWarningContainer : colors.onSurfaceVariant }]}>
                    {getStudentStatusLabel(item.status)}
                  </Text>
                </View>
              </Pressable>

              {activePayment ? (
                <>
                  {/* Row 2: month number + dates */}
                  <View style={[styles.cardRow2, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                    <View style={styles.periodInfo}>
                      <Text style={[styles.periodLabel, { color: colors.primary }]}>
                        {periodNumber <= PERIOD_LABELS.length ? PERIOD_LABELS[periodNumber - 1] : `Mois ${periodNumber}`}
                      </Text>
                      <View style={styles.datesRow}>
                        <CalendarDays size={13} color={colors.onSurfaceVariant} />
                        <Text style={[styles.datesText, { color: colors.onSurfaceVariant }]}>
                          {formatDate(activePayment.period_start)} → {formatDate(activePayment.period_end)}
                        </Text>
                      </View>
                    </View>
                  </View>

                  {/* Row 3: session bars */}
                  <SessionBars
                    sessionsDone={sessionsDone}
                    sessionsTotal={sessionsTotal}
                    paymentStatus={activePayment.status}
                    colors={colors}
                  />

                  {/* Row 4: payment info grid */}
                  <View style={[styles.payInfoGrid, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                    <View style={styles.payInfoCol}>
                      <Text style={[styles.payInfoLabel, { color: colors.onSurfaceVariant }]}>État</Text>
                      <Text style={[styles.payInfoValue, { color: activePayment.status === 'paid' ? colors.success : activePayment.status === 'partial' ? colors.warning : colors.error }]}>
                        {getPaymentStatusLabel(activePayment.status)}
                      </Text>
                    </View>
                    <View style={styles.payInfoCol}>
                      <Text style={[styles.payInfoLabel, { color: colors.onSurfaceVariant }]}>Payé</Text>
                      <Text style={[styles.payInfoValue, { color: colors.onSurface }]}>{formatCurrency(amountPaid)}</Text>
                    </View>
                    <View style={styles.payInfoCol}>
                      <Text style={[styles.payInfoLabel, { color: colors.onSurfaceVariant }]}>Reste</Text>
                      <Text style={[styles.payInfoValue, { color: debt > 0 ? colors.error : colors.success }]}>{formatCurrency(debt)}</Text>
                    </View>
                    {lastPaymentDate ? (
                      <View style={styles.payInfoCol}>
                        <Text style={[styles.payInfoLabel, { color: colors.onSurfaceVariant }]}>Dernier paiement</Text>
                        <Text style={[styles.payInfoValueSmall, { color: colors.onSurface }]}>{formatDate(lastPaymentDate)}</Text>
                      </View>
                    ) : null}
                  </View>
                </>
              ) : (
                <View style={[styles.noPaymentBox, { backgroundColor: colors.surfaceVariant }]}>
                  <Text style={[styles.noPaymentText, { color: colors.onSurfaceVariant }]}>Aucun mois enregistré</Text>
                </View>
              )}

              {/* Row 5: action buttons */}
              <View style={[styles.cardActions, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}>
                <Pressable
                  onPress={() => setPayModalStudent(item)}
                  style={[styles.actionBtn, { backgroundColor: colors.primary }]}
                >
                  <Wallet size={14} color={colors.onPrimary} />
                  <Text style={[styles.actionBtnText, { color: colors.onPrimary }]}>Payer / Régulariser</Text>
                </Pressable>
                <Pressable
                  onPress={() => setEditStudent(item)}
                  style={[styles.iconBtn, { backgroundColor: colors.primaryContainer }]}
                >
                  <Pencil size={14} color={colors.onPrimaryContainer} />
                </Pressable>
                {item.status === 'active' ? (
                  <Pressable onPress={() => handleSuspend(item.id)} style={[styles.iconBtn, { backgroundColor: colors.warningContainer }]}>
                    <Ban size={14} color={colors.onWarningContainer} />
                  </Pressable>
                ) : item.status === 'suspended' ? (
                  <Pressable onPress={() => handleActivate(item.id)} style={[styles.iconBtn, { backgroundColor: colors.successContainer }]}>
                    <CheckCircle2 size={14} color={colors.onSuccessContainer} />
                  </Pressable>
                ) : null}
                <Pressable onPress={() => setConfirmDelete(item)} style={[styles.iconBtn, { backgroundColor: colors.errorContainer }]}>
                  <Trash2 size={14} color={colors.onErrorContainer} />
                </Pressable>
              </View>
            </Card>
          );
        }}
      />

      <FAB onPress={() => setShowAddModal(true)} icon={<UserPlus size={26} color={colors.onPrimary} />} />

      {/* Level filter modal */}
      <Modal visible={showLevelFilter} transparent animationType="slide" onRequestClose={() => setShowLevelFilter(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Filtrer par niveau</Text>
              <Pressable onPress={() => setShowLevelFilter(false)}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
            </View>
            <Pressable onPress={() => { setFilterLevel(null); setShowLevelFilter(false); }} style={[styles.filterOption, { backgroundColor: filterLevel === null ? colors.primaryContainer : 'transparent' }]}>
              <Text style={[styles.filterOptionText, { color: filterLevel === null ? colors.onPrimaryContainer : colors.onSurface }]}>Tous les niveaux</Text>
            </Pressable>
            {levels.map((lvl) => (
              <Pressable key={lvl.id} onPress={() => { setFilterLevel(lvl.id); setShowLevelFilter(false); }} style={[styles.filterOption, { backgroundColor: filterLevel === lvl.id ? colors.primaryContainer : 'transparent' }]}>
                <Text style={[styles.filterOptionText, { color: filterLevel === lvl.id ? colors.onPrimaryContainer : colors.onSurface }]}>{lvl.name}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </Modal>

      {/* Sort modal */}
      <Modal visible={showSortModal} transparent animationType="slide" onRequestClose={() => setShowSortModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Trier les élèves</Text>
              <Pressable onPress={() => setShowSortModal(false)}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
            </View>
            {(['status', 'level', 'name'] as const).map((opt) => (
              <Pressable key={opt} onPress={() => { setSortBy(opt); setShowSortModal(false); }} style={[styles.filterOption, { backgroundColor: sortBy === opt ? colors.primaryContainer : 'transparent' }]}>
                <Text style={[styles.filterOptionText, { color: sortBy === opt ? colors.onPrimaryContainer : colors.onSurface }]}>{sortLabels[opt]}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </Modal>

      <AddStudentModal visible={showAddModal} onClose={() => setShowAddModal(false)} levels={levels} currentYearId={currentYear?.id ?? null} settings={settings} activePeriodId={activePeriodId} onSaved={() => { setShowAddModal(false); loadData(); }} />

      {payModalStudent ? (
        <PayRegularizeModal
          student={payModalStudent}
          payments={paymentsByStudent.get(payModalStudent.id) ?? []}
          currentYearId={currentYear?.id ?? null}
          settings={settings}
          activePeriodId={activePeriodId}
          onClose={() => setPayModalStudent(null)}
          onSaved={() => { setPayModalStudent(null); loadData(); }}
        />
      ) : null}

      {editStudent ? (
        <EditStudentModal
          student={editStudent}
          levels={levels}
          onClose={() => setEditStudent(null)}
          onSaved={(updates) => handleEditSave(editStudent.id, updates)}
        />
      ) : null}

      <ConfirmDialog
        visible={confirmDelete !== null}
        title="Supprimer l'élève"
        message="Êtes-vous certain de vouloir supprimer cet élève ? Cette opération est irréversible."
        confirmLabel="Supprimer"
        danger
        onConfirm={() => { if (confirmDelete) handleTrash(confirmDelete.id); setConfirmDelete(null); }}
        onCancel={() => setConfirmDelete(null)}
      />
    </View>
  );
}

function SessionBars({ sessionsDone, sessionsTotal, paymentStatus, colors }: {
  sessionsDone: number; sessionsTotal: number; paymentStatus: string; colors: ReturnType<typeof useTheme>['colors'];
}) {
  const barColor = paymentStatus === 'paid' ? colors.success : paymentStatus === 'partial' ? colors.warning : colors.error;
  const bars = [];
  for (let i = 0; i < sessionsTotal; i++) {
    bars.push(
      <View key={i} style={[styles.sessionBarItem, { backgroundColor: i < sessionsDone ? barColor : colors.surfaceVariant, borderColor: colors.outline }]} />
    );
  }
  return (
    <View style={styles.sessionBarsContainer}>
      <View style={styles.sessionBarsRow}>{bars}</View>
      <Text style={[styles.sessionBarsLabel, { color: colors.onSurfaceVariant }]}>
        {sessionsDone} / {sessionsTotal} séances effectuées
      </Text>
    </View>
  );
}

interface AddStudentModalProps {
  visible: boolean;
  onClose: () => void;
  levels: Level[];
  currentYearId: string | null;
  settings: AppSettings | null;
  activePeriodId: string | null;
  onSaved: () => void;
}

function AddStudentModal({ visible, onClose, levels, currentYearId, settings, activePeriodId, onSaved }: AddStudentModalProps) {
  const { colors, spacing, radius } = useTheme();
  const [fullName, setFullName] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [gender, setGender] = useState<Gender>(null);
  const [paymentType, setPaymentType] = useState<PaymentType>('monthly');
  const [periodStart, setPeriodStart] = useState(todayISO());
  const [amount, setAmount] = useState('');
  const [amountPaid, setAmountPaid] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const periodDays = settings?.period_duration_days ?? 21;
  const sessionsPerPeriod = paymentType === 'per_session' ? 1 : (settings?.sessions_per_period ?? 4);
  const defaultPrice = settings?.default_session_price ?? 500;
  const periodEnd = computePeriodEnd(periodStart, periodDays);

  const reset = () => {
    setFullName(''); setSelectedLevel(null); setGender(null); setPaymentType('monthly'); setPeriodStart(todayISO());
    setAmount(''); setAmountPaid(''); setErr(null);
  };

  const handleSave = async () => {
    if (!fullName.trim()) { setErr('Le nom complet est obligatoire'); return; }
    if (!selectedLevel) { setErr('Veuillez sélectionner le niveau de l\'élève (1AM, 2AM, 3AM, 4AM ou Autre)'); return; }
    setSaving(true); setErr(null);
    try {
      const student = await createStudent({
        full_name: fullName.trim(),
        level_id: selectedLevel,
        gender,
        school_year_id: currentYearId,
      });

      const defaultAmt = paymentType === 'per_session' ? defaultPrice : defaultPrice * sessionsPerPeriod;
      const amt = parseFloat(amount) || defaultAmt;
      const paid = paymentType === 'social_case' ? 0 : (parseFloat(amountPaid) || 0);
      const status = paymentType === 'social_case' ? 'unpaid' : computePaymentStatus(amt, paid, sessionsPerPeriod);

      await createPayment({
        student_id: student.id,
        amount: amt,
        amount_paid: paid,
        status,
        payment_type: paymentType,
        period_start: periodStart,
        period_end: periodEnd,
        session_count: sessionsPerPeriod,
        school_year_id: currentYearId,
        period_id: activePeriodId,
      });

      reset(); onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Erreur lors de l'enregistrement");
    } finally { setSaving(false); }
  };

  const paymentTypes: { key: PaymentType; label: string }[] = [
    { key: 'monthly', label: 'Mensuel' },
    { key: 'per_session', label: 'Par séance' },
    { key: 'social_case', label: 'Cas social' },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Nouvel élève</Text>
            <Pressable onPress={() => { reset(); onClose(); }}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 500 }}>
            <FieldInput label="Nom complet *" value={fullName} onChangeText={setFullName} placeholder="Nom et prénom de l'élève" />

            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Genre</Text>
            <View style={[styles.pillRow, { marginTop: 4 }]}>
              <Pressable onPress={() => setGender(gender === 'male' ? null : 'male')} style={[styles.pill, { backgroundColor: gender === 'male' ? '#3B82F6' : colors.surfaceVariant, borderColor: colors.outline }]}>
                <Text style={[styles.pillText, { color: gender === 'male' ? '#FFFFFF' : colors.onSurfaceVariant }]}>Garçon</Text>
              </Pressable>
              <Pressable onPress={() => setGender(gender === 'female' ? null : 'female')} style={[styles.pill, { backgroundColor: gender === 'female' ? '#EC4899' : colors.surfaceVariant, borderColor: colors.outline }]}>
                <Text style={[styles.pillText, { color: gender === 'female' ? '#FFFFFF' : colors.onSurfaceVariant }]}>Fille</Text>
              </Pressable>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Niveau *</Text>
            <View style={[styles.pillRow, { marginTop: 4 }]}>
              {levels.map((lvl) => (
                <Pressable key={lvl.id} onPress={() => setSelectedLevel(selectedLevel === lvl.id ? null : lvl.id)} style={[styles.pill, { backgroundColor: selectedLevel === lvl.id ? colors.primary : colors.surfaceVariant, borderColor: colors.outline }]}>
                  <Text style={[styles.pillText, { color: selectedLevel === lvl.id ? colors.onPrimary : colors.onSurfaceVariant }]}>{lvl.name}</Text>
                </Pressable>
              ))}
            </View>

            <View style={[styles.sectionDivider, { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth, marginVertical: spacing.md }]} />

            <View style={styles.enrollHeader}>
              <CalendarDays size={18} color={colors.primary} />
              <Text style={[styles.enrollTitle, { color: colors.onSurface }]}>Inscription du mois</Text>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Type de paiement</Text>
            <View style={[styles.pillRow, { marginTop: 4 }]}>
              {paymentTypes.map((pt) => (
                <Pressable key={pt.key} onPress={() => setPaymentType(pt.key)} style={[styles.pill, { backgroundColor: paymentType === pt.key ? colors.primary : colors.surfaceVariant, borderColor: colors.outline }]}>
                  <Text style={[styles.pillText, { color: paymentType === pt.key ? colors.onPrimary : colors.onSurfaceVariant }]}>{pt.label}</Text>
                </Pressable>
              ))}
            </View>

            <DatePickerField label="Date de début (mois)" value={periodStart} onChange={setPeriodStart} placeholder="Sélectionner une date" />
            <View style={[styles.periodInfoBox, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm }]}>
              <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Date de fin calculée ({periodDays} jours)</Text>
              <Text style={[styles.periodEndValue, { color: colors.primary }]}>{formatDate(periodEnd)}</Text>
            </View>

            {paymentType !== 'social_case' ? (
              <>
                <FieldInput label="Montant total (DZD)" value={amount} onChangeText={setAmount} placeholder={`${paymentType === 'per_session' ? defaultPrice : defaultPrice * sessionsPerPeriod} (par défaut)`} keyboardType="numeric" />
                <FieldInput label="Montant payé (DZD)" value={amountPaid} onChangeText={setAmountPaid} placeholder="0" keyboardType="numeric" />
              </>
            ) : (
              <View style={[styles.periodInfoBox, { backgroundColor: colors.warningContainer, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm }]}>
                <Text style={[styles.fieldLabel, { color: colors.onWarningContainer }]}>Cas social — aucun paiement requis</Text>
              </View>
            )}
          </ScrollView>
          {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={() => { reset(); onClose(); }} style={{ flex: 1 }} />
            <Button label={saving ? 'Enregistrement...' : 'Enregistrer'} variant="filled" onPress={handleSave} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

interface PayRegularizeModalProps {
  student: StudentWithRelations;
  payments: PaymentWithStudent[];
  currentYearId: string | null;
  settings: AppSettings | null;
  activePeriodId: string | null;
  onClose: () => void;
  onSaved: () => void;
}

function PayRegularizeModal({ student, payments, currentYearId, settings, activePeriodId, onClose, onSaved }: PayRegularizeModalProps) {
  const { colors, spacing, radius } = useTheme();
  const [mode, setMode] = useState<'normal' | 'regularize'>('normal');
  const [activePayment, setActivePayment] = useState<PaymentWithStudent | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [oldDebts, setOldDebts] = useState<OldDebt[]>([]);
  const [selectedDebt, setSelectedDebt] = useState<string | null>(null);
  const [regularizeAmount, setRegularizeAmount] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const regular = payments.filter((p) => !p.is_regularization);
    const active = regular.find((p) => !p.is_closed) ?? regular[0] ?? null;
    setActivePayment(active);
    if (active) setPayAmount(String(active.amount_paid ?? 0));
    fetchOldDebts(student.id).then(setOldDebts).catch(() => {});
  }, [student.id, payments]);

  const handlePay = async () => {
    if (!activePayment) { setErr('Aucun mois actif à payer'); return; }
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt < 0) { setErr('Montant invalide'); return; }
    setSaving(true); setErr(null);
    try {
      const status = computePaymentStatus(Number(activePayment.amount), amt, activePayment.session_count);
      await updatePayment(activePayment.id, { amount_paid: amt, status, payment_date: todayISO() });
      onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  const handleRegularize = async () => {
    if (!selectedDebt) { setErr('Sélectionnez une dette à régulariser'); return; }
    const amt = parseFloat(regularizeAmount);
    if (isNaN(amt) || amt <= 0) { setErr('Montant invalide'); return; }
    setSaving(true); setErr(null);
    try {
      await createPayment({
        student_id: student.id,
        amount: amt,
        amount_paid: amt,
        status: 'paid',
        period_start: todayISO(),
        period_end: todayISO(),
        session_count: 0,
        school_year_id: currentYearId,
        period_id: activePeriodId,
        is_regularization: true,
        regularizes_payment_id: selectedDebt,
      });
      const debt = oldDebts.find((d) => d.id === selectedDebt);
      if (debt) {
        const newAmountPaid = Math.min(debt.amount_paid + amt, debt.amount);
        const newStatus = newAmountPaid >= debt.amount ? 'paid' : 'partial';
        await updatePayment(debt.id, { amount_paid: newAmountPaid, status: newStatus });
      }
      onSaved();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Erreur');
    } finally { setSaving(false); }
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]} numberOfLines={1}>Payer / Régulariser — {student.full_name}</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>

          {/* Mode toggle */}
          <View style={[styles.payModeToggle, { backgroundColor: colors.surfaceVariant }]}>
            <Pressable
              onPress={() => setMode('normal')}
              style={[styles.payModeBtn, { backgroundColor: mode === 'normal' ? colors.primary : 'transparent' }]}
            >
              <Wallet size={16} color={mode === 'normal' ? colors.onPrimary : colors.onSurfaceVariant} />
              <Text style={{ fontSize: 14, fontWeight: '600', color: mode === 'normal' ? colors.onPrimary : colors.onSurfaceVariant }}>Paiement normal</Text>
            </Pressable>
            <Pressable
              onPress={() => setMode('regularize')}
              style={[styles.payModeBtn, { backgroundColor: mode === 'regularize' ? colors.warning : 'transparent' }]}
            >
              <TrendingUp size={16} color={mode === 'regularize' ? colors.onWarning : colors.onSurfaceVariant} />
              <Text style={{ fontSize: 14, fontWeight: '600', color: mode === 'regularize' ? colors.onWarning : colors.onSurfaceVariant }}>Régulariser une dette</Text>
            </Pressable>
          </View>

          <ScrollView style={{ maxHeight: 400 }}>
            {mode === 'normal' ? (
              activePayment ? (
                <View>
                  <View style={[styles.periodInfoBox, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, padding: spacing.md }]}>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Mois actuel</Text>
                      <Text style={{ fontSize: 15, fontWeight: '600', color: colors.onSurface }}>{formatDate(activePayment.period_start)} → {formatDate(activePayment.period_end)}</Text>
                    </View>
                    <View style={{ alignItems: 'flex-end' }}>
                      <Text style={{ fontSize: 12, color: colors.onSurfaceVariant }}>Dû: {formatCurrency(Number(activePayment.amount))}</Text>
                      <Text style={{ fontSize: 12, color: colors.onSurfaceVariant }}>Payé: {formatCurrency(Number(activePayment.amount_paid))}</Text>
                    </View>
                  </View>

                  <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Montant payé (DZD)</Text>
                  <TextInput
                    value={payAmount}
                    onChangeText={setPayAmount}
                    placeholder="0"
                    placeholderTextColor={colors.onSurfaceVariant}
                    keyboardType="numeric"
                    style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
                  />
                  <View style={{ flexDirection: 'row', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
                    <Button label="Tout payer" size="sm" variant="outlined" onPress={() => setPayAmount(String(activePayment.amount))} />
                    <Button label="Moitié" size="sm" variant="outlined" onPress={() => setPayAmount(String(Math.round(Number(activePayment.amount) / 2)))} />
                    <Button label="Effacer" size="sm" variant="text" onPress={() => setPayAmount('0')} />
                  </View>
                </View>
              ) : (
                <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Aucun mois actif. Créez un nouveau mois depuis la fiche de l'élève.</Text>
              )
            ) : (
              <View>
                {oldDebts.length === 0 ? (
                  <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>Aucune dette de période clôturée à régulariser.</Text>
                ) : (
                  <>
                    <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Dette à régulariser *</Text>
                    <View style={{ gap: 8, marginTop: 4 }}>
                      {oldDebts.map((d) => (
                        <Pressable key={d.id} onPress={() => { setSelectedDebt(d.id); setRegularizeAmount(String(d.debt)); }} style={[styles.debtOption, { backgroundColor: selectedDebt === d.id ? colors.warningContainer : colors.surfaceVariant, borderColor: selectedDebt === d.id ? colors.warning : 'transparent' }]}>
                          <View style={{ flex: 1 }}>
                            <Text style={{ fontSize: 14, fontWeight: '600', color: selectedDebt === d.id ? colors.onWarningContainer : colors.onSurface }}>{d.period_name}</Text>
                            <Text style={{ fontSize: 12, color: colors.onSurfaceVariant, marginTop: 2 }}>
                              {formatDate(d.period_start)} → {formatDate(d.period_end)} — Reste: {formatCurrency(d.debt)}
                            </Text>
                          </View>
                          <Text style={{ fontSize: 15, fontWeight: '700', color: colors.error }}>{formatCurrency(d.debt)}</Text>
                        </Pressable>
                      ))}
                    </View>
                    {selectedDebt ? (
                      <View style={{ marginTop: spacing.sm }}>
                        <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>Montant à régulariser (DZD)</Text>
                        <TextInput
                          value={regularizeAmount}
                          onChangeText={setRegularizeAmount}
                          placeholder="0"
                          placeholderTextColor={colors.onSurfaceVariant}
                          keyboardType="numeric"
                          style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md, height: 48, marginTop: 4 }]}
                        />
                      </View>
                    ) : null}
                  </>
                )}
              </View>
            )}
            {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          </ScrollView>

          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            {mode === 'normal' ? (
              <Button label={saving ? '...' : 'Enregistrer'} variant="filled" onPress={handlePay} disabled={saving} style={{ flex: 1, marginLeft: 8 }} />
            ) : (
              <Button label={saving ? '...' : 'Régulariser'} variant="filled" onPress={handleRegularize} disabled={saving || !selectedDebt} style={{ flex: 1, marginLeft: 8 }} />
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

function EditStudentModal({ student, levels, onClose, onSaved }: {
  student: StudentWithRelations; levels: Level[]; onClose: () => void; onSaved: (updates: { full_name: string; level_id: string | null; gender: Gender; notes: string | null }) => void;
}) {
  const { colors, spacing, radius } = useTheme();
  const [fullName, setFullName] = useState(student.full_name);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(student.level_id);
  const [gender, setGender] = useState<Gender>(student.gender);
  const [notes, setNotes] = useState(student.notes ?? '');
  const [err, setErr] = useState<string | null>(null);

  const handleSave = () => {
    if (!fullName.trim()) { setErr('Le nom complet est obligatoire'); return; }
    onSaved({ full_name: fullName.trim(), level_id: selectedLevel, gender, notes: notes.trim() || null });
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.addModal, { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.lg }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>Modifier l'élève</Text>
            <Pressable onPress={onClose}><X size={24} color={colors.onSurfaceVariant} /></Pressable>
          </View>
          <ScrollView style={{ maxHeight: 400 }}>
            <FieldInput label="Nom complet *" value={fullName} onChangeText={setFullName} placeholder="Nom et prénom" />
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Genre</Text>
            <View style={[styles.pillRow, { marginTop: 4 }]}>
              <Pressable onPress={() => setGender(gender === 'male' ? null : 'male')} style={[styles.pill, { backgroundColor: gender === 'male' ? '#3B82F6' : colors.surfaceVariant, borderColor: colors.outline }]}>
                <Text style={[styles.pillText, { color: gender === 'male' ? '#FFFFFF' : colors.onSurfaceVariant }]}>Garçon</Text>
              </Pressable>
              <Pressable onPress={() => setGender(gender === 'female' ? null : 'female')} style={[styles.pill, { backgroundColor: gender === 'female' ? '#EC4899' : colors.surfaceVariant, borderColor: colors.outline }]}>
                <Text style={[styles.pillText, { color: gender === 'female' ? '#FFFFFF' : colors.onSurfaceVariant }]}>Fille</Text>
              </Pressable>
            </View>
            <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant, marginTop: spacing.sm }]}>Niveau</Text>
            <View style={styles.pillRow}>
              {levels.map((lvl) => (
                <Pressable key={lvl.id} onPress={() => setSelectedLevel(selectedLevel === lvl.id ? null : lvl.id)} style={[styles.pill, { backgroundColor: selectedLevel === lvl.id ? colors.primary : colors.surfaceVariant, borderColor: colors.outline }]}>
                  <Text style={[styles.pillText, { color: selectedLevel === lvl.id ? colors.onPrimary : colors.onSurfaceVariant }]}>{lvl.name}</Text>
                </Pressable>
              ))}
            </View>
            <FieldInput label="Notes" value={notes} onChangeText={setNotes} multiline />
          </ScrollView>
          {err ? <Text style={[styles.errText, { color: colors.error }]}>{err}</Text> : null}
          <View style={styles.modalActions}>
            <Button label="Annuler" variant="text" onPress={onClose} style={{ flex: 1 }} />
            <Button label="Enregistrer" variant="filled" onPress={handleSave} style={{ flex: 1, marginLeft: 8 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function FieldInput({ label, value, onChangeText, placeholder, multiline, keyboardType }: {
  label: string; value: string; onChangeText: (v: string) => void; placeholder?: string; multiline?: boolean; keyboardType?: 'default' | 'numeric';
}) {
  const { colors, radius, spacing } = useTheme();
  return (
    <View style={{ marginTop: spacing.sm }}>
      <Text style={[styles.fieldLabel, { color: colors.onSurfaceVariant }]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.onSurfaceVariant}
        multiline={multiline}
        keyboardType={keyboardType ?? 'default'}
        style={[styles.input, { backgroundColor: colors.surfaceVariant, borderRadius: radius.md, color: colors.onSurface, paddingHorizontal: spacing.md }, multiline && { minHeight: 70, textAlignVertical: 'top', paddingTop: spacing.sm }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  copiesCard: { padding: 16, borderRadius: 16 },
  copiesCardRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  copiesCardIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  copiesCardLabel: { fontSize: 15, fontWeight: '700' },
  copiesCardHint: { fontSize: 12, marginTop: 2, opacity: 0.8 },
  copiesCardValue: { fontSize: 32, fontWeight: '800' },
  filterBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, height: 44, borderRadius: 12 },
  filterText: { fontSize: 14, fontWeight: '500' },
  cardTopRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  numberBadge: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  numberText: { fontSize: 15, fontWeight: '700' },
  studentName: { fontSize: 16, fontWeight: '700' },
  subInfo: { fontSize: 12, marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  statusBadgeText: { fontSize: 12, fontWeight: '700' },
  cardRow2: { flexDirection: 'row', alignItems: 'center', marginTop: 10, paddingTop: 8 },
  periodInfo: { flex: 1 },
  periodLabel: { fontSize: 14, fontWeight: '700' },
  datesRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  datesText: { fontSize: 12, fontWeight: '500' },
  payInfoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10, paddingTop: 8 },
  payInfoCol: { flex: 1, minWidth: 70, alignItems: 'center' },
  payInfoLabel: { fontSize: 11, fontWeight: '500' },
  payInfoValue: { fontSize: 14, fontWeight: '700', marginTop: 2 },
  payInfoValueSmall: { fontSize: 13, fontWeight: '600', marginTop: 2 },
  noPaymentBox: { marginTop: 10, paddingTop: 8, paddingBottom: 8, borderRadius: 8, alignItems: 'center' },
  noPaymentText: { fontSize: 13, fontWeight: '500' },
  cardActions: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 10, paddingTop: 8, flexWrap: 'wrap' },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8 },
  actionBtnText: { fontSize: 12, fontWeight: '600' },
  iconBtn: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  sessionBarsContainer: { marginTop: 10 },
  sessionBarsRow: { flexDirection: 'row', gap: 6 },
  sessionBarItem: { flex: 1, height: 8, borderRadius: 4, borderWidth: StyleSheet.hairlineWidth },
  sessionBarsLabel: { fontSize: 11, fontWeight: '500', marginTop: 4 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 36 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '700' },
  filterOption: { paddingVertical: 14, paddingHorizontal: 16, borderRadius: 12, marginTop: 4 },
  filterOptionText: { fontSize: 15, fontWeight: '500' },
  addModal: { width: '100%', maxHeight: '90%' },
  fieldLabel: { fontSize: 13, fontWeight: '500', marginBottom: 6 },
  input: { height: 48, fontSize: 15 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: StyleSheet.hairlineWidth },
  pillText: { fontSize: 13, fontWeight: '600' },
  errText: { fontSize: 13, marginTop: 8, textAlign: 'center' },
  modalActions: { flexDirection: 'row', marginTop: 16 },
  sectionDivider: { width: '100%' },
  enrollHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  enrollTitle: { fontSize: 15, fontWeight: '700' },
  periodInfoBox: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  periodEndValue: { fontSize: 16, fontWeight: '700' },
  emptyText: { fontSize: 14, marginTop: 8 },
  payModeToggle: { flexDirection: 'row', borderRadius: 12, padding: 4, marginBottom: 16 },
  payModeBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: 10 },
  debtOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14, borderRadius: 12, borderWidth: 2 },
});
