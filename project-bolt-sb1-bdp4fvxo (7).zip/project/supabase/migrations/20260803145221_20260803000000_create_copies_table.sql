/*
# Create copies table for copy/exam print tracking

1. New Tables
- `copies`
  - `id` (uuid, primary key)
  - `level_id` (uuid, foreign key to levels, nullable)
  - `date` (text, YYYY-MM-DD format — the day the copies are tracked)
  - `copies_done` (integer, default 0 — how many copies have been printed/realized)
  - `professor_name` (text, nullable — name of the professor who validated the print)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
2. Constraints
- Unique constraint on (level_id, date) so there is one record per level per day
3. Security
- Enable RLS on `copies`.
- Single-tenant no-auth app: allow anon + authenticated full CRUD.
*/

CREATE TABLE IF NOT EXISTS copies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  level_id uuid REFERENCES levels(id) ON DELETE SET NULL,
  date text NOT NULL,
  copies_done integer NOT NULL DEFAULT 0,
  professor_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS copies_level_date_unique ON copies(level_id, date);

ALTER TABLE copies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_copies" ON copies;
CREATE POLICY "anon_select_copies" ON copies FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_copies" ON copies;
CREATE POLICY "anon_insert_copies" ON copies FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_copies" ON copies;
CREATE POLICY "anon_update_copies" ON copies FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_copies" ON copies;
CREATE POLICY "anon_delete_copies" ON copies FOR DELETE
  TO anon, authenticated USING (true);
