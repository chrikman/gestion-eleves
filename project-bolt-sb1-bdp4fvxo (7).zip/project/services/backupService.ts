import { supabase } from '@/lib/supabase';
import { DEFAULT_SETTINGS, type AppSettings } from '@/types';

const BACKUP_VERSION = 1;

export interface BackupData {
  version: number;
  created_at: string;
  tables: {
    students: unknown[];
    payments: unknown[];
    periods: unknown[];
    levels: unknown[];
    school_years: unknown[];
    absences: unknown[];
    operations_log: unknown[];
    settings: { key: string; value: AppSettings | unknown; updated_at: string }[];
  };
}

export interface BackupMeta {
  date: string;
  size: number;
  version: number;
  studentCount: number;
  paymentCount: number;
}

async function fetchAll<T>(table: string, select = '*'): Promise<T[]> {
  const pageSize = 1000;
  let all: T[] = [];
  let from = 0;
  while (true) {
    const { data, error } = await supabase
      .from(table)
      .select(select)
      .range(from, from + pageSize - 1);
    if (error) throw error;
    all = all.concat((data ?? []) as T[]);
    if (!data || data.length < pageSize) break;
    from += pageSize;
  }
  return all;
}

export async function exportBackup(): Promise<{ json: string; meta: BackupMeta }> {
  const [students, payments, periods, levels, schoolYears, absences, operationsLog, settingsRows] = await Promise.all([
    fetchAll('students'),
    fetchAll('payments'),
    fetchAll('periods'),
    fetchAll('levels'),
    fetchAll('school_years'),
    fetchAll('absences'),
    fetchAll('operations_log'),
    fetchAll('settings'),
  ]);

  const backup: BackupData = {
    version: BACKUP_VERSION,
    created_at: new Date().toISOString(),
    tables: {
      students,
      payments,
      periods,
      levels,
      school_years: schoolYears,
      absences,
      operations_log: operationsLog,
      settings: settingsRows as BackupData['tables']['settings'],
    },
  };

  const json = JSON.stringify(backup, null, 2);
  return {
    json,
    meta: {
      date: backup.created_at,
      size: new Blob([json]).size,
      version: BACKUP_VERSION,
      studentCount: students.length,
      paymentCount: payments.length,
    },
  };
}

export function validateBackup(jsonString: string): BackupData {
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonString);
  } catch {
    throw new Error('Fichier JSON invalide ou corrompu');
  }
  const data = parsed as Partial<BackupData>;
  if (!data || typeof data !== 'object') throw new Error('Structure de sauvegarde invalide');
  if (!data.version || typeof data.version !== 'number') throw new Error('Version de sauvegarde manquante');
  if (!data.tables || typeof data.tables !== 'object') throw new Error('Données de tables manquantes');
  if (data.version > BACKUP_VERSION) throw new Error(`Sauvegarde version ${data.version} non supportée (max ${BACKUP_VERSION})`);
  return data as BackupData;
}

export async function importBackup(jsonString: string): Promise<void> {
  const backup = validateBackup(jsonString);
  const t = backup.tables;

  const upsertTable = async (table: string, rows: unknown[]) => {
    if (!rows || rows.length === 0) return;
    const { error } = await supabase.from(table).upsert(rows, { onConflict: 'id' });
    if (error) throw new Error(`Erreur import ${table}: ${error.message}`);
  };

  await upsertTable('levels', t.levels);
  await upsertTable('school_years', t.school_years);
  await upsertTable('students', t.students);
  await upsertTable('periods', t.periods);
  await upsertTable('payments', t.payments);
  await upsertTable('absences', t.absences);
  await upsertTable('operations_log', t.operations_log);
  await upsertTable('settings', t.settings);
}

export async function getBackupMeta(jsonString: string): Promise<BackupMeta> {
  const backup = validateBackup(jsonString);
  return {
    date: backup.created_at,
    size: new Blob([jsonString]).size,
    version: backup.version,
    studentCount: backup.tables.students.length,
    paymentCount: backup.tables.payments.length,
  };
}

export { DEFAULT_SETTINGS };
